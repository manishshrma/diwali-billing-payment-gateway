# 04 — When Payments Go Wrong: Declined Cards, Outages, Late Money and Refunds

This document explains what happens when a payment does not go smoothly, and
how the Payment and Booking services handle it. It covers four situations:

1. The customer's bank is down (or the card is declined) while they pay.
2. The bank takes the money but confirms it late.
3. Razorpay (or Stripe) cannot be reached from our server.
4. Our own Payment service, or its webhook endpoint, is down.

For each one: what it means in plain English, what was changed in the code,
and exactly how it works now.

These changes fix gaps A8 (no payment window) and A9 (money ignored after a
failure) from `docs/runbook/08-known-limitations.md` in the workspace root.
Both are now listed in that file's "Fixed" section.

---

## The rules in one minute

| Rule | What it means for the customer |
|---|---|
| **One payment link per booking.** | They always pay on the same page. There is never a second link that could charge them twice. |
| **The link is open for 30 minutes** (the *payment window*). | The slot is held for them for 30 minutes. After that the link stops accepting money and the slot is released. |
| **A declined attempt is not a failure.** | If the card is declined or the bank is down, they can try UPI, another card or netbanking on the same page, within the 30 minutes. |
| **Money is never ignored.** | If money reaches us for a booking we can no longer give them, it is **refunded automatically** (Option A). |
| **We ask the provider instead of guessing.** | If a message from Razorpay is lost or late, a background job checks with Razorpay directly. |

---

## Point 1 — The customer's bank is down (or the card is declined) while paying

### In plain English

The customer opens the payment page and pays by card. Their bank is having
problems, or the card is declined. Razorpay shows an error and lets them try
again on the same page, for example with UPI.

**Before the fix:** the first decline was treated as the end of the booking. The
booking failed and the slot was released. When the customer then paid with UPI
on the same page, the money was taken but our system ignored it. The customer
paid for nothing and nobody knew.

**Now:** a decline is just one failed attempt. The booking stays on hold and the
customer can keep trying until the 30-minute window ends. If they pay, the
booking is confirmed. If they never succeed, the window closes, the slot is
released, and nothing was charged.

### What was changed in the code

| Where | Change |
|---|---|
| `RazorpayWebhookController` | `payment.failed` now calls `processAttemptFailure` instead of failing the payment. |
| `WebhookProcessingService.processAttemptFailure` | Finds the open payment row for the booking and records the attempt. |
| `PaymentOutcomeService.applyAttemptFailure` | Increases `failed_attempts` and saves `last_failure_reason` / `last_error_code`. **The row stays `PENDING` and nothing is sent to Booking.** |
| `StripeWebhookController` | `payment_intent.payment_failed` is only acknowledged. A declined card inside Stripe Checkout keeps the session open. |
| `PaymentLinkResponse` (GET `/bookings/{id}/payment-link`) | Now also returns `expiresAt`, `lastAttemptFailureReason` and `failedAttempts`, so the UI can show "Your last attempt was declined, please try another method". |

### How it works now

```mermaid
sequenceDiagram
    participant C as Customer
    participant R as Razorpay page
    participant P as Payment service
    participant B as Booking service
    C->>R: Pays by card
    R-->>C: "Bank unavailable" (try another method)
    R->>P: webhook payment.failed
    P->>P: row stays PENDING, failed_attempts = 1, reason saved
    Note over P,B: Nothing sent to Booking — slot still held
    C->>R: Pays with UPI on the same page
    R->>P: webhook payment_link.paid
    P->>P: row PENDING → SUCCESS
    P->>B: PAYMENT_PROCESSED
    B->>B: booking PENDING → CONFIRMED
```

---

## Point 2 — The bank takes the money but confirms it late

### In plain English

Sometimes, often with UPI or netbanking, the bank takes the money from the
customer's account but tells Razorpay minutes or hours later. By then the
30-minute window may have closed and the slot may have gone to someone else.
The money arrives for a booking we can no longer give them.

**Before the fix:** that money was ignored, both inside Payment and inside
Booking. The customer was charged and got nothing.

**Now:** every payment that reaches us is recorded. Booking then decides:
- If the booking is still waiting for payment, it is **confirmed**.
- If the booking has already ended (window expired, failed, or cancelled before
  payment), Booking asks for a **refund**, and Payment refunds it automatically
  through Razorpay.

If the bank never confirms, it reverses the debit on its own and nothing was
captured, so there is nothing for us to do.

### What was changed in the code

| Where | Change |
|---|---|
| `PaymentOutcomeService.applySuccess` | Records a success even when the row is already `FAILED` (closed). The first success for a booking is sent to Booking as `PAYMENT_PROCESSED`. A second, different payment for an already-paid booking is refunded directly in Payment. |
| `RazorpayWebhookController` | Also handles `payment.captured`, the safety net for money captured on a link that was already closed. |
| `WebhookProcessingService` | All payment outcomes lock every payment row of the booking first, so two webhooks (or a webhook and the background job) can never decide differently. |
| Booking `PaymentProcessedProcessor` | If the booking is `FAILED`, `CANCELLED` before payment, or unknown, it emits `PAYMENT_REFUND_REQUESTED` instead of ignoring the money. |
| `RefundService` + `PaymentRefundRequestConsumer` | Receive the refund request and refund through Razorpay (or Stripe). |
| Grace period (`payment.reconciliation.grace-minutes`, 5) | Payment waits 5 minutes after the deadline before closing a link, so a last-second UPI payment usually lands first. |

### How it works now

```mermaid
sequenceDiagram
    participant R as Razorpay
    participant P as Payment service
    participant B as Booking service
    participant PL as Platform
    Note over P: 30 min + 5 min grace passed, no payment yet
    P->>R: cancel link
    R-->>P: cancelled
    P->>B: PAYMENT_FAILED (payment window expired)
    B->>PL: BOOKING_FAILED → slot released
    Note over R: 2 hours later the bank confirms the UPI payment
    R->>P: payment.captured
    P->>P: row FAILED → SUCCESS (money recorded)
    P->>B: PAYMENT_PROCESSED
    B->>B: booking is FAILED → cannot confirm
    B->>P: PAYMENT_REFUND_REQUESTED
    P->>R: refund
    R-->>P: refund id
    P->>P: refund_status = REFUNDED, alert logged
```

If the customer pays at the last second and the bank confirms within the
grace period, the payment is simply confirmed. When our cancel request reaches
Razorpay, Razorpay refuses it because the link is already paid, and Payment
records the payment instead.

---

## Point 3 — Razorpay (or Stripe) cannot be reached from our server

### In plain English

Sometimes our server cannot talk to Razorpay (network problem, Razorpay
outage). This can happen at three moments:

| Moment | What happens |
|---|---|
| Creating the payment link | Already handled before this fix: retried every 2 minutes, 5 times. If it still fails, the booking fails and the slot is released. |
| Closing a link (window over, or booking cancelled) | The link stays marked "to close" and the background job retries every few minutes until Razorpay answers. |
| Refunding | The refund stays `REQUESTED` and is retried with growing gaps (1, 2, 4, 8 ... up to 60 minutes), 10 times. If all fail, it becomes `FAILED` and a **MANUAL ACTION** alert asks someone to refund from the Razorpay dashboard. |

Nothing is lost during an outage; outcomes are only delayed.

### What was changed in the code

| Where | Change |
|---|---|
| `PaymentStrategy` | New provider operations: `fetchState` (ask what happened), `cancel` (close a link), `refund`. Implemented for Razorpay and Stripe. |
| `PaymentReconciliationService` | If a provider call fails, the row is left as it is and retried on a later run (`recheck-minutes`, 5). |
| `RefundService.executeRefund` | Claims the refund with a conditional database update, so two workers never refund the same payment. Before refunding, it asks the provider whether a refund already exists for this payment, so a retry after a timeout never refunds twice. Failures go back to `REQUESTED`, with backoff. |
| Kafka listeners for Booking events | Retry for up to 30 minutes with growing gaps if our database is briefly down. After that they raise a MANUAL ACTION alert instead of silently dropping the message. |

### How it works now

```mermaid
stateDiagram-v2
    [*] --> REQUESTED: Booking asks for refund\n(or second payment found)
    REQUESTED --> IN_PROGRESS: worker claims it
    IN_PROGRESS --> REFUNDED: provider accepted
    IN_PROGRESS --> REQUESTED: provider error\n(retry after 1, 2, 4 ... 60 min)
    IN_PROGRESS --> FAILED: 10 attempts used\n→ MANUAL ACTION alert
    IN_PROGRESS --> REQUESTED: worker crashed\n(claim older than 10 min)
```

---

## Point 4 — Our Payment service (or its webhook endpoint) is down

### In plain English

If our Payment service is down, Razorpay cannot deliver its messages. Razorpay
retries for a while, but if a message never arrives we used to have no way to
find out what happened, and the booking stayed "waiting for payment" forever
with its slot held.

**Now there are two safety nets:**

1. **Payment's reconciliation job** (every 2 minutes). For each payment whose
   window has passed (plus 5 minutes of grace), it asks Razorpay directly:
   - **paid** → the payment is recorded and the booking confirmed (or refunded if it already ended);
   - **still open** → the link is cancelled, the booking fails and the slot is released;
   - **expired/cancelled** → the booking fails and the slot is released.
2. **Booking's last-resort job** (every 5 minutes). If a booking is still waiting
   60 minutes after its deadline (for example Payment itself was down the whole
   time), Booking fails it and releases the slot. When Payment comes back, it
   closes the link. If the customer had paid, Booking asks for a refund.

### What was changed in the code

| Where | Change |
|---|---|
| `PaymentReconciliationService` + `PaymentReconciliationJob` (Payment) | New Quartz job (JDBC store, runs on one pod at a time). |
| `BookingLifecycleConsumer` + `BookingClosureService` (Payment) | Listen to `BOOKING_FAILED` / `BOOKING_CANCELLED`. Open links of that booking are marked "close requested" and cancelled at the provider. |
| `PendingBookingExpiryService` + `PendingBookingExpiryJob` (Booking) | The last-resort expiry. Waits 10 minutes after startup so Payment's job, which can see real payments, goes first. |
| `PaymentReconciliationService.checkClosedRowOnce` | One-time check of payment rows that failed **before** this fix: their links could still be paid. Open ones are cancelled; paid ones are recorded so the money is confirmed or refunded. |

### How it works now

```mermaid
flowchart TD
    A[Payment row PENDING] --> B{Window + 5 min passed,<br/>or booking closed?}
    B -- no --> A
    B -- yes --> C[Ask Razorpay: fetch link]
    C -->|error| D[Try again in 5 min]
    D --> C
    C -->|paid| E[Record SUCCESS<br/>→ PAYMENT_PROCESSED]
    C -->|expired / cancelled| F[Record FAILED<br/>→ PAYMENT_FAILED]
    C -->|still open| G[Cancel link]
    G -->|cancelled| F
    G -->|refused: already paid| E
    G -->|error| D
    E --> H[Booking confirms<br/>or asks for refund]
    F --> I[Booking fails,<br/>Platform releases slot]
```

---

## The payment window in detail

1. **Booking** creates the booking with `payment_due_at = now + 30 minutes`
   (`booking.payment.hold-minutes`) and sends it as `paymentDueAt` in
   `PAYMENT_REQUESTED`.
2. **Payment** creates the Razorpay link with `expire_by = paymentDueAt` and
   stores it in `payment.expires_at`. Provider limits are respected
   (`PaymentWindowPolicy`):
   - Razorpay: at least 16 minutes ahead (Razorpay requires 15).
   - Stripe: between 31 minutes and 23 hours ahead (Stripe allows 30 min to 24 h).
3. At the deadline Razorpay expires the link and sends `payment_link.expired`.
   Payment marks the row `FAILED` and sends **one** `PAYMENT_FAILED`. Booking
   fails the booking and Platform releases the slot.
4. If that webhook is lost, the reconciliation job does the same 5 minutes later.
5. If Payment is down, Booking's last-resort job does it 60 minutes later.

Expired bookings use the existing `FAILED` status with a clear reason. A new
`EXPIRED` status was not added on purpose: the `bookings.status` column has a
database check constraint generated by Hibernate, and a new value would need a
manual SQL migration (the same problem `add_pricing_level_client.sql` once
fixed).

## The "retry payment" endpoint

`POST /api/payment/bookings/{bookingId}/retry` **never creates a second link**
any more. Two open links for one booking were how a customer could be charged
twice.

| Situation | Response |
|---|---|
| Link still open | `409 PAYMENT_IN_PROGRESS` with the same `paymentUrl` (open it again), `expiresAt` and `lastAttemptFailureReason`. |
| Already paid | `409 ALREADY_PAID` |
| Window over (or booking closed) | `409 PAYMENT_WINDOW_CLOSED`: "please create a new booking". |

## Automatic refunds (Option A)

| Question | Answer |
|---|---|
| When? | Money arrived for a booking that ended before it was paid (expired, failed, cancelled, unknown), or a second payment arrived for an already-paid booking. |
| How fast? | Immediately; the customer usually sees it in a few working days (bank timing). |
| Refund amount | The full captured amount. |
| Can it refund twice? | No. One worker claims the row; before refunding, the provider is asked whether a refund already exists for that payment (Stripe calls also use an idempotency key per attempt). |
| What does ops see? | An `ALERT:` log line for every automatic refund, a `MANUAL ACTION` line if a refund finally fails, and `GET /api/payment/admin/refunds?status=FAILED` (or `REQUESTED`, `IN_PROGRESS`, `REFUNDED`). |
| Not covered | Refunds when a customer cancels an already **confirmed** booking stay a manual decision (gap A10). |

## Settings

| Property | Default | Meaning |
|---|---|---|
| Booking `booking.payment.hold-minutes` (env `BOOKING_PAYMENT_HOLD_MINUTES`) | 30 | Payment window length. |
| Booking `booking.payment.expiry-grace-minutes` | 60 | Last-resort expiry delay after the deadline. |
| Booking `booking.payment.expiry-job-interval-minutes` | 5 | How often the last-resort job runs. |
| Payment `payment.hold.default-minutes` (env `PAYMENT_HOLD_MINUTES`) | 30 | Used only when Booking sends no deadline (older events). |
| Payment `payment.reconciliation.interval-minutes` | 2 | How often reconciliation runs. |
| Payment `payment.reconciliation.grace-minutes` | 5 | Wait after the deadline before closing a link. |
| Payment `payment.reconciliation.recheck-minutes` | 5 | How often the same unresolved link is re-checked. |
| Payment `payment.refund.max-attempts` | 10 | Refund attempts before `FAILED` + MANUAL ACTION. |

## What must be set up outside the code

1. **Razorpay webhook events** (Dashboard → Webhooks): enable
   `payment_link.paid`, `payment_link.expired`, `payment_link.cancelled`,
   `payment.failed` and **`payment.captured`** (new).
2. **Razorpay late authorisation** (Dashboard → payment capture settings):
   check how late-authorised payments are handled. With auto-refund, Razorpay
   returns most late money itself; with auto-capture, our refund path does it.
   Both are safe.
3. **Alerts:** `AlertService` only writes `ALERT:` lines to the log. Make sure
   someone watches for `MANUAL ACTION` until real alerting (Slack/email) exists.
4. **Kafka topic** `topic_payment_refund_requested` is created by Booking on
   startup (or by the broker's auto-create).

## Deploying

- **No database migration is needed.** All new columns (`payment.expires_at`,
  `refund_*`, `bookings.payment_due_at`, ...) are nullable and added by Hibernate
  (`ddl-auto: update`).
- **Order:** deploy **Booking first**, then Payment. Booking already handles late
  payments; its refund requests wait in Kafka until the new Payment reads them.
- **First run after deploy:**
  - Payment's new listeners read the `booking-failed`/`booking-cancelled` history
    still kept in Kafka and close any links of those bookings that are still open.
  - Reconciliation settles old `PENDING` payments that never had an expiry, and
    checks old `FAILED` links once.
  - Expect a burst of Razorpay API calls and log lines in the first minutes.

## Finding past incidents (before this fix)

Customers who paid after a decline were charged while our records said
`FAILED`. The one-time check of old `FAILED` rows finds them: each such link
reports `paid`, the payment is recorded, and Booking requests a refund
automatically. To review them, search the logs for `Late payment` and
`RECONCILIATION_LEGACY`, or compare Razorpay's dashboard (links with status
*paid*) against `payment` rows with `status = 'FAILED'`.

## Edge cases found in review (and how they are handled)

An independent review of this change found these; all are fixed and tested.

| Edge case | Handling |
|---|---|
| Stripe link creation retried after a crash (session created, our row not saved) | `expires_at` is computed from the event's own timestamp, so the retry sends identical parameters and Stripe returns the same session. If the event is too old for its own expiry, a fresh expiry is used under a derived key. |
| Booking closed before Payment created its link (the two Kafka topics are not ordered) | Payment remembers the closed booking; a link created afterwards is marked for closing and cancelled by the next reconciliation run. |
| Same payment reported for two rows (older data with several links per booking) | The money stays recorded once; the other row is closed out (`PAID_ON_OTHER_ROW`) so it is not checked forever. Older `FAILED` rows that held a declined attempt's id get the real payment id. |
| Provider says "paid" but does not name the payment | Recorded as paid without an id; the payment webhook fills the id in (it is not mistaken for a second payment). |
| A background update and a payment webhook at the same moment | Background updates change only their own columns, so they can never overwrite a recorded payment. |
| Stripe refund retried after an earlier refund failed | Each attempt uses its own idempotency key, so a failed refund is never replayed as "done". |
| UI asks for the payment link after an internal refund row was added | The link endpoints look at the booking's link rows, not just the newest row. |

**Known limits (not changed here):**
- A refund the provider accepts but later fails (Razorpay `refund.failed`) is not
  tracked; `REFUNDED` means "the provider accepted it".
- Razorpay rejects a second link with the same `reference_id`, so if a link was
  created but our row was never saved, the retry fails and the booking fails
  (this was already true before this change).

## Tests

| Test | What it proves |
|---|---|
| `PaymentWindowAndLateMoneyIntegrationTests` (Payment, 23 tests) | Decline then UPI on the same link (also through the real webhook endpoint); late money; duplicate webhooks; second payment refunded; expiry sends one `PAYMENT_FAILED`; booking closed cancels the link (also when it closed before the link existed); reconciliation for lost webhooks, provider outage, legacy rows; review edge cases; refunds are idempotent, retried and escalated. |
| `PaymentWindowUnitTests` (Payment) | Window clamping per provider, Razorpay status mapping, refund backoff, JSON contract with Booking's events. |
| `PaymentControllerTests` (Payment) | `/retry` never creates a second link and finds the open link among several rows. |
| `PaymentWindowIntegrationTest` (Booking, 9 tests) | Booking gets a deadline and sends it; last-resort expiry; late payment → refund request instead of confirmation; cancelled-before-payment → refund; unknown booking → refund; a stuck event retries into a refund request. |

## Where the code is

| Service | Files |
|---|---|
| Payment | `service/PaymentOutcomeService`, `WebhookProcessingService`, `PaymentReconciliationService`, `BookingClosureService`, `RefundService`, `PaymentOutcomeDispatcher`, `PaymentWindowPolicy`, `ProviderPaymentState`, `RazorpayPaymentProcessor`, `StripePaymentProcessor`; `controller/RazorpayWebhookController`, `StripeWebhookController`, `PaymentController` (`/retry`), `PaymentAdminController` (`/admin/refunds`); `consumer/BookingLifecycleConsumer`, `PaymentRefundRequestConsumer`; `scheduler/PaymentReconciliationJob`; `domain/entity/Payment`, `RefundStatus` |
| Booking | `service/inbound/BookingRequestProcessor` (deadline), `PaymentProcessedProcessor` (confirm or refund request); `service/PendingBookingExpiryService` + `scheduler/PendingBookingExpiryJob`; `service/retries_cleanup/InboundOutboxRetryService`; `events/PaymentRefundRequestedEvent`; `domain/entity/Booking.paymentDueAt` |
