package com.forvmom.MomentForeverPayment.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;

/**
 * Decides how long a payment link/session stays payable.
 *
 * <p>
 * Booking owns the business deadline ({@code paymentDueAt} in
 * PAYMENT_REQUESTED). Each provider has its own limits, so the deadline is
 * clamped:
 * <ul>
 * <li>Razorpay rejects {@code expire_by} less than 15 minutes ahead, so the
 * link lives at least 16 minutes.</li>
 * <li>Stripe requires {@code expires_at} between 30 minutes and 24 hours
 * ahead, so the session lives 31 minutes to 23 hours.</li>
 * </ul>
 * When an older Booking build sends no deadline, the default hold window
 * ({@code payment.hold.default-minutes}, 30) is used.
 */
@Component
public class PaymentWindowPolicy {

    static final Duration RAZORPAY_MIN_AHEAD = Duration.ofMinutes(16);
    static final Duration STRIPE_MIN_AHEAD = Duration.ofMinutes(31);
    static final Duration STRIPE_MAX_AHEAD = Duration.ofHours(23);

    private final long defaultHoldMinutes;
    private final long graceMinutes;

    public PaymentWindowPolicy(
            @Value("${payment.hold.default-minutes:30}") long defaultHoldMinutes,
            @Value("${payment.reconciliation.grace-minutes:5}") long graceMinutes) {
        this.defaultHoldMinutes = defaultHoldMinutes > 0 ? defaultHoldMinutes : 30;
        this.graceMinutes = Math.max(graceMinutes, 0);
    }

    /**
     * @param requestedDueAt Booking's deadline, may be null
     * @return the instant the provider link/session should expire
     */
    public Instant linkExpiry(Instant requestedDueAt, PaymentProvider provider, Instant now) {
        Instant due = requestedDueAt != null ? requestedDueAt : now.plus(Duration.ofMinutes(defaultHoldMinutes));
        return switch (provider) {
            case RAZORPAY -> max(due, now.plus(RAZORPAY_MIN_AHEAD));
            case STRIPE -> min(max(due, now.plus(STRIPE_MIN_AHEAD)), now.plus(STRIPE_MAX_AHEAD));
        };
    }

    /** Converts to the LocalDateTime convention used by the Payment table. */
    public static LocalDateTime toLocal(Instant instant) {
        return LocalDateTime.ofInstant(instant, ZoneId.systemDefault());
    }

    public long getDefaultHoldMinutes() {
        return defaultHoldMinutes;
    }

    /**
     * Extra wait after the deadline before reconciliation steps in, so a
     * payment finishing at the last second (slow UPI/bank) still lands first.
     */
    public long getGraceMinutes() {
        return graceMinutes;
    }

    private static Instant max(Instant a, Instant b) {
        return a.isAfter(b) ? a : b;
    }

    private static Instant min(Instant a, Instant b) {
        return a.isBefore(b) ? a : b;
    }
}
