package com.forvmom.MomentForeverPayment.service;

import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;
import com.forvmom.MomentForeverPayment.domain.entity.WebhookInbox;
import com.forvmom.MomentForeverPayment.repository.PaymentRepository;
import com.forvmom.MomentForeverPayment.repository.WebhookInboxRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Booking said a booking ended unpaid (failed, expired or cancelled). Its
 * payment link must stop accepting money.
 *
 * <p>
 * Step 1 (fast, in the Kafka listener): mark every open payment row of the
 * booking as "close requested" in the database. Step 2: cancel the link at the
 * provider through {@link PaymentReconciliationService#reconcilePending}. If the
 * provider is down, step 2 is retried by the reconciliation job because the
 * mark from step 1 is already saved.
 */
@Service
public class BookingClosureService {

    private static final Logger log = LoggerFactory.getLogger(BookingClosureService.class);

    private final PaymentRepository paymentRepository;
    private final PaymentReconciliationService reconciliationService;
    private final TransactionTemplate transactionTemplate;
    private final WebhookInboxRepository webhookInboxRepository;

    public BookingClosureService(PaymentRepository paymentRepository,
                                 PaymentReconciliationService reconciliationService,
                                 TransactionTemplate transactionTemplate,
                                 WebhookInboxRepository webhookInboxRepository) {
        this.paymentRepository = paymentRepository;
        this.reconciliationService = reconciliationService;
        this.transactionTemplate = transactionTemplate;
        this.webhookInboxRepository = webhookInboxRepository;
    }

    /**
     * Marker saved when Booking closes a booking before Payment created its link
     * (the two Kafka topics are not ordered). Link creation checks it, see
     * {@link PaymentTransactionService#persistPaymentResult}.
     */
    public static String closedBookingMarker(String bookingId) {
        return "booking-closed:" + bookingId;
    }

    /** @return ids of open payment rows whose link must be cancelled */
    public List<Long> markCloseRequested(String bookingId, String reason) {
        List<Long> ids = transactionTemplate.execute(status -> {
            List<Long> open = new ArrayList<>();
            List<Payment> rows = paymentRepository.lockAllByBookingId(bookingId);
            if (rows.isEmpty() && !webhookInboxRepository.existsByEventId(closedBookingMarker(bookingId))) {
                WebhookInbox marker = new WebhookInbox();
                marker.setEventId(closedBookingMarker(bookingId));
                marker.setProvider(RefundService.BOOKING_PROVIDER);
                marker.setStatus("CLOSED");
                webhookInboxRepository.save(marker);
                log.info("Booking {} closed before its payment link existed; the link will be closed on creation",
                        bookingId);
            }
            for (Payment payment : rows) {
                if (payment.getStatus() != PaymentStatus.PENDING) {
                    continue;
                }
                if (payment.getCloseRequestedAt() == null) {
                    payment.setCloseRequestedAt(LocalDateTime.now());
                    payment.setCloseReason(PaymentOutcomeService.truncate(reason, 500));
                    paymentRepository.save(payment);
                }
                open.add(payment.getId());
            }
            return open;
        });
        if (ids != null && !ids.isEmpty()) {
            log.info("Booking {} closed ({}); closing {} open payment link(s)", bookingId, reason, ids.size());
        }
        return ids == null ? List.of() : ids;
    }

    /** Cancels the links at the provider; failures are retried by the job. */
    public void closeLinks(List<Long> paymentIds) {
        for (Long id : paymentIds) {
            try {
                reconciliationService.reconcilePending(id);
            } catch (Exception e) {
                log.warn("Closing payment link {} failed; reconciliation will retry: {}", id, e.getMessage());
            }
        }
    }
}
