package com.forvmom.MomentForeverPayment.domain.entity;

/**
 * Refund state of a {@link Payment} row. Stored as plain text (not a JPA enum)
 * so adding a value later never needs a database check-constraint migration.
 *
 * <p>
 * A {@code null} refund status means no refund was ever needed.
 *
 * <pre>
 * REQUESTED ──claim──▶ IN_PROGRESS ──provider ok──▶ REFUNDED
 *     ▲                     │
 *     └──provider error─────┘ (attempts &lt; max)
 *                           └──────────────────────▶ FAILED (attempts used up; a person must act)
 * </pre>
 */
public final class RefundStatus {

    /** Money must go back; no worker has picked it up yet. */
    public static final String REQUESTED = "REQUESTED";

    /** A worker claimed the refund and is calling the provider. */
    public static final String IN_PROGRESS = "IN_PROGRESS";

    /** The provider accepted the refund ({@code refundId} is set). */
    public static final String REFUNDED = "REFUNDED";

    /** Automatic refund gave up; an alert was raised for manual action. */
    public static final String FAILED = "FAILED";

    private RefundStatus() {
    }
}
