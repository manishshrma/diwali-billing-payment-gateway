package com.forvmom.MomentForeverPayment.dto;

import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 * Payment link for the UI.
 *
 * @param expiresAt                when the link stops accepting money (null for older links)
 * @param lastAttemptFailureReason why the last attempt was declined, e.g. "card declined";
 *                                 the link is still payable while {@code status} is PENDING
 * @param failedAttempts           number of declined attempts on this link
 */
public record PaymentLinkResponse(
        String bookingId,
        String provider,
        String providerSessionId,
        String paymentUrl,
        PaymentStatus status,
        BigDecimal amount,
        String currency,
        LocalDateTime createdAt,
        LocalDateTime updatedAt,
        LocalDateTime expiresAt,
        String lastAttemptFailureReason,
        Integer failedAttempts
) {
    public static PaymentLinkResponse from(Payment payment) {
        return new PaymentLinkResponse(
                payment.getBookingId(),
                payment.getProvider(),
                payment.getProviderSessionId(),
                payment.getPaymentUrl(),
                payment.getStatus(),
                payment.getAmount(),
                payment.getCurrency(),
                payment.getCreatedAt(),
                payment.getUpdatedAt(),
                payment.getExpiresAt(),
                payment.getLastFailureReason(),
                payment.getFailedAttempts() == null ? 0 : payment.getFailedAttempts()
        );
    }
}
