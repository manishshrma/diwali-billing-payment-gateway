package com.forvmom.MomentForeverPayment.service;

import com.forvmom.MomentForeverPayment.domain.entity.OutgoingPaymentOutbox;
import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;
import com.forvmom.MomentForeverPayment.domain.entity.RefundStatus;
import com.forvmom.MomentForeverPayment.events.InboundPaymentEvent;
import com.forvmom.MomentForeverPayment.events.OutGoingEvent;
import com.forvmom.MomentForeverPayment.events.PaymentFailedEvent;
import com.forvmom.MomentForeverPayment.repository.PaymentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Objects;

/**
 * The single place that decides what a provider result means for our data.
 * Webhooks, the reconciliation job and the booking-closed listener all call
 * here, so the rules below hold whichever path sees the result first.
 *
 * <p>
 * Rules:
 * <ol>
 * <li><b>A declined attempt is not a failure.</b> The link stays payable; we
 * only record the reason.</li>
 * <li><b>Money is never ignored.</b> A success is always recorded, even on a
 * row that was already closed. The first success of a booking goes to Booking
 * (PAYMENT_PROCESSED), which confirms the booking or asks for a refund. Any
 * further success for the same booking is refunded here directly.</li>
 * <li><b>Booking hears at most one PAYMENT_PROCESSED and one PAYMENT_FAILED per
 * booking</b> (Booking's inbox is unique per booking and event type).</li>
 * </ol>
 *
 * <p>
 * Every method must run inside the caller's transaction with all of the
 * booking's payment rows locked ({@link PaymentRepository#lockAllByBookingId}).
 */
@Service
public class PaymentOutcomeService {

    private static final Logger log = LoggerFactory.getLogger(PaymentOutcomeService.class);

    static final String SECOND_PAYMENT_REASON =
            "Second payment received for a booking that was already paid";

    private final PaymentRepository paymentRepository;
    private final OutgoingEventFactoryRegistry outgoingEventFactoryRegistry;
    private final OutgoingPaymentOutboxService outgoingPaymentOutboxService;
    private final AlertService alertService;

    public PaymentOutcomeService(PaymentRepository paymentRepository,
                                 OutgoingEventFactoryRegistry outgoingEventFactoryRegistry,
                                 OutgoingPaymentOutboxService outgoingPaymentOutboxService,
                                 AlertService alertService) {
        this.paymentRepository = paymentRepository;
        this.outgoingEventFactoryRegistry = outgoingEventFactoryRegistry;
        this.outgoingPaymentOutboxService = outgoingPaymentOutboxService;
        this.alertService = alertService;
    }

    /**
     * What the caller must do after the transaction commits.
     *
     * @param outgoing        event to publish to Booking (may be null)
     * @param refundPaymentId payment row whose refund should be executed (may be null)
     */
    public record Outcome(OutgoingPaymentOutbox outgoing, Long refundPaymentId) {
        public static Outcome none() {
            return new Outcome(null, null);
        }
    }

    /**
     * Records that the provider captured money for {@code row}.
     *
     * @param bookingRows all rows of the booking, locked, including {@code row}
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public Outcome applySuccess(Payment row, List<Payment> bookingRows, String transactionId, String source) {
        // A transaction id stored on a row that is not SUCCESS is never captured
        // money (older code stored the declined attempt's id there), so only a
        // SUCCESS row's own id may stand in for an unknown one.
        String txn = hasText(transactionId)
                ? transactionId
                : (row.getStatus() == PaymentStatus.SUCCESS ? row.getTransactionId() : null);
        LocalDateTime now = LocalDateTime.now();

        // Same money already recorded on some row -> duplicate notification.
        if (hasText(txn)) {
            Payment holder = bookingRows.stream()
                    .filter(p -> p.getStatus() == PaymentStatus.SUCCESS && txn.equals(p.getTransactionId()))
                    .findFirst().orElse(null);
            if (holder != null) {
                if (!sameRow(holder, row)) {
                    closeOutPaidElsewhere(row, holder, txn, now);
                }
                log.info("Payment {} for booking {} already recorded; ignoring duplicate ({})",
                        txn, row.getBookingId(), source);
                return Outcome.none();
            }
        }

        if (row.getStatus() == PaymentStatus.SUCCESS) {
            if (!hasText(txn) || txn.equals(row.getTransactionId())) {
                return Outcome.none();
            }
            if (!hasText(row.getTransactionId())) {
                // Paid earlier without a known payment id (e.g. found by
                // reconciliation); this is the same payment, not a second one.
                row.setTransactionId(txn);
                row.setLastReconciledAt(now);
                paymentRepository.save(row);
                return Outcome.none();
            }
            // This row was already paid by a different payment: a second charge.
            Payment extra = newExtraPaymentRow(row, txn);
            markRefundRequested(extra, SECOND_PAYMENT_REASON, now);
            Payment saved = paymentRepository.save(extra);
            alertService.sendAlert(String.format(
                    "Second payment %s for already-paid booking %s; automatic refund requested",
                    txn, row.getBookingId()));
            return new Outcome(null, saved.getId());
        }

        boolean bookingAlreadyPaid = bookingRows.stream()
                .anyMatch(p -> p != row && !Objects.equals(p.getId(), row.getId())
                        && p.getStatus() == PaymentStatus.SUCCESS);

        PaymentStatus previous = row.getStatus();
        row.setStatus(PaymentStatus.SUCCESS);
        // Overwrite any declined attempt's id; null means "captured, id not known yet".
        row.setTransactionId(txn);
        row.setLastReconciledAt(now);

        if (bookingAlreadyPaid) {
            markRefundRequested(row, SECOND_PAYMENT_REASON, now);
            paymentRepository.save(row);
            alertService.sendAlert(String.format(
                    "Second payment %s for already-paid booking %s; automatic refund requested",
                    txn, row.getBookingId()));
            return new Outcome(null, row.getId());
        }

        paymentRepository.save(row);
        if (previous != PaymentStatus.PENDING) {
            // Money arrived on a link we had already closed (race at the deadline,
            // bank confirming late). Booking decides: confirm or refund.
            log.warn("Late payment {} for booking {} on a {} row ({}); sending to Booking to decide",
                    txn, row.getBookingId(), previous, source);
        } else {
            log.info("Payment {} succeeded for booking {} ({})", txn, row.getBookingId(), source);
        }
        return new Outcome(createOutgoing(row, source, null, null), null);
    }

    /**
     * Records that the link/session can no longer be paid (expired or cancelled).
     * Booking is told only when this closes the booking's payment for the first
     * time and Booking did not close it itself.
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public Outcome applyClosed(Payment row, List<Payment> bookingRows, String reason, String errorCode, String source) {
        if (row.getStatus() != PaymentStatus.PENDING) {
            row.setLastReconciledAt(LocalDateTime.now());
            paymentRepository.save(row);
            return Outcome.none();
        }
        row.setStatus(PaymentStatus.FAILED);
        row.setLastReconciledAt(LocalDateTime.now());
        if (row.getCloseRequestedAt() == null) {
            row.setLastFailureReason(truncate(reason, 500));
            row.setLastErrorCode(truncate(errorCode, 100));
        }
        paymentRepository.save(row);

        if (row.getCloseRequestedAt() != null) {
            log.info("Link for booking {} closed after Booking closed the booking ({})", row.getBookingId(), source);
            return Outcome.none();
        }
        boolean bookingAlreadyHasOutcome = bookingRows.stream()
                .anyMatch(p -> !Objects.equals(p.getId(), row.getId())
                        && (p.getStatus() == PaymentStatus.FAILED || p.getStatus() == PaymentStatus.SUCCESS));
        if (bookingAlreadyHasOutcome) {
            // Older attempt rows (before one-link-per-booking) already told Booking.
            log.info("Link for booking {} closed; booking already has a payment outcome ({})",
                    row.getBookingId(), source);
            return Outcome.none();
        }
        log.info("Payment window closed for booking {} ({}, {})", row.getBookingId(), errorCode, source);
        return new Outcome(createOutgoing(row, source, reason, errorCode), null);
    }

    /**
     * A single declined attempt (card declined, bank down, UPI failure). The link
     * stays payable, so nothing is sent to Booking.
     */
    @Transactional(propagation = Propagation.MANDATORY)
    public void applyAttemptFailure(Payment row, String reason, String errorCode) {
        if (row.getStatus() != PaymentStatus.PENDING) {
            log.info("Ignoring declined attempt for booking {}: payment already {}",
                    row.getBookingId(), row.getStatus());
            return;
        }
        int attempts = row.getFailedAttempts() == null ? 0 : row.getFailedAttempts();
        row.setFailedAttempts(attempts + 1);
        row.setLastFailureReason(truncate(reason, 500));
        row.setLastErrorCode(truncate(errorCode, 100));
        paymentRepository.save(row);
        log.info("Declined attempt #{} for booking {} ({}: {}); link stays payable",
                attempts + 1, row.getBookingId(), errorCode, reason);
    }

    /**
     * The provider says this row's link was paid, but that money is already
     * recorded on another row (older data with several links per booking, or
     * {@code payment.captured} attached it first). Close this row out so the
     * reconciliation job stops asking the provider about it.
     */
    private void closeOutPaidElsewhere(Payment row, Payment holder, String txn, LocalDateTime now) {
        row.setLastReconciledAt(now);
        if (row.getStatus() == PaymentStatus.PENDING) {
            row.setStatus(PaymentStatus.FAILED);
            row.setLastFailureReason(truncate("Link paid; payment " + txn
                    + " is recorded on payment row " + holder.getId(), 500));
            row.setLastErrorCode("PAID_ON_OTHER_ROW");
        }
        paymentRepository.save(row);
    }

    private static boolean sameRow(Payment a, Payment b) {
        return a == b || (a.getId() != null && a.getId().equals(b.getId()));
    }

    /** Marks a captured payment as needing a refund (worker executes it later). */
    public static void markRefundRequested(Payment payment, String reason, LocalDateTime now) {
        if (payment.getRefundStatus() != null) {
            return; // already requested, in progress or done
        }
        payment.setRefundStatus(RefundStatus.REQUESTED);
        payment.setRefundReason(truncate(reason, 500));
        payment.setRefundRequestedAt(now);
        payment.setRefundAttempts(0);
    }

    private OutgoingPaymentOutbox createOutgoing(Payment payment, String source, String failureReason, String errorCode) {
        OutgoingEventFactory factory = outgoingEventFactoryRegistry.getFactoryForStatus(payment.getStatus());
        OutGoingEvent event = factory.createEvent(syntheticInbound(payment, source), payment);
        if (event instanceof PaymentFailedEvent failedEvent) {
            if (hasText(failureReason)) {
                failedEvent.setFailureReason(failureReason);
            }
            if (hasText(errorCode)) {
                failedEvent.setErrorCode(errorCode);
            }
        }
        return outgoingPaymentOutboxService.createRecord(
                payment.getBookingId(), event.getEventType(), event.getProducer(), event.getEventId(), event);
    }

    private static Payment newExtraPaymentRow(Payment paidRow, String transactionId) {
        Payment extra = new Payment();
        extra.setProvider(paidRow.getProvider());
        extra.setBookingId(paidRow.getBookingId());
        extra.setCorrelationId(paidRow.getCorrelationId());
        extra.setAmount(paidRow.getAmount());
        extra.setCurrency(paidRow.getCurrency());
        extra.setTransactionId(transactionId);
        extra.setStatus(PaymentStatus.SUCCESS);
        extra.setLastReconciledAt(LocalDateTime.now());
        // No providerSessionId: the link belongs to the row that was paid first.
        return extra;
    }

    static InboundPaymentEvent syntheticInbound(Payment payment, String source) {
        return new InboundPaymentEvent() {
            @Override public String getEventType() { return source; }
            @Override public String getBookingId() { return payment.getBookingId(); }
            @Override public String getPaymentType() { return payment.getProvider(); }
            @Override public String getEventId() { return source + ":" + payment.getId(); }
            @Override public String getProducer() { return "payment-service"; }
            @Override public String getCorrelationId() { return payment.getCorrelationId(); }
        };
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }

    static String truncate(String value, int max) {
        if (value == null) {
            return null;
        }
        return value.length() <= max ? value : value.substring(0, max);
    }
}
