package com.forvmom.MomentForeverPayment.service;

import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;
import com.forvmom.MomentForeverPayment.repository.PaymentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Asks the provider what really happened instead of trusting silence.
 *
 * <p>
 * Covers every case where a webhook is late or lost (our service down, bank
 * slow, provider retrying): once a payment window has passed (plus a grace
 * period) or Booking closed the booking, the provider is asked about the link:
 * <ul>
 * <li>PAID → recorded as a success (Booking confirms, or asks for a refund if
 * the booking is already closed).</li>
 * <li>still OPEN → cancelled at the provider. If the provider refuses because
 * the customer just paid, that payment is recorded instead.</li>
 * <li>CLOSED → the payment fails and Booking releases the slot.</li>
 * </ul>
 * If the provider cannot be reached the row is retried on a later run, so an
 * outage only delays the outcome.
 *
 * <p>
 * It also checks, once, FAILED rows created before this fix: back then a
 * declined card marked the row FAILED while its link stayed payable.
 */
@Service
public class PaymentReconciliationService {

    private static final Logger log = LoggerFactory.getLogger(PaymentReconciliationService.class);

    static final String WINDOW_EXPIRED_REASON = "Payment window expired before the payment was completed - booking released";
    static final String WINDOW_EXPIRED_CODE = "PAYMENT_WINDOW_EXPIRED";

    private final PaymentRepository paymentRepository;
    private final PaymentProcessorRegistry processorRegistry;
    private final PaymentOutcomeService outcomeService;
    private final PaymentOutcomeDispatcher dispatcher;
    private final PaymentWindowPolicy windowPolicy;
    private final AlertService alertService;
    private final TransactionTemplate transactionTemplate;
    private final int batchSize;
    private final long recheckMinutes;

    public PaymentReconciliationService(PaymentRepository paymentRepository,
                                        PaymentProcessorRegistry processorRegistry,
                                        PaymentOutcomeService outcomeService,
                                        PaymentOutcomeDispatcher dispatcher,
                                        PaymentWindowPolicy windowPolicy,
                                        AlertService alertService,
                                        TransactionTemplate transactionTemplate,
                                        @Value("${payment.reconciliation.batch-size:50}") int batchSize,
                                        @Value("${payment.reconciliation.recheck-minutes:5}") long recheckMinutes) {
        this.paymentRepository = paymentRepository;
        this.processorRegistry = processorRegistry;
        this.outcomeService = outcomeService;
        this.dispatcher = dispatcher;
        this.windowPolicy = windowPolicy;
        this.alertService = alertService;
        this.transactionTemplate = transactionTemplate;
        this.batchSize = Math.max(batchSize, 1);
        this.recheckMinutes = Math.max(recheckMinutes, 1);
    }

    /** One pass of the reconciliation job. */
    public void runOnce() {
        LocalDateTime now = LocalDateTime.now();
        long grace = windowPolicy.getGraceMinutes();
        List<Payment> due = paymentRepository.findPendingDueForReconciliation(
                PaymentStatus.PENDING,
                now.minusMinutes(recheckMinutes),
                now.minusMinutes(grace),
                now.minusMinutes(windowPolicy.getDefaultHoldMinutes() + grace),
                PageRequest.of(0, batchSize));
        if (!due.isEmpty()) {
            log.info("Reconciliation: {} pending payment(s) past their window or closed by Booking", due.size());
        }
        for (Payment payment : due) {
            try {
                reconcilePending(payment.getId());
            } catch (Exception e) {
                log.error("Reconciliation crashed for payment {}", payment.getId(), e);
            }
        }

        List<Payment> legacy = paymentRepository.findFailedNeverReconciled(
                PaymentStatus.FAILED, PageRequest.of(0, batchSize));
        if (!legacy.isEmpty()) {
            log.info("Reconciliation: checking {} older FAILED payment link(s) once", legacy.size());
        }
        for (Payment payment : legacy) {
            try {
                checkClosedRowOnce(payment.getId());
            } catch (Exception e) {
                log.error("Legacy link check crashed for payment {}", payment.getId(), e);
            }
        }
    }

    /**
     * Resolves one PENDING row against the provider. Also called right away when
     * Booking reports the booking closed.
     */
    public void reconcilePending(Long paymentId) {
        Payment snapshot = paymentRepository.findById(paymentId).orElse(null);
        if (snapshot == null || snapshot.getStatus() != PaymentStatus.PENDING
                || snapshot.getProviderSessionId() == null) {
            return;
        }
        LocalDateTime now = LocalDateTime.now();
        ProviderPaymentState state;
        boolean closedByUs = false;
        try {
            PaymentStrategy strategy = processorRegistry.getPaymentTypeProcessor(snapshot.getProvider());
            state = strategy.fetchState(snapshot);
            if (state.kind() == ProviderPaymentState.Kind.OPEN && isOverdue(snapshot, now)) {
                state = strategy.cancel(snapshot);
                closedByUs = state.kind() == ProviderPaymentState.Kind.CLOSED;
            }
        } catch (Exception e) {
            log.warn("Could not reconcile payment {} (booking {}) with {}: {}. Will retry.",
                    paymentId, snapshot.getBookingId(), snapshot.getProvider(), e.getMessage());
            touch(paymentId);
            return;
        }

        final ProviderPaymentState finalState = state;
        final boolean finalClosedByUs = closedByUs;
        PaymentOutcomeService.Outcome outcome = transactionTemplate.execute(status -> {
            List<Payment> rows = paymentRepository.lockAllByBookingId(snapshot.getBookingId());
            Payment row = rows.stream().filter(p -> p.getId().equals(paymentId)).findFirst().orElse(null);
            if (row == null) {
                return PaymentOutcomeService.Outcome.none();
            }
            switch (finalState.kind()) {
                case PAID:
                    return outcomeService.applySuccess(row, rows, finalState.transactionId(), "RECONCILIATION");
                case CLOSED:
                    String[] reasonAndCode = closedReason(finalState, finalClosedByUs);
                    return outcomeService.applyClosed(row, rows, reasonAndCode[0], reasonAndCode[1], "RECONCILIATION");
                default:
                    row.setLastReconciledAt(LocalDateTime.now());
                    paymentRepository.save(row);
                    return PaymentOutcomeService.Outcome.none();
            }
        });
        dispatcher.dispatch(outcome);
    }

    /**
     * One-time check of a FAILED row whose link may still be payable (rows
     * failed by a declined card before this fix). Open links are cancelled; a
     * link that was paid is recorded so the money is confirmed or refunded.
     */
    public void checkClosedRowOnce(Long paymentId) {
        Payment snapshot = paymentRepository.findById(paymentId).orElse(null);
        if (snapshot == null || snapshot.getStatus() != PaymentStatus.FAILED
                || snapshot.getLastReconciledAt() != null || snapshot.getProviderSessionId() == null) {
            return;
        }
        ProviderPaymentState state;
        try {
            PaymentStrategy strategy = processorRegistry.getPaymentTypeProcessor(snapshot.getProvider());
            state = strategy.fetchState(snapshot);
            if (state.kind() == ProviderPaymentState.Kind.OPEN) {
                state = strategy.cancel(snapshot);
            }
        } catch (Exception e) {
            touch(paymentId);
            alertService.sendAlert(String.format(
                    "Could not verify older payment link %s (booking %s) with %s: %s. "
                            + "Check it in the provider dashboard and cancel it if it is still open.",
                    snapshot.getProviderSessionId(), snapshot.getBookingId(), snapshot.getProvider(), e.getMessage()));
            return;
        }
        final ProviderPaymentState finalState = state;
        PaymentOutcomeService.Outcome outcome = transactionTemplate.execute(status -> {
            List<Payment> rows = paymentRepository.lockAllByBookingId(snapshot.getBookingId());
            Payment row = rows.stream().filter(p -> p.getId().equals(paymentId)).findFirst().orElse(null);
            if (row == null) {
                return PaymentOutcomeService.Outcome.none();
            }
            if (finalState.kind() == ProviderPaymentState.Kind.PAID) {
                return outcomeService.applySuccess(row, rows, finalState.transactionId(), "RECONCILIATION_LEGACY");
            }
            row.setLastReconciledAt(LocalDateTime.now());
            paymentRepository.save(row);
            return PaymentOutcomeService.Outcome.none();
        });
        dispatcher.dispatch(outcome);
    }

    boolean isOverdue(Payment payment, LocalDateTime now) {
        if (payment.getCloseRequestedAt() != null) {
            return true;
        }
        if (payment.getExpiresAt() != null) {
            return payment.getExpiresAt().isBefore(now);
        }
        return payment.getCreatedAt() != null && payment.getCreatedAt().isBefore(
                now.minusMinutes(windowPolicy.getDefaultHoldMinutes() + windowPolicy.getGraceMinutes()));
    }

    private static String[] closedReason(ProviderPaymentState state, boolean closedByUs) {
        String detail = state.detail() == null ? "" : state.detail();
        if (closedByUs || detail.startsWith("expired")) {
            return new String[]{WINDOW_EXPIRED_REASON, WINDOW_EXPIRED_CODE};
        }
        if (detail.startsWith("cancelled")) {
            return new String[]{"Payment link was cancelled", "PAYMENT_LINK_CANCELLED"};
        }
        return new String[]{"Payment failed (" + detail + ")", "PAYMENT_FAILED"};
    }

    /**
     * Records "asked the provider just now" with a single-column UPDATE: the row
     * is not locked here, and a webhook may record a payment at this very moment.
     */
    private void touch(Long paymentId) {
        try {
            transactionTemplate.executeWithoutResult(status ->
                    paymentRepository.markReconciled(paymentId, LocalDateTime.now()));
        } catch (Exception e) {
            log.warn("Could not record reconciliation attempt for payment {}: {}", paymentId, e.getMessage());
        }
    }
}
