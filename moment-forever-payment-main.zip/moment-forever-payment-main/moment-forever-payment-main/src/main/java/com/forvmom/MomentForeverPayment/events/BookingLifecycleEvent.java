package com.forvmom.MomentForeverPayment.events;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

/**
 * The subset of Booking's BOOKING_FAILED / BOOKING_CANCELLED events that Payment
 * needs: which booking ended without being paid. Payment then closes the
 * booking's open payment link so nobody can pay it any more.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class BookingLifecycleEvent {
    private String eventType;
    private String eventId;
    private String producer;
    private String bookingId;
    private String failureReason;
    private String cancelReason;
}
