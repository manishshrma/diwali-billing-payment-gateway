package com.forvmom.MomentForeverPayment.service;

import com.forvmom.MomentForeverPayment.domain.entity.OutgoingPaymentOutbox;
import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentOutbox;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;
import com.forvmom.MomentForeverPayment.events.InboundPaymentEvent;
import com.forvmom.MomentForeverPayment.events.OutGoingEvent;
import com.forvmom.MomentForeverPayment.repository.PaymentRepository;
import com.forvmom.MomentForeverPayment.repository.WebhookInboxRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class PaymentTransactionService {

    private static final Logger log = LoggerFactory.getLogger(PaymentTransactionService.class);

    private final PaymentRepository paymentRepository;
    private final OutgoingEventFactoryRegistry outgoingEventFactoryRegistry;
    private final OutgoingPaymentOutboxService outgoingPaymentOutboxService;
    private final PaymentOutboxService paymentOutboxService;
    private final WebhookInboxRepository webhookInboxRepository;

    public PaymentTransactionService(
            PaymentRepository paymentRepository,
            OutgoingEventFactoryRegistry outgoingEventFactoryRegistry,
            OutgoingPaymentOutboxService outgoingPaymentOutboxService,
            PaymentOutboxService paymentOutboxService,
            WebhookInboxRepository webhookInboxRepository) {
        this.paymentRepository = paymentRepository;
        this.outgoingEventFactoryRegistry = outgoingEventFactoryRegistry;
        this.outgoingPaymentOutboxService = outgoingPaymentOutboxService;
        this.paymentOutboxService = paymentOutboxService;
        this.webhookInboxRepository = webhookInboxRepository;
    }

    @Transactional
    public OutgoingPaymentOutbox persistPaymentResult(
            PaymentOutbox inbox,
            InboundPaymentEvent inboundEvent,
            Payment payment) {
        if (payment.getStatus() == PaymentStatus.PENDING && payment.getBookingId() != null
                && webhookInboxRepository.existsByEventId(
                        BookingClosureService.closedBookingMarker(payment.getBookingId()))) {
            // Booking closed this booking before the link existed (the topics are
            // not ordered). Mark the new link for closing; the reconciliation job
            // cancels it within minutes so nobody can pay for a released slot.
            payment.setCloseRequestedAt(LocalDateTime.now());
            payment.setCloseReason("Booking was closed before its payment link was created");
            log.warn("Payment link for already-closed booking {} will be cancelled", payment.getBookingId());
        }
        Payment savedPayment = paymentRepository.save(payment);
        OutgoingEventFactory factory =
                outgoingEventFactoryRegistry.getFactoryForStatus(savedPayment.getStatus());
        OutGoingEvent outgoingEvent = factory.createEvent(inboundEvent, savedPayment);

        OutgoingPaymentOutbox outgoingRecord = outgoingPaymentOutboxService.createRecord(
                inbox.getBookingId(),
                outgoingEvent.getEventType(),
                outgoingEvent.getProducer(),
                outgoingEvent.getEventId(),
                outgoingEvent);

        paymentOutboxService.markAsProcessed(inbox);
        log.info("Persisted payment result and outgoing event for bookingId={}",
                inboundEvent.getBookingId());
        return outgoingRecord;
    }
}
