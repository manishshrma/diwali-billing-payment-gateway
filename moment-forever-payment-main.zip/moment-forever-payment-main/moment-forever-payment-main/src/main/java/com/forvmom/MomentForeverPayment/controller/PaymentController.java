package com.forvmom.MomentForeverPayment.controller;

import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;
import com.forvmom.MomentForeverPayment.dto.PaymentLinkResponse;
import com.forvmom.MomentForeverPayment.repository.PaymentRepository;
import com.forvmom.MomentForeverPayment.service.PaymentQueryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/bookings")
@Tag(name = "Payment", description = "UI-facing payment APIs")
public class PaymentController {

    private static final Logger log = LoggerFactory.getLogger(PaymentController.class);

    private final PaymentQueryService paymentQueryService;
    private final PaymentRepository paymentRepository;

    @Autowired
    public PaymentController(PaymentQueryService paymentQueryService,
                             PaymentRepository paymentRepository) {
        this.paymentQueryService = paymentQueryService;
        this.paymentRepository = paymentRepository;
    }

    /** Test-only convenience constructor (GET payment-link path needs only query service). */
    public PaymentController(PaymentQueryService paymentQueryService) {
        this(paymentQueryService, null);
    }

    @GetMapping("/{bookingId}/payment-link")
    @Operation(summary = "Get latest payment link URL for a booking. " +
            "UI polls this after creating a booking until Stripe/Razorpay session is ready.")
    public ResponseEntity<?> getPaymentLink(@PathVariable String bookingId) {
        if (bookingId == null || bookingId.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of(
                    "code", "INVALID_BOOKING_ID",
                    "message", "bookingId must not be blank"));
        }

        return paymentQueryService.getLatestPaymentForBooking(bookingId.trim())
                .map(payment -> {
                    // Session not created yet (no URL persisted) -> tell UI to keep polling
                    if (payment.getPaymentUrl() == null || payment.getPaymentUrl().isBlank()) {
                        return ResponseEntity.status(404).body(Map.of(
                                "code", "PAYMENT_NOT_READY",
                                "message", "Payment session is being created. Retry shortly.",
                                "bookingId", bookingId));
                    }
                    return ResponseEntity.ok(PaymentLinkResponse.from(payment));
                })
                .orElseGet(() -> ResponseEntity.status(404).body(Map.of(
                        "code", "PAYMENT_NOT_READY",
                        "message", "No payment session found yet for this booking. Retry shortly.",
                        "bookingId", bookingId)));
    }

    /**
     * "Try paying again" for a booking.
     *
     * <p>
     * Each booking has exactly ONE payment link, valid for the booking's payment
     * window. A declined card does not close it: the customer retries on the same
     * page with UPI, another card or netbanking. So this endpoint never creates a
     * second link (two open links let one booking be charged twice):
     * <ul>
     * <li>link still payable → {@code 409 PAYMENT_IN_PROGRESS} with the same
     * {@code paymentUrl} (open it again)</li>
     * <li>already paid → {@code 409 ALREADY_PAID}</li>
     * <li>window over → {@code 409 PAYMENT_WINDOW_CLOSED}: the slot was released;
     * the customer must create a new booking</li>
     * </ul>
     */
    @PostMapping("/{bookingId}/retry")
    @Operation(summary = "Get the payment link to try again. Never creates a second link: "
            + "returns the open link, or PAYMENT_WINDOW_CLOSED when the booking must be made again.")
    public ResponseEntity<?> retryPayment(@PathVariable String bookingId) {
        if (bookingId == null || bookingId.isBlank()) {
            return ResponseEntity.badRequest().body(Map.of(
                    "code", "INVALID_BOOKING_ID",
                    "message", "bookingId must not be blank"));
        }
        String id = bookingId.trim();
        List<Payment> rows = paymentRepository.findAllByBookingIdOrderByIdDesc(id); // newest first
        if (rows.isEmpty()) {
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(Map.of(
                    "code", "PAYMENT_NOT_FOUND",
                    "message", "No payment attempt found for this booking.",
                    "bookingId", id));
        }
        if (rows.stream().anyMatch(p -> p.getStatus() == PaymentStatus.SUCCESS)) {
            return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of(
                    "code", "ALREADY_PAID",
                    "message", "Booking is already paid. Retry not allowed.",
                    "bookingId", id));
        }
        Payment latest = rows.stream()
                .filter(p -> p.getStatus() == PaymentStatus.PENDING
                        && p.getCloseRequestedAt() == null
                        && p.getPaymentUrl() != null && !p.getPaymentUrl().isBlank())
                .findFirst().orElse(null);
        if (latest != null) {
            Map<String, Object> body = new LinkedHashMap<>();
            body.put("code", "PAYMENT_IN_PROGRESS");
            body.put("message", "The payment link is still open. Use it to pay with any method "
                    + "(a declined card can be retried on the same page).");
            body.put("bookingId", id);
            body.put("paymentUrl", latest.getPaymentUrl() == null ? "" : latest.getPaymentUrl());
            body.put("providerSessionId", latest.getProviderSessionId() == null ? "" : latest.getProviderSessionId());
            body.put("expiresAt", latest.getExpiresAt() == null ? "" : latest.getExpiresAt().toString());
            body.put("lastAttemptFailureReason",
                    latest.getLastFailureReason() == null ? "" : latest.getLastFailureReason());
            return ResponseEntity.status(HttpStatus.CONFLICT).body(body);
        }

        log.info("Retry refused for booking {}: payment window closed", id);
        return ResponseEntity.status(HttpStatus.CONFLICT).body(Map.of(
                "code", "PAYMENT_WINDOW_CLOSED",
                "message", "The payment window for this booking has closed and its slot was released. "
                        + "Please create a new booking.",
                "bookingId", id));
    }
}
