package com.forvmom.MomentForeverPayment.events;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

import java.math.BigDecimal;
import java.time.Instant;

/**
 * From Booking: money was received for a booking that can no longer be
 * confirmed (it had already failed, expired or been cancelled), so the payment
 * must be refunded. Consumed by
 * {@link com.forvmom.MomentForeverPayment.consumer.PaymentRefundRequestConsumer}.
 */
@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class PaymentRefundRequestedEvent {
    private String eventType = "PAYMENT_REFUND_REQUESTED";
    private String eventId;
    private String producer;
    private String correlationId;
    private String causationId;
    private Instant occurredAt;

    private String bookingId;
    /** Provider payment id to refund (Razorpay pay_..., Stripe PaymentIntent). */
    private String transactionId;
    private BigDecimal amount;
    private String currency;
    /** Booking status when the money arrived, e.g. FAILED or CANCELLED. */
    private String bookingStatus;
    /** Human-readable reason, stored on the refund and sent to the provider. */
    private String reason;
}
