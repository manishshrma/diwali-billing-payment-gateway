package com.forvmom.MomentForeverPayment.service;

/**
 * What the payment provider (Razorpay / Stripe) says about one payment link or
 * checkout session right now. The provider is the source of truth for money;
 * our database only mirrors it.
 *
 * @param kind          OPEN (can still be paid), PAID (money captured) or
 *                      CLOSED (expired/cancelled, can no longer be paid)
 * @param transactionId provider payment id when {@code kind == PAID}
 *                      (Razorpay {@code pay_...}, Stripe PaymentIntent id); may be null
 * @param detail        raw provider status, for logs and failure reasons
 */
public record ProviderPaymentState(Kind kind, String transactionId, String detail) {

    public enum Kind {
        OPEN,
        PAID,
        CLOSED
    }

    public static ProviderPaymentState open(String detail) {
        return new ProviderPaymentState(Kind.OPEN, null, detail);
    }

    public static ProviderPaymentState paid(String transactionId, String detail) {
        return new ProviderPaymentState(Kind.PAID, transactionId, detail);
    }

    public static ProviderPaymentState closed(String detail) {
        return new ProviderPaymentState(Kind.CLOSED, null, detail);
    }
}
