package com.forvmom.MomentForeverPayment.consumer;

import com.forvmom.MomentForeverPayment.events.BookingLifecycleEvent;
import com.forvmom.MomentForeverPayment.service.BookingClosureService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

import java.util.List;

/**
 * Listens to Booking's BOOKING_FAILED and BOOKING_CANCELLED events. When a
 * booking ends unpaid, its payment link is closed so the customer cannot pay
 * for a slot that was already released.
 *
 * <p>
 * The database mark is saved before the offset is acknowledged; the provider
 * call happens after, and is retried by the reconciliation job if it fails.
 * A cancelled booking that was already paid has no open link, so nothing
 * happens (refunds for cancelled paid bookings remain a manual decision).
 */
@Component
public class BookingLifecycleConsumer {

    private static final Logger log = LoggerFactory.getLogger(BookingLifecycleConsumer.class);

    private final BookingClosureService bookingClosureService;

    public BookingLifecycleConsumer(BookingClosureService bookingClosureService) {
        this.bookingClosureService = bookingClosureService;
    }

    @KafkaListener(
            topics = {"${kafka.topics.booking-failed}", "${kafka.topics.booking-cancelled}"},
            containerFactory = "bookingLifecycleListenerContainerFactory")
    public void onBookingClosed(@Payload(required = false) BookingLifecycleEvent event, Acknowledgment ack) {
        if (event == null || event.getBookingId() == null || event.getBookingId().isBlank()) {
            log.warn("Ignoring booking lifecycle event without bookingId: {}", event);
            ack.acknowledge();
            return;
        }
        String reason = firstText(event.getFailureReason(), event.getCancelReason(), event.getEventType());
        List<Long> openPayments = bookingClosureService.markCloseRequested(
                event.getBookingId(), "Booking " + event.getEventType() + ": " + reason);
        ack.acknowledge();
        bookingClosureService.closeLinks(openPayments);
    }

    private static String firstText(String... values) {
        for (String value : values) {
            if (value != null && !value.isBlank()) {
                return value;
            }
        }
        return "closed";
    }
}
