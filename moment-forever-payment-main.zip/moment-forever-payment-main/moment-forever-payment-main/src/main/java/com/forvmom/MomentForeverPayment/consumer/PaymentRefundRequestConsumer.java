package com.forvmom.MomentForeverPayment.consumer;

import com.forvmom.MomentForeverPayment.events.PaymentRefundRequestedEvent;
import com.forvmom.MomentForeverPayment.service.RefundService;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

/**
 * Listens to Booking's PAYMENT_REFUND_REQUESTED: money was received for a
 * booking that had already failed, expired or been cancelled. The refund is
 * recorded (and acknowledged) first; the provider call is retried by the
 * reconciliation job if the first attempt fails.
 */
@Component
public class PaymentRefundRequestConsumer {

    private final RefundService refundService;

    public PaymentRefundRequestConsumer(RefundService refundService) {
        this.refundService = refundService;
    }

    @KafkaListener(
            topics = "${kafka.topics.payment-refund-requested}",
            containerFactory = "refundRequestListenerContainerFactory")
    public void onRefundRequested(@Payload(required = false) PaymentRefundRequestedEvent event, Acknowledgment ack) {
        // recordRefundRequest commits before the provider call inside
        // onRefundRequested; an exception before that commit leaves the offset
        // unacknowledged so Kafka redelivers.
        refundService.onRefundRequested(event);
        ack.acknowledge();
    }
}
