package com.forvmom.MomentForeverPayment.service;

import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;
import com.forvmom.MomentForeverPayment.events.InboundPaymentEvent;
import com.forvmom.MomentForeverPayment.events.PaymentRequestedEvent;
import com.stripe.Stripe;
import com.stripe.exception.InvalidRequestException;
import com.stripe.exception.StripeException;
import com.stripe.model.PaymentIntent;
import com.stripe.model.Refund;
import com.stripe.model.RefundCollection;
import com.stripe.net.RequestOptions;
import com.stripe.model.checkout.Session;
import com.stripe.param.RefundCreateParams;
import com.stripe.param.RefundListParams;
import com.stripe.param.checkout.SessionCreateParams;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;

/**
 * Service dedicated to interacting with the Stripe API.
 * Responsible solely for translating our domain models into Stripe requests and capturing the response.
 * <p>
 * A declined card inside Stripe Checkout keeps the session open, so the customer
 * can retry with another card until {@code expires_at}.
 */
@Service
public class StripePaymentProcessor implements PaymentStrategy {

    private static final Logger log = LoggerFactory.getLogger(StripePaymentProcessor.class);

    @Value("${payment.gateway.api-key}")
    private String stripeApiKey;

    @Value("${payment.gateway.success-url:http://localhost:8082/payment/success?session_id={CHECKOUT_SESSION_ID}}")
    private String successUrl;

    @Value("${payment.gateway.cancel-url:http://localhost:8082/payment/cancel}")
    private String cancelUrl;

    private final PaymentWindowPolicy windowPolicy;

    public StripePaymentProcessor(PaymentWindowPolicy windowPolicy) {
        this.windowPolicy = windowPolicy;
    }

    @Override
    public Payment initiatePayment(InboundPaymentEvent inboundPaymentEvent) {
        ensureApiKey();

        Payment payment = new Payment();
        payment.setProvider("STRIPE");
        payment.setBookingId(inboundPaymentEvent.getBookingId());
        payment.setCorrelationId(inboundPaymentEvent.getCorrelationId());
        payment.setStatus(PaymentStatus.PENDING);

        Instant requestedDueAt = null;
        Instant anchor = null;
        if (inboundPaymentEvent instanceof PaymentRequestedEvent requestedEvent) {
            payment.setAmount(requestedEvent.getGrandTotal());
            payment.setCurrency(requestedEvent.getCurrency());
            requestedDueAt = requestedEvent.getPaymentDueAt();
            anchor = requestedEvent.getOccurredAt();
        }
        // Stripe replays an idempotent request only when every parameter is the
        // same. A retry of this event (crash after Stripe created the session) must
        // therefore send the same expires_at, so it is computed from the event's
        // own timestamp, not from "now".
        Instant expiresAt = windowPolicy.linkExpiry(requestedDueAt, PaymentProvider.STRIPE,
                anchor != null ? anchor : Instant.now());
        final Instant dueAt = requestedDueAt;

        try {
            // Build the line item for Stripe Checkout
            SessionCreateParams.LineItem lineItem = SessionCreateParams.LineItem.builder()
                    .setQuantity(1L)
                    .setPriceData(
                            SessionCreateParams.LineItem.PriceData.builder()
                                    .setCurrency(payment.getCurrency() != null ? payment.getCurrency().toLowerCase() : "usd")
                                    // Stripe unit_amount is also in the smallest currency sub-unit (cents for
                                    // USD). Round instead of truncate, for the same reason as Razorpay's
                                    // amountInSubUnits (see RazorpayPaymentProcessor) — avoids under-charging
                                    // by a fractional cent.
                                    .setUnitAmount(payment.getAmount() != null
                                            ? payment.getAmount().multiply(new BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact()
                                            : 5000L)
                                    .setProductData(
                                            SessionCreateParams.LineItem.PriceData.ProductData.builder()
                                                    .setName("Booking " + payment.getBookingId())
                                                    .build()
                                    )
                                    .build()
                    )
                    .build();

            Session session;
            try {
                session = Session.create(sessionParams(lineItem, payment.getBookingId(), expiresAt),
                        RequestOptions.builder().setIdempotencyKey(inboundPaymentEvent.getEventId()).build());
            } catch (InvalidRequestException e) {
                if (!"expires_at".equals(e.getParam())) {
                    throw e;
                }
                // The event is too old for its own expiry (Stripe needs >= 30 min
                // ahead). Stripe stores no idempotent result for a request that
                // fails validation, so no session exists under the original key and
                // a fresh expiry under a derived key cannot create a second one.
                expiresAt = windowPolicy.linkExpiry(dueAt, PaymentProvider.STRIPE, Instant.now());
                session = Session.create(sessionParams(lineItem, payment.getBookingId(), expiresAt),
                        RequestOptions.builder()
                                .setIdempotencyKey(inboundPaymentEvent.getEventId() + ":expires-" + expiresAt.getEpochSecond())
                                .build());
            }

            payment.setProviderSessionId(session.getId());
            payment.setPaymentUrl(session.getUrl());
            payment.setExpiresAt(PaymentWindowPolicy.toLocal(expiresAt));

            log.info("Created Stripe Checkout Session: {} for booking: {} (expires {})",
                    session.getId(), payment.getBookingId(), expiresAt);

        } catch (Exception e) {
            log.error("Failed to create Stripe Checkout Session", e);
            throw new IllegalStateException("Stripe Checkout Session creation failed", e);
        }

        return payment;
    }

    private SessionCreateParams sessionParams(SessionCreateParams.LineItem lineItem, String bookingId, Instant expiresAt) {
        return SessionCreateParams.builder()
                .setMode(SessionCreateParams.Mode.PAYMENT)
                .setSuccessUrl(successUrl)
                .setCancelUrl(cancelUrl)
                .addLineItem(lineItem)
                .setClientReferenceId(bookingId)
                // The booking's payment window (Stripe allows 30 min .. 24 h).
                .setExpiresAt(expiresAt.getEpochSecond())
                .build();
    }

    @Override
    public ProviderPaymentState fetchState(Payment payment) {
        ensureApiKey();
        String sessionId = requireSessionId(payment);
        try {
            Session session = Session.retrieve(sessionId);
            ProviderPaymentState state = toState(session);
            if (state.kind() == ProviderPaymentState.Kind.OPEN
                    && "complete".equals(session.getStatus())
                    && session.getPaymentIntent() != null) {
                // Completed checkout with an async method (e.g. bank debit) that
                // has not settled: only the PaymentIntent knows if it failed.
                String piStatus = PaymentIntent.retrieve(session.getPaymentIntent()).getStatus();
                if ("succeeded".equals(piStatus)) {
                    return ProviderPaymentState.paid(session.getPaymentIntent(), "complete/" + piStatus);
                }
                if (!"processing".equals(piStatus)) {
                    return ProviderPaymentState.closed("async_payment_failed/" + piStatus);
                }
            }
            return state;
        } catch (StripeException e) {
            throw new IllegalStateException("Could not fetch Stripe session " + sessionId + ": " + e.getMessage(), e);
        }
    }

    @Override
    public ProviderPaymentState cancel(Payment payment) {
        ensureApiKey();
        String sessionId = requireSessionId(payment);
        try {
            Session session = Session.retrieve(sessionId);
            if ("open".equals(session.getStatus())) {
                session = session.expire();
                log.info("Expired Stripe session {} for booking {}", sessionId, payment.getBookingId());
                ProviderPaymentState state = toState(session);
                if (state.kind() != ProviderPaymentState.Kind.OPEN) {
                    return state;
                }
            }
            // Not open (completed or async settling): re-check with full detail.
            ProviderPaymentState state = fetchState(payment);
            if (state.kind() == ProviderPaymentState.Kind.OPEN) {
                throw new IllegalStateException("Stripe session " + sessionId
                        + " cannot be closed yet (" + state.detail() + ")");
            }
            return state;
        } catch (StripeException e) {
            // Stripe refuses to expire a completed session; ask what happened.
            ProviderPaymentState state = fetchState(payment);
            if (state.kind() == ProviderPaymentState.Kind.OPEN) {
                throw new IllegalStateException("Could not expire Stripe session " + sessionId + ": " + e.getMessage(), e);
            }
            return state;
        }
    }

    @Override
    public String refund(Payment payment, String reason) {
        ensureApiKey();
        String paymentIntentId = payment.getTransactionId();
        if (paymentIntentId == null || paymentIntentId.isBlank()) {
            throw new IllegalStateException("Cannot refund booking " + payment.getBookingId()
                    + ": no Stripe PaymentIntent recorded");
        }
        try {
            // Never refund twice: reuse a refund created by an earlier attempt.
            RefundCollection existing = Refund.list(RefundListParams.builder()
                    .setPaymentIntent(paymentIntentId)
                    .setLimit(10L)
                    .build());
            if (existing != null && existing.getData() != null) {
                for (Refund refund : existing.getData()) {
                    String status = refund.getStatus();
                    if (!"failed".equalsIgnoreCase(status) && !"canceled".equalsIgnoreCase(status)) {
                        log.info("Stripe PaymentIntent {} already has refund {} ({}); not refunding again",
                                paymentIntentId, refund.getId(), status);
                        return refund.getId();
                    }
                }
            }

            RefundCreateParams params = RefundCreateParams.builder()
                    .setPaymentIntent(paymentIntentId)
                    .putMetadata("bookingId", payment.getBookingId() == null ? "" : payment.getBookingId())
                    .putMetadata("reason", reason == null ? "" : truncate(reason, 450))
                    .build();
            // One key per attempt: the same key within 24 h would replay the first
            // attempt's response, even if that refund later failed. Duplicates are
            // prevented by the existing-refund check above and the claim in RefundService.
            int attempt = payment.getRefundAttempts() == null ? 0 : payment.getRefundAttempts();
            RequestOptions options = RequestOptions.builder()
                    .setIdempotencyKey("refund-payment-" + payment.getId() + "-attempt-" + attempt)
                    .build();
            Refund refund = Refund.create(params, options);
            log.info("Stripe refund {} created for PaymentIntent {} (booking {})",
                    refund.getId(), paymentIntentId, payment.getBookingId());
            return refund.getId();
        } catch (StripeException e) {
            throw new IllegalStateException("Stripe refund failed for " + paymentIntentId + ": " + e.getMessage(), e);
        }
    }

    @Override
    public PaymentProvider getProvider() {
        return PaymentProvider.STRIPE;
    }

    /**
     * Session status: open, complete, expired. Payment status: paid, unpaid,
     * no_payment_required. complete + unpaid means an async method is still
     * settling, so it is treated as open.
     */
    static ProviderPaymentState toState(Session session) {
        String status = session.getStatus();
        String paymentStatus = session.getPaymentStatus();
        if ("complete".equals(status) && "paid".equals(paymentStatus)) {
            return ProviderPaymentState.paid(session.getPaymentIntent(), status + "/" + paymentStatus);
        }
        if ("expired".equals(status)) {
            return ProviderPaymentState.closed("expired");
        }
        return ProviderPaymentState.open(status + "/" + paymentStatus);
    }

    private void ensureApiKey() {
        if (stripeApiKey == null || stripeApiKey.isBlank()) {
            throw new IllegalStateException("PAYMENT_GATEWAY_API_KEY must be configured");
        }
        Stripe.apiKey = stripeApiKey;
    }

    private static String requireSessionId(Payment payment) {
        String sessionId = payment.getProviderSessionId();
        if (sessionId == null || sessionId.isBlank()) {
            throw new IllegalStateException("Payment " + payment.getId() + " has no Stripe session id");
        }
        return sessionId;
    }

    private static String truncate(String value, int max) {
        return value.length() <= max ? value : value.substring(0, max);
    }
}
