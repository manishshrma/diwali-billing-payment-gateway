package com.forvmom.MomentForeverPayment.service;

import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.events.InboundPaymentEvent;

/**
 * Interface for connecting to external payment gateways (e.g., Stripe, PayPal).
 * Follows the Single Responsibility Principle by only containing logic for external API calls.
 */
public interface PaymentStrategy {
    
    /**
     * Initiates a payment session with the provider. The link/session must be
     * created with an expiry (the booking's payment window) and the returned
     * Payment must carry it in {@code expiresAt}.
     *
     * @param inboundPaymentEvent The incoming request data from Kafka.
     * @return Payment entity populated with the provider's session ID, payment URL and expiry.
     */
    Payment initiatePayment(InboundPaymentEvent inboundPaymentEvent);

    /**
     * Asks the provider whether the link/session is still open, paid or closed.
     * Used by reconciliation so a lost webhook never leaves money or a booking
     * stuck.
     *
     * @throws IllegalStateException when the provider cannot be reached or
     *                               answers with an error (caller retries later)
     */
    ProviderPaymentState fetchState(Payment payment);

    /**
     * Stops the link/session from accepting money. If the provider refuses
     * because the link is already paid or closed, returns that state instead,
     * so a payment that slipped in at the last second is never lost.
     *
     * @return {@code CLOSED} when cancelled (or already closed), {@code PAID}
     *         when the customer paid first
     * @throws IllegalStateException when the link is still open and could not
     *                               be cancelled (caller retries later)
     */
    ProviderPaymentState cancel(Payment payment);

    /**
     * Refunds the full captured amount of {@code payment.transactionId}.
     * Must be safe to call again after an unknown outcome: if a refund already
     * exists for this payment, return its id instead of refunding twice.
     *
     * @return provider refund id
     * @throws IllegalStateException when the refund could not be created
     */
    String refund(Payment payment, String reason);

    /**
     * Declares the payment provider this strategy supports.
     *
     * @return provider enum (e.g., {@code PaymentProvider.STRIPE}).
     */
    PaymentProvider getProvider();

    /**
     * Declares the payment provider this strategy supports.
     *
     * @return Provider identifier (e.g., "STRIPE").
     */
    default String getSupportedPaymentType() {
        return getProvider().name();
    }
}
