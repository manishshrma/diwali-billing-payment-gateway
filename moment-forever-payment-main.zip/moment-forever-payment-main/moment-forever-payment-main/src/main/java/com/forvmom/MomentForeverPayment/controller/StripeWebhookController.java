package com.forvmom.MomentForeverPayment.controller;

import com.forvmom.MomentForeverPayment.service.PaymentOutcomeDispatcher;
import com.forvmom.MomentForeverPayment.service.PaymentOutcomeService;
import com.forvmom.MomentForeverPayment.service.WebhookProcessingService;
import com.stripe.model.Event;
import com.stripe.model.EventDataObjectDeserializer;
import com.stripe.model.checkout.Session;
import com.stripe.net.Webhook;
import io.swagger.v3.oas.annotations.Operation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Controller specifically for handling incoming Webhooks from Stripe.
 *
 * <p>
 * The Checkout Session events carry the result. A declined card inside
 * Checkout keeps the session open (the customer retries on the same page), so
 * {@code payment_intent.*} events are acknowledged without changing anything.
 */
@RestController
@RequestMapping("/webhooks/stripe")
public class StripeWebhookController {

    private static final Logger log = LoggerFactory.getLogger(StripeWebhookController.class);

    @Value("${payment.gateway.webhook-secret:}")
    private String endpointSecret;

    private final WebhookProcessingService webhookProcessingService;
    private final PaymentOutcomeDispatcher outcomeDispatcher;

    public StripeWebhookController(WebhookProcessingService webhookProcessingService,
                                   PaymentOutcomeDispatcher outcomeDispatcher) {
        this.webhookProcessingService = webhookProcessingService;
        this.outcomeDispatcher = outcomeDispatcher;
    }

    @PostMapping
    @Operation(summary = "Stripe webhook callback", security = {})
    public ResponseEntity<String> handleStripeWebhook(
            @RequestBody String payload,
            @RequestHeader("Stripe-Signature") String sigHeader) {

        Event event;
        try {
            if (endpointSecret.isBlank()) {
                log.error("Stripe webhook secret is not configured");
                return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE)
                        .body("Webhook endpoint is not configured");
            }
            event = Webhook.constructEvent(payload, sigHeader, endpointSecret);
        } catch (Exception e) {
            log.error("Webhook signature verification failed", e);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Signature Verification Failed");
        }

        PaymentOutcomeService.Outcome outcome = null;

        switch (event.getType()) {
            case "checkout.session.completed":
            case "checkout.session.async_payment_succeeded":
                outcome = handleCheckoutSessionPaid(event);
                break;
            case "checkout.session.expired":
                outcome = handleCheckoutSessionClosed(event,
                        "Payment window expired before the payment was completed - booking released",
                        "PAYMENT_LINK_EXPIRED");
                break;
            case "checkout.session.async_payment_failed":
                // The checkout finished but the delayed bank debit failed; this
                // session cannot be paid any more.
                outcome = handleCheckoutSessionClosed(event,
                        "Bank payment failed after checkout", "PAYMENT_FAILED");
                break;
            case "payment_intent.succeeded":
            case "payment_intent.payment_failed":
                // Session events above carry the outcome; a declined card here is
                // just one attempt and the session stays open for another try.
                log.info("Stripe {} acknowledged; session events decide the outcome", event.getType());
                break;
            default:
                log.info("Unhandled event type: {}", event.getType());
        }

        outcomeDispatcher.dispatch(outcome);

        // Return a 200 OK so Stripe knows we received the webhook successfully
        return ResponseEntity.ok("Success");
    }

    private PaymentOutcomeService.Outcome handleCheckoutSessionPaid(Event event) {
        Session session = deserializeSession(event);
        if (!"paid".equalsIgnoreCase(session.getPaymentStatus())) {
            log.info("Checkout session {} is not paid yet; waiting for an asynchronous result",
                    session.getId());
            return null;
        }
        log.info("Processing paid checkout session for Stripe Session ID: {}", session.getId());
        return webhookProcessingService.processLinkPaid(
                "STRIPE",
                event.getId(),
                session.getId(),
                session.getPaymentIntent(),
                session.getClientReferenceId());
    }

    private PaymentOutcomeService.Outcome handleCheckoutSessionClosed(Event event, String reason, String errorCode) {
        Session session = deserializeSession(event);
        log.info("Processing closed checkout session for Stripe Session ID: {} ({})", session.getId(), errorCode);
        return webhookProcessingService.processLinkClosed(
                "STRIPE",
                event.getId(),
                session.getId(),
                reason,
                errorCode);
    }

    private Session deserializeSession(Event event) {
        EventDataObjectDeserializer deserializer =
                event.getDataObjectDeserializer();

        log.info("Stripe Event ID: {}", event.getId());
        log.info("Stripe Event Type: {}", event.getType());
        log.info("Stripe API Version: {}", event.getApiVersion());
        log.info("Raw event data: {}", deserializer.getRawJson());

        if (deserializer.getObject().isPresent()) {
            Object stripeObject = deserializer.getObject().get();

            log.info("Deserialized object class: {}",
                    stripeObject.getClass().getName());

            log.info("Deserialized object: {}", stripeObject);

            if (stripeObject instanceof Session session) {
                return session;
            }

            log.error(
                    "Expected Session but got {}",
                    stripeObject.getClass().getName()
            );
        } else {
            log.error("Stripe SDK could not deserialize event data object");
        }

        throw new IllegalArgumentException(
                "Stripe event " + event.getId()
                        + " did not contain a compatible checkout session"
        );
    }
}
