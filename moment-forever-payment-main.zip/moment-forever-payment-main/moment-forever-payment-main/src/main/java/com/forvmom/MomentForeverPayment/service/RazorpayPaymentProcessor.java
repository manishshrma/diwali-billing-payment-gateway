package com.forvmom.MomentForeverPayment.service;

import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;
import com.forvmom.MomentForeverPayment.events.InboundPaymentEvent;
import com.forvmom.MomentForeverPayment.events.PaymentRequestedEvent;
import com.razorpay.PaymentLink;
import com.razorpay.RazorpayClient;
import com.razorpay.RazorpayException;
import com.razorpay.Refund;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.Instant;
import java.util.List;

/**
 * Service dedicated to interacting with the Razorpay API.
 * Mirrors {@link StripePaymentProcessor}'s responsibilities: translate our domain models
 * into Razorpay requests and capture the hosted payment page details.
 * <p>
 * Razorpay has no direct equivalent of a Stripe Checkout Session, so this uses the
 * Razorpay "Payment Links" API, which also returns a single hosted payment page URL
 * and supports webhook-based completion/expiry notifications - the closest match to
 * how the rest of this service (Payment entity, webhook processing) already works.
 * <p>
 * One link per booking: a declined attempt does not close the link, so the
 * customer retries with another method (UPI, another card, netbanking) on the
 * same page until {@code expire_by}.
 */
@Service
public class RazorpayPaymentProcessor implements PaymentStrategy {

    private static final Logger log = LoggerFactory.getLogger(RazorpayPaymentProcessor.class);

    @Value("${payment.gateway.razorpay.key-id:}")
    private String razorpayKeyId;

    @Value("${payment.gateway.razorpay.key-secret:}")
    private String razorpayKeySecret;

    @Value("${payment.gateway.razorpay.callback-url:http://localhost:8082/payment/success}")
    private String callbackUrl;

    private final PaymentWindowPolicy windowPolicy;

    public RazorpayPaymentProcessor(PaymentWindowPolicy windowPolicy) {
        this.windowPolicy = windowPolicy;
    }

    @Override
    public Payment initiatePayment(InboundPaymentEvent inboundPaymentEvent) {
        Payment payment = new Payment();
        payment.setProvider("RAZORPAY");
        payment.setBookingId(inboundPaymentEvent.getBookingId());
        payment.setCorrelationId(inboundPaymentEvent.getCorrelationId());
        payment.setStatus(PaymentStatus.PENDING);

        Instant requestedDueAt = null;
        if (inboundPaymentEvent instanceof PaymentRequestedEvent requestedEvent) {
            payment.setAmount(requestedEvent.getGrandTotal());
            payment.setCurrency(requestedEvent.getCurrency());
            requestedDueAt = requestedEvent.getPaymentDueAt();
        }
        Instant expiresAt = windowPolicy.linkExpiry(requestedDueAt, PaymentProvider.RAZORPAY, Instant.now());

        try {
            RazorpayClient razorpayClient = client();

            // Razorpay Payment Links primarily support INR (India/Malaysia/Singapore
            // merchant accounts); default to INR when the event didn't carry a currency.
            String currency = payment.getCurrency() != null ? payment.getCurrency().toUpperCase() : "INR";
            // Razorpay amounts are expressed in the smallest currency sub-unit (e.g. paise for INR).
            // Round (not truncate) to the nearest sub-unit: a plain .longValue() silently drops
            // any fractional paise (e.g. 149.995 -> 14999 instead of 15000), which would make the
            // amount the customer is charged a few paise less than the quoted price.
            long amountInSubUnits = payment.getAmount() != null
                    ? payment.getAmount().multiply(new BigDecimal(100)).setScale(0, RoundingMode.HALF_UP).longValueExact()
                    : 5000L;

            JSONObject paymentLinkRequest = new JSONObject();
            paymentLinkRequest.put("amount", amountInSubUnits);
            paymentLinkRequest.put("currency", currency);
            paymentLinkRequest.put("description", "Booking " + payment.getBookingId());
            paymentLinkRequest.put("reference_id", payment.getBookingId());
            paymentLinkRequest.put("callback_url", callbackUrl);
            paymentLinkRequest.put("callback_method", "get");
            // The booking's payment window: after this Razorpay stops accepting money
            // and sends payment_link.expired. Without it a link stayed payable forever.
            paymentLinkRequest.put("expire_by", expiresAt.getEpochSecond());

            // Payment Links have no client-supplied idempotency key parameter, unlike
            // Stripe Checkout Sessions. Duplicate-request protection is already handled
            // upstream by PaymentOutboxService's inbox/outbox tables, so we only stash
            // the Kafka event id in notes for traceability when inspecting the Razorpay
            // dashboard.
            JSONObject notes = new JSONObject();
            notes.put("eventId", inboundPaymentEvent.getEventId());
            // payment.failed / payment.captured webhooks carry only payload.payment.entity
            // (no payment_link). Stash booking correlation here so the webhook handler can
            // map them back to the internal Payment without an extra Razorpay API call.
            notes.put("bookingId", payment.getBookingId());
            if (payment.getCorrelationId() != null) {
                notes.put("correlationId", payment.getCorrelationId());
            }
            paymentLinkRequest.put("notes", notes);

            PaymentLink paymentLink = razorpayClient.paymentLink.create(paymentLinkRequest);
            String paymentLinkId = paymentLink.get("id");
            String shortUrl = paymentLink.get("short_url");

            payment.setProviderSessionId(paymentLinkId);
            payment.setPaymentUrl(shortUrl);
            payment.setExpiresAt(PaymentWindowPolicy.toLocal(expiresAt));

            log.info("Created Razorpay Payment Link: {} for booking: {} (expires {})",
                    paymentLinkId, payment.getBookingId(), expiresAt);

        } catch (RazorpayException e) {
            log.error("Failed to create Razorpay Payment Link", e);
            throw new IllegalStateException("Razorpay Payment Link creation failed", e);
        }

        return payment;
    }

    @Override
    public ProviderPaymentState fetchState(Payment payment) {
        String linkId = requireLinkId(payment);
        try {
            JSONObject link = client().paymentLink.fetch(linkId).toJson();
            return toState(link);
        } catch (RazorpayException e) {
            throw new IllegalStateException("Could not fetch Razorpay payment link " + linkId + ": " + e.getMessage(), e);
        }
    }

    @Override
    public ProviderPaymentState cancel(Payment payment) {
        String linkId = requireLinkId(payment);
        try {
            JSONObject link = client().paymentLink.cancel(linkId).toJson();
            log.info("Cancelled Razorpay payment link {} for booking {}", linkId, payment.getBookingId());
            ProviderPaymentState state = toState(link);
            return state.kind() == ProviderPaymentState.Kind.OPEN
                    ? ProviderPaymentState.closed("cancelled")
                    : state;
        } catch (RazorpayException e) {
            // Razorpay refuses to cancel a link that is already paid, expired or
            // cancelled. Ask what happened instead of guessing.
            log.info("Razorpay refused to cancel link {} ({}); checking its state", linkId, e.getMessage());
            ProviderPaymentState state = fetchState(payment);
            if (state.kind() == ProviderPaymentState.Kind.OPEN) {
                throw new IllegalStateException("Could not cancel Razorpay payment link " + linkId
                        + ": " + e.getMessage(), e);
            }
            return state;
        }
    }

    @Override
    public String refund(Payment payment, String reason) {
        String paymentId = payment.getTransactionId();
        if (paymentId == null || paymentId.isBlank()) {
            throw new IllegalStateException("Cannot refund booking " + payment.getBookingId()
                    + ": no Razorpay payment id recorded");
        }
        try {
            RazorpayClient razorpayClient = client();
            // Never refund twice: if an earlier attempt succeeded but we lost the
            // answer (crash, timeout), Razorpay already has the refund.
            List<Refund> existing = razorpayClient.payments.fetchAllRefunds(paymentId);
            if (existing != null) {
                for (Refund refund : existing) {
                    JSONObject json = refund.toJson();
                    if (!"failed".equalsIgnoreCase(json.optString("status", ""))) {
                        log.info("Razorpay payment {} already has refund {} ({}); not refunding again",
                                paymentId, json.optString("id"), json.optString("status"));
                        return json.optString("id");
                    }
                }
            }

            JSONObject request = new JSONObject();
            request.put("speed", "normal");
            JSONObject notes = new JSONObject();
            notes.put("bookingId", truncate(payment.getBookingId(), 250));
            notes.put("reason", truncate(reason, 250));
            request.put("notes", notes);
            request.put("receipt", truncate("refund-" + payment.getId(), 40));

            Refund refund = razorpayClient.payments.refund(paymentId, request);
            String refundId = refund.toJson().optString("id");
            log.info("Razorpay refund {} created for payment {} (booking {})",
                    refundId, paymentId, payment.getBookingId());
            return refundId;
        } catch (RazorpayException e) {
            throw new IllegalStateException("Razorpay refund failed for payment " + paymentId + ": " + e.getMessage(), e);
        }
    }

    @Override
    public PaymentProvider getProvider() {
        return PaymentProvider.RAZORPAY;
    }

    /** Overridable in tests. */
    protected RazorpayClient client() throws RazorpayException {
        if (razorpayKeyId.isBlank() || razorpayKeySecret.isBlank()) {
            throw new IllegalStateException("RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET must be configured");
        }
        return new RazorpayClient(razorpayKeyId, razorpayKeySecret);
    }

    /**
     * Razorpay link statuses: created, partially_paid, paid, expired, cancelled.
     */
    static ProviderPaymentState toState(JSONObject link) {
        String status = link.optString("status", "");
        switch (status) {
            case "paid":
                return ProviderPaymentState.paid(capturedPaymentId(link), status);
            case "expired":
            case "cancelled":
                return ProviderPaymentState.closed(status);
            default:
                return ProviderPaymentState.open(status);
        }
    }

    /**
     * Picks the captured payment from the link's {@code payments} list. Returns
     * null rather than guessing: a declined attempt's id recorded as the paid one
     * would later make the real payment look like a second charge. A null id is
     * filled in when the payment webhook arrives.
     */
    static String capturedPaymentId(JSONObject link) {
        JSONArray payments = link.optJSONArray("payments");
        if (payments == null) {
            return null;
        }
        for (int i = 0; i < payments.length(); i++) {
            JSONObject entry = payments.optJSONObject(i);
            if (entry == null) {
                continue;
            }
            String id = entry.optString("payment_id", entry.optString("id", ""));
            if (!id.isBlank() && "captured".equalsIgnoreCase(entry.optString("status", ""))) {
                return id;
            }
        }
        return null;
    }

    private static String requireLinkId(Payment payment) {
        String linkId = payment.getProviderSessionId();
        if (linkId == null || linkId.isBlank()) {
            throw new IllegalStateException("Payment " + payment.getId() + " has no Razorpay link id");
        }
        return linkId;
    }

    private static String truncate(String value, int max) {
        if (value == null) {
            return "";
        }
        return value.length() <= max ? value : value.substring(0, max);
    }
}
