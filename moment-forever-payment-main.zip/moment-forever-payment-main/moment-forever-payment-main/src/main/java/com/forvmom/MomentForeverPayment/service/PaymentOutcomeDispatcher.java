package com.forvmom.MomentForeverPayment.service;

import com.forvmom.MomentForeverPayment.scheduler.OutgoingPaymentPublisher;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

/**
 * Carries out a {@link PaymentOutcomeService.Outcome} after its transaction
 * committed: publish the event to Booking and/or execute the refund. Both are
 * backed by durable rows (outbox, refund status), so a failure here is retried
 * by the Quartz jobs and never loses work.
 */
@Component
public class PaymentOutcomeDispatcher {

    private static final Logger log = LoggerFactory.getLogger(PaymentOutcomeDispatcher.class);

    private final OutgoingPaymentPublisher outgoingPaymentPublisher;
    private final RefundService refundService;

    public PaymentOutcomeDispatcher(OutgoingPaymentPublisher outgoingPaymentPublisher,
                                    RefundService refundService) {
        this.outgoingPaymentPublisher = outgoingPaymentPublisher;
        this.refundService = refundService;
    }

    public void dispatch(PaymentOutcomeService.Outcome outcome) {
        if (outcome == null) {
            return;
        }
        if (outcome.outgoing() != null) {
            outgoingPaymentPublisher.trySinglePublish(outcome.outgoing());
        }
        if (outcome.refundPaymentId() != null) {
            try {
                refundService.executeRefund(outcome.refundPaymentId());
            } catch (Exception e) {
                log.error("Immediate refund attempt crashed for payment {}; the job will retry",
                        outcome.refundPaymentId(), e);
            }
        }
    }
}
