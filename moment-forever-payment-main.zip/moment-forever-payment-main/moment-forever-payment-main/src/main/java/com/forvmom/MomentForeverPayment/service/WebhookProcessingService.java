package com.forvmom.MomentForeverPayment.service;

import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;
import com.forvmom.MomentForeverPayment.domain.entity.WebhookInbox;
import com.forvmom.MomentForeverPayment.repository.PaymentRepository;
import com.forvmom.MomentForeverPayment.repository.WebhookInboxRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

/**
 * Turns verified provider webhooks into payment outcomes, idempotently.
 *
 * <p>
 * Each method runs in one transaction: record the webhook id (so a redelivery
 * is ignored), lock all payment rows of the booking, then let
 * {@link PaymentOutcomeService} decide. The returned
 * {@link PaymentOutcomeService.Outcome} tells the caller what to publish or
 * refund after commit. If anything throws, the whole transaction (including the
 * webhook id) rolls back and the provider redelivers the webhook later.
 *
 * <p>
 * Rows are never loaded before the lock is taken (only the booking id is read),
 * so decisions are made on fresh data and every path locks rows in the same
 * order.
 */
@Service
public class WebhookProcessingService {

    private static final Logger log = LoggerFactory.getLogger(WebhookProcessingService.class);

    private final WebhookInboxRepository webhookInboxRepository;
    private final PaymentRepository paymentRepository;
    private final PaymentOutcomeService outcomeService;
    private final AlertService alertService;

    public WebhookProcessingService(
            WebhookInboxRepository webhookInboxRepository,
            PaymentRepository paymentRepository,
            PaymentOutcomeService outcomeService,
            AlertService alertService) {
        this.webhookInboxRepository = webhookInboxRepository;
        this.paymentRepository = paymentRepository;
        this.outcomeService = outcomeService;
        this.alertService = alertService;
    }

    /**
     * The link/session was paid (Razorpay {@code payment_link.paid}, Stripe
     * {@code checkout.session.completed} with payment_status=paid).
     *
     * @param fallbackBookingId booking id from the provider payload, used when no
     *                          row exists for the link (the link was created but
     *                          our row was never saved); may be null
     */
    @Transactional
    public PaymentOutcomeService.Outcome processLinkPaid(
            String provider,
            String webhookEventId,
            String providerSessionId,
            String transactionId,
            String fallbackBookingId) {
        if (!registerWebhook(webhookEventId, provider)) {
            return PaymentOutcomeService.Outcome.none();
        }
        Optional<String> bookingId = paymentRepository.findBookingIdByProviderSessionId(providerSessionId);
        if (bookingId.isEmpty()) {
            if (hasText(fallbackBookingId)) {
                log.warn("Paid {} link {} has no payment row; recording it under booking {}",
                        provider, providerSessionId, fallbackBookingId);
                return capturedForBooking(provider, fallbackBookingId, transactionId, null, null, "WEBHOOK_PAID");
            }
            // Throwing rolls back the inbox row so the provider retries; by then the
            // row may exist. Never ack a payment we could not record.
            throw new IllegalArgumentException("Unknown providerSessionId: " + providerSessionId);
        }
        List<Payment> rows = paymentRepository.lockAllByBookingId(bookingId.get());
        Payment row = findBySession(rows, providerSessionId);
        return outcomeService.applySuccess(row, rows, transactionId, "WEBHOOK_PAID");
    }

    /**
     * The link/session can no longer be paid (Razorpay
     * {@code payment_link.expired}/{@code payment_link.cancelled}, Stripe
     * {@code checkout.session.expired}/{@code async_payment_failed}).
     */
    @Transactional
    public PaymentOutcomeService.Outcome processLinkClosed(
            String provider,
            String webhookEventId,
            String providerSessionId,
            String failureReason,
            String errorCode) {
        if (!registerWebhook(webhookEventId, provider)) {
            return PaymentOutcomeService.Outcome.none();
        }
        Optional<String> bookingId = paymentRepository.findBookingIdByProviderSessionId(providerSessionId);
        if (bookingId.isEmpty()) {
            log.warn("{} reported closed link {} that has no payment row; nothing to do", provider, providerSessionId);
            return PaymentOutcomeService.Outcome.none();
        }
        List<Payment> rows = paymentRepository.lockAllByBookingId(bookingId.get());
        Payment row = findBySession(rows, providerSessionId);
        return outcomeService.applyClosed(row, rows, failureReason, errorCode, "WEBHOOK_CLOSED");
    }

    /**
     * One declined attempt (Razorpay {@code payment.failed}: card declined, bank
     * down, UPI failure). The link stays payable and Booking is not told, so the
     * customer can retry with another method on the same page.
     *
     * @param providerSessionId link id when the payload carries it, else null
     * @param bookingId         booking id from payment notes, used when the link
     *                          id is not in the payload
     */
    @Transactional
    public void processAttemptFailure(
            String provider,
            String webhookEventId,
            String providerSessionId,
            String bookingId,
            String failureReason,
            String errorCode) {
        if (!registerWebhook(webhookEventId, provider)) {
            return;
        }
        String resolvedBookingId = hasText(providerSessionId)
                ? paymentRepository.findBookingIdByProviderSessionId(providerSessionId).orElse(bookingId)
                : bookingId;
        if (!hasText(resolvedBookingId)) {
            log.warn("Declined attempt (event {}) could not be matched to a booking; ignoring", webhookEventId);
            return;
        }
        List<Payment> rows = paymentRepository.lockAllByBookingId(resolvedBookingId);
        Payment target = null;
        if (hasText(providerSessionId)) {
            target = rows.stream()
                    .filter(p -> providerSessionId.equals(p.getProviderSessionId()))
                    .findFirst().orElse(null);
        }
        if (target == null) {
            target = rows.stream() // rows are newest first
                    .filter(p -> p.getStatus() == PaymentStatus.PENDING)
                    .findFirst().orElse(null);
        }
        if (target == null) {
            log.info("Declined attempt for booking {} has no open payment; ignoring", resolvedBookingId);
            return;
        }
        outcomeService.applyAttemptFailure(target, failureReason, errorCode);
    }

    /**
     * The provider captured money identified only by booking id (Razorpay
     * {@code payment.captured}, which has no payment_link in its payload). This
     * is the safety net for money that arrives after a link was closed.
     *
     * @param amount   captured amount in major units (may be null)
     * @param currency captured currency (may be null)
     */
    @Transactional
    public PaymentOutcomeService.Outcome processCapturedPayment(
            String provider,
            String webhookEventId,
            String bookingId,
            String transactionId,
            BigDecimal amount,
            String currency) {
        if (!registerWebhook(webhookEventId, provider)) {
            return PaymentOutcomeService.Outcome.none();
        }
        return capturedForBooking(provider, bookingId, transactionId, amount, currency, "WEBHOOK_CAPTURED");
    }

    private PaymentOutcomeService.Outcome capturedForBooking(
            String provider,
            String bookingId,
            String transactionId,
            BigDecimal amount,
            String currency,
            String source) {
        List<Payment> rows = new ArrayList<>(paymentRepository.lockAllByBookingId(bookingId));

        Payment target = null;
        if (hasText(transactionId)) {
            target = rows.stream()
                    .filter(p -> transactionId.equals(p.getTransactionId()))
                    .findFirst().orElse(null);
        }
        if (target == null) {
            target = rows.stream() // newest first
                    .filter(p -> p.getStatus() == PaymentStatus.PENDING)
                    .findFirst().orElse(null);
        }
        if (target == null) {
            // A closed link row. Any transaction id on a FAILED row is a declined
            // attempt (older code stored it), never captured money.
            target = rows.stream()
                    .filter(p -> p.getStatus() == PaymentStatus.FAILED && p.getProviderSessionId() != null)
                    .findFirst().orElse(null);
        }
        if (target == null) {
            // No open or closed link row to attach the money to: record it on its own row.
            Payment orphan = new Payment();
            orphan.setProvider(provider);
            orphan.setBookingId(bookingId);
            orphan.setStatus(PaymentStatus.PENDING);
            orphan.setAmount(amount != null ? amount : rows.stream()
                    .map(Payment::getAmount).filter(Objects::nonNull).findFirst().orElse(null));
            orphan.setCurrency(currency != null ? currency : rows.stream()
                    .map(Payment::getCurrency).filter(Objects::nonNull).findFirst().orElse(null));
            orphan.setCorrelationId(rows.stream()
                    .map(Payment::getCorrelationId).filter(Objects::nonNull).findFirst().orElse(bookingId));
            target = paymentRepository.save(orphan);
            rows.add(target);
            alertService.sendAlert(String.format(
                    "%s payment %s for booking %s had no matching payment link; recorded separately",
                    provider, transactionId, bookingId));
        }
        return outcomeService.applySuccess(target, rows, transactionId, source);
    }

    /** @return false when this webhook id was already processed */
    private boolean registerWebhook(String webhookEventId, String provider) {
        if (webhookInboxRepository.existsByEventId(webhookEventId)) {
            log.info("Webhook event {} already processed. Ignoring.", webhookEventId);
            return false;
        }
        WebhookInbox inbox = new WebhookInbox();
        inbox.setEventId(webhookEventId);
        inbox.setProvider(provider);
        inbox.setStatus("PROCESSED");
        webhookInboxRepository.save(inbox);
        return true;
    }

    private static Payment findBySession(List<Payment> rows, String providerSessionId) {
        return rows.stream()
                .filter(p -> providerSessionId.equals(p.getProviderSessionId()))
                .findFirst()
                .orElseThrow(() -> new IllegalStateException(
                        "Payment row for " + providerSessionId + " disappeared while locking"));
    }

    private static boolean hasText(String value) {
        return value != null && !value.isBlank();
    }
}
