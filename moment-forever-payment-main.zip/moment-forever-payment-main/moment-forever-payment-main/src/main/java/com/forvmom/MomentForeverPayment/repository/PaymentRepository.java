package com.forvmom.MomentForeverPayment.repository;

import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;
import jakarta.persistence.LockModeType;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface PaymentRepository extends JpaRepository<Payment, Long>, JpaSpecificationExecutor<Payment> {
    Optional<Payment> findByProviderSessionId(String providerSessionId);

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT p FROM Payment p WHERE p.providerSessionId = :providerSessionId")
    Optional<Payment> findByProviderSessionIdForUpdate(
            @Param("providerSessionId") String providerSessionId);

    Optional<Payment> findByTransactionId(String transactionId);

    Optional<Payment> findFirstByBookingIdOrderByIdDesc(String bookingId);

    Optional<Payment> findFirstByCorrelationIdOrderByIdDesc(String correlationId);

    // ─── Read/query APIs ─────────────────────────────────────────────
    // Derived finders (no @Query with nullable guards — same 42P18 reason
    // as booking-service: null binds break PostgreSQL type resolution).

    List<Payment> findAllByBookingIdOrderByIdDesc(String bookingId);

    Page<Payment> findAllByBookingId(String bookingId, Pageable pageable);

    Page<Payment> findAllByStatus(PaymentStatus status, Pageable pageable);

    boolean existsByBookingId(String bookingId);

    // ─── Payment outcome / reconciliation / refunds ──────────────────
    // Every bound parameter below is non-null (see the 42P18 note above).

    /**
     * Locks every payment row of a booking. All outcome decisions (paid,
     * closed, refund) take this lock first, so two webhooks or a webhook and
     * the reconciliation job can never decide differently for one booking.
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("SELECT p FROM Payment p WHERE p.bookingId = :bookingId ORDER BY p.id DESC")
    List<Payment> lockAllByBookingId(@Param("bookingId") String bookingId);

    Optional<Payment> findFirstByTransactionIdOrderByIdDesc(String transactionId);

    /**
     * Reads only the booking id for a link, without loading the row into the
     * persistence context, so the following {@link #lockAllByBookingId} returns
     * fresh (not cached) row state.
     */
    @Query("SELECT p.bookingId FROM Payment p WHERE p.providerSessionId = :providerSessionId")
    List<String> findBookingIdsByProviderSessionId(@Param("providerSessionId") String providerSessionId);

    default Optional<String> findBookingIdByProviderSessionId(String providerSessionId) {
        if (providerSessionId == null || providerSessionId.isBlank()) {
            return Optional.empty();
        }
        return findBookingIdsByProviderSessionId(providerSessionId).stream()
                .filter(id -> id != null && !id.isBlank())
                .findFirst();
    }

    Optional<Payment> findFirstByBookingIdAndStatusOrderByIdDesc(String bookingId, PaymentStatus status);

    /**
     * PENDING rows that need a provider check: the booking was closed, the
     * payment window has passed, or (legacy rows with no expiry) the row is
     * older than the default hold window. Rows checked recently are skipped.
     */
    @Query("""
            SELECT p FROM Payment p
            WHERE p.status = :pending
              AND p.providerSessionId IS NOT NULL
              AND (p.lastReconciledAt IS NULL OR p.lastReconciledAt < :recheckBefore)
              AND (p.closeRequestedAt IS NOT NULL
                   OR p.expiresAt < :expiredBefore
                   OR (p.expiresAt IS NULL AND p.createdAt < :legacyCreatedBefore))
            ORDER BY p.id
            """)
    List<Payment> findPendingDueForReconciliation(
            @Param("pending") PaymentStatus pending,
            @Param("recheckBefore") LocalDateTime recheckBefore,
            @Param("expiredBefore") LocalDateTime expiredBefore,
            @Param("legacyCreatedBefore") LocalDateTime legacyCreatedBefore,
            Pageable pageable);

    /**
     * FAILED rows never checked against the provider. Before this fix a
     * declined card marked the row FAILED while its link stayed payable; these
     * links are checked once and closed (or their late payment is recovered).
     */
    @Query("""
            SELECT p FROM Payment p
            WHERE p.status = :failed
              AND p.providerSessionId IS NOT NULL
              AND p.lastReconciledAt IS NULL
            ORDER BY p.id
            """)
    List<Payment> findFailedNeverReconciled(@Param("failed") PaymentStatus failed, Pageable pageable);

    /** Refunds waiting for a worker, plus claims abandoned by a crashed worker. */
    @Query("""
            SELECT p FROM Payment p
            WHERE p.refundStatus = :requested
               OR (p.refundStatus = :inProgress AND p.refundClaimedAt < :staleBefore)
            ORDER BY p.id
            """)
    List<Payment> findRefundsToProcess(
            @Param("requested") String requested,
            @Param("inProgress") String inProgress,
            @Param("staleBefore") LocalDateTime staleBefore,
            Pageable pageable);

    /**
     * Atomically claims a refund for one worker. Returns 1 when this caller
     * won the claim, 0 when another worker owns it or it is already done.
     */
    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("""
            UPDATE Payment p
            SET p.refundStatus = :inProgress,
                p.refundClaimedAt = :now,
                p.refundAttempts = COALESCE(p.refundAttempts, 0) + 1,
                p.updatedAt = :now
            WHERE p.id = :id
              AND (p.refundStatus = :requested
                   OR (p.refundStatus = :inProgress AND p.refundClaimedAt < :staleBefore))
            """)
    int claimRefund(
            @Param("id") Long id,
            @Param("requested") String requested,
            @Param("inProgress") String inProgress,
            @Param("now") LocalDateTime now,
            @Param("staleBefore") LocalDateTime staleBefore);

    Page<Payment> findAllByRefundStatus(String refundStatus, Pageable pageable);

    // ─── Targeted updates ────────────────────────────────────────────
    // Used where the row is NOT locked: they change only their own columns, so
    // they can never overwrite a payment outcome committed at the same moment
    // (a load-then-save would write back stale status/transaction id).

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("UPDATE Payment p SET p.lastReconciledAt = :now WHERE p.id = :id")
    int markReconciled(@Param("id") Long id, @Param("now") LocalDateTime now);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("""
            UPDATE Payment p
            SET p.refundStatus = :refunded,
                p.refundId = :refundId,
                p.refundedAt = :now,
                p.refundLastError = NULL,
                p.updatedAt = :now
            WHERE p.id = :id AND p.refundStatus = :inProgress
            """)
    int markRefunded(
            @Param("id") Long id,
            @Param("refunded") String refunded,
            @Param("inProgress") String inProgress,
            @Param("refundId") String refundId,
            @Param("now") LocalDateTime now);

    @Modifying(clearAutomatically = true, flushAutomatically = true)
    @Query("""
            UPDATE Payment p
            SET p.refundStatus = :nextStatus,
                p.refundLastError = :error,
                p.updatedAt = :now
            WHERE p.id = :id AND p.refundStatus = :inProgress
            """)
    int markRefundAttemptFailed(
            @Param("id") Long id,
            @Param("nextStatus") String nextStatus,
            @Param("inProgress") String inProgress,
            @Param("error") String error,
            @Param("now") LocalDateTime now);
}
