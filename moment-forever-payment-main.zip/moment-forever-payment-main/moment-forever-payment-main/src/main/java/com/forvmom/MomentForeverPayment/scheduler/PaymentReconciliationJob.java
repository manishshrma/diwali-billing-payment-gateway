package com.forvmom.MomentForeverPayment.scheduler;

import com.forvmom.MomentForeverPayment.service.PaymentReconciliationService;
import com.forvmom.MomentForeverPayment.service.RefundService;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Every few minutes: settles payments whose window has passed or whose booking
 * was closed (asking the provider, never guessing), then retries refunds that
 * have not gone through yet. Runs on one pod at a time (JDBC Quartz).
 */
@Component
@DisallowConcurrentExecution
public class PaymentReconciliationJob implements Job {

    private static final Logger log = LoggerFactory.getLogger(PaymentReconciliationJob.class);

    @Autowired
    private PaymentReconciliationService reconciliationService;

    @Autowired
    private RefundService refundService;

    @Override
    public void execute(JobExecutionContext context) throws JobExecutionException {
        try {
            reconciliationService.runOnce();
        } catch (Exception e) {
            log.error("Payment reconciliation pass failed", e);
        }
        try {
            refundService.retryPendingRefunds();
        } catch (Exception e) {
            log.error("Refund retry pass failed", e);
            throw new JobExecutionException("Payment reconciliation job failed", e);
        }
    }
}
