package com.forvmom.MomentForeverPayment.domain.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Data
@Table(name = "payment")
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "provider")
    private String provider;

    @Column(name = "provider_session_id")
    private String providerSessionId;

    @Column(name = "payment_url", length = 1000)
    private String paymentUrl;

    @Column(name = "amount")
    private BigDecimal amount;

    @Column(name = "currency")
    private String currency;

    @Column(name = "transaction_id")
    private String transactionId;

    @Column(name = "booking_id")
    private String bookingId;

    @Column(name = "correlation_id")
    private String correlationId;

    @Enumerated(EnumType.STRING)
    @Column(name = "status")
    private PaymentStatus status;

    // ── Payment window ────────────────────────────────────────────────────
    // When the provider link/session stops accepting money. null = created
    // before expiry existed (legacy row); reconciliation treats it as
    // createdAt + the default hold window.
    @Column(name = "expires_at")
    private LocalDateTime expiresAt;

    // ── Declined attempts (card declined, bank down, UPI failure) ────────
    // A decline does NOT fail the payment: the customer can try another
    // method on the same link until it expires. We only remember the last
    // reason so the UI can show it.
    @Column(name = "failed_attempts")
    private Integer failedAttempts;

    @Column(name = "last_failure_reason", length = 500)
    private String lastFailureReason;

    @Column(name = "last_error_code", length = 100)
    private String lastErrorCode;

    // ── Booking closed while this link was still open ─────────────────────
    // Set when Booking reports the booking failed/expired/cancelled. The link
    // must then be cancelled at the provider so nobody can pay it.
    @Column(name = "close_requested_at")
    private LocalDateTime closeRequestedAt;

    @Column(name = "close_reason", length = 500)
    private String closeReason;

    /** Last time reconciliation asked the provider about this row. */
    @Column(name = "last_reconciled_at")
    private LocalDateTime lastReconciledAt;

    // ── Automatic refund (money received that cannot be kept) ────────────
    /** See {@link RefundStatus}; null = no refund needed. */
    @Column(name = "refund_status", length = 20)
    private String refundStatus;

    @Column(name = "refund_reason", length = 500)
    private String refundReason;

    @Column(name = "refund_id")
    private String refundId;

    @Column(name = "refund_attempts")
    private Integer refundAttempts;

    @Column(name = "refund_requested_at")
    private LocalDateTime refundRequestedAt;

    @Column(name = "refund_claimed_at")
    private LocalDateTime refundClaimedAt;

    @Column(name = "refunded_at")
    private LocalDateTime refundedAt;

    @Column(name = "refund_last_error", length = 500)
    private String refundLastError;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        this.updatedAt = this.createdAt;
    }

    @PreUpdate
    protected void onUpdate() {
        this.updatedAt = LocalDateTime.now();
    }
}
