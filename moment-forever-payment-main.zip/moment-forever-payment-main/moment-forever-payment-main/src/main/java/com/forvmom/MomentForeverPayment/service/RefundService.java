package com.forvmom.MomentForeverPayment.service;

import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;
import com.forvmom.MomentForeverPayment.domain.entity.RefundStatus;
import com.forvmom.MomentForeverPayment.domain.entity.WebhookInbox;
import com.forvmom.MomentForeverPayment.events.PaymentRefundRequestedEvent;
import com.forvmom.MomentForeverPayment.repository.PaymentRepository;
import com.forvmom.MomentForeverPayment.repository.WebhookInboxRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.support.TransactionTemplate;

import java.time.LocalDateTime;
import java.util.List;

/**
 * Automatic refunds for money we cannot keep (Option A).
 *
 * <p>
 * Two ways a refund is requested:
 * <ul>
 * <li>Booking sends PAYMENT_REFUND_REQUESTED: money arrived for a booking that
 * had already failed, expired or been cancelled.</li>
 * <li>{@link PaymentOutcomeService} finds a second payment for a booking that
 * was already paid.</li>
 * </ul>
 *
 * <p>
 * Execution is safe to repeat: a worker first claims the row
 * (REQUESTED → IN_PROGRESS) with a conditional update, so two workers never
 * refund the same row at once, and each provider integration reuses an
 * existing refund instead of creating a second one. Failures are retried with
 * growing gaps (1, 2, 4, ... up to 60 minutes); after
 * {@code payment.refund.max-attempts} the row becomes FAILED and an alert asks
 * a person to refund from the provider dashboard.
 */
@Service
public class RefundService {

    private static final Logger log = LoggerFactory.getLogger(RefundService.class);

    static final String BOOKING_PROVIDER = "BOOKING";

    private final PaymentRepository paymentRepository;
    private final PaymentProcessorRegistry processorRegistry;
    private final WebhookInboxRepository webhookInboxRepository;
    private final AlertService alertService;
    private final TransactionTemplate transactionTemplate;
    private final int maxAttempts;
    private final long staleClaimMinutes;
    private final int batchSize;

    public RefundService(PaymentRepository paymentRepository,
                         PaymentProcessorRegistry processorRegistry,
                         WebhookInboxRepository webhookInboxRepository,
                         AlertService alertService,
                         TransactionTemplate transactionTemplate,
                         @Value("${payment.refund.max-attempts:10}") int maxAttempts,
                         @Value("${payment.refund.stale-claim-minutes:10}") long staleClaimMinutes,
                         @Value("${payment.refund.batch-size:50}") int batchSize) {
        this.paymentRepository = paymentRepository;
        this.processorRegistry = processorRegistry;
        this.webhookInboxRepository = webhookInboxRepository;
        this.alertService = alertService;
        this.transactionTemplate = transactionTemplate;
        this.maxAttempts = Math.max(maxAttempts, 1);
        this.staleClaimMinutes = Math.max(staleClaimMinutes, 1);
        this.batchSize = Math.max(batchSize, 1);
    }

    /**
     * Booking asked for a refund. Records the request (idempotent per event id)
     * and tries the refund right away; the job retries if this attempt fails.
     */
    public void onRefundRequested(PaymentRefundRequestedEvent event) {
        Long paymentId = transactionTemplate.execute(status -> recordRefundRequest(event));
        if (paymentId != null) {
            executeRefund(paymentId);
        }
    }

    /** @return the payment row to refund, or null when there is nothing to do */
    private Long recordRefundRequest(PaymentRefundRequestedEvent event) {
        if (event == null || isBlank(event.getBookingId())) {
            log.warn("Ignoring refund request without bookingId: {}", event);
            return null;
        }
        String inboxKey = "refund-request:" + (isBlank(event.getEventId())
                ? event.getBookingId() + ":" + event.getTransactionId()
                : event.getEventId());
        if (webhookInboxRepository.existsByEventId(inboxKey)) {
            log.info("Refund request {} already recorded", inboxKey);
            return null;
        }
        WebhookInbox inbox = new WebhookInbox();
        inbox.setEventId(inboxKey);
        inbox.setProvider(BOOKING_PROVIDER);
        inbox.setStatus("PROCESSED");
        webhookInboxRepository.save(inbox);

        List<Payment> rows = paymentRepository.lockAllByBookingId(event.getBookingId());
        Payment target = null;
        if (!isBlank(event.getTransactionId())) {
            target = rows.stream()
                    .filter(p -> p.getStatus() == PaymentStatus.SUCCESS
                            && event.getTransactionId().equals(p.getTransactionId()))
                    .findFirst().orElse(null);
        }
        if (target == null) {
            target = rows.stream() // newest first
                    .filter(p -> p.getStatus() == PaymentStatus.SUCCESS && p.getRefundStatus() == null)
                    .findFirst().orElse(null);
        }
        if (target == null) {
            alertService.sendAlert(String.format(
                    "MANUAL ACTION: refund requested for booking %s (payment %s) but no captured payment was found",
                    event.getBookingId(), event.getTransactionId()));
            return null;
        }
        if (target.getRefundStatus() != null) {
            log.info("Payment {} of booking {} already has refund status {}",
                    target.getId(), target.getBookingId(), target.getRefundStatus());
            return RefundStatus.REQUESTED.equals(target.getRefundStatus()) ? target.getId() : null;
        }
        String reason = isBlank(event.getReason())
                ? "Payment received after the booking was " + event.getBookingStatus()
                : event.getReason();
        PaymentOutcomeService.markRefundRequested(target, reason, LocalDateTime.now());
        paymentRepository.save(target);
        alertService.sendAlert(String.format(
                "Late payment %s for booking %s (%s); automatic refund requested: %s",
                target.getTransactionId(), target.getBookingId(), event.getBookingStatus(), reason));
        return target.getId();
    }

    /**
     * Claims and executes one refund. Safe to call from several threads or pods:
     * only the caller that wins the claim talks to the provider.
     */
    public void executeRefund(Long paymentId) {
        LocalDateTime now = LocalDateTime.now();
        LocalDateTime staleBefore = now.minusMinutes(staleClaimMinutes);
        Integer claimed = transactionTemplate.execute(status -> paymentRepository.claimRefund(
                paymentId, RefundStatus.REQUESTED, RefundStatus.IN_PROGRESS, now, staleBefore));
        if (claimed == null || claimed == 0) {
            return;
        }
        Payment payment = paymentRepository.findById(paymentId).orElse(null);
        if (payment == null) {
            return;
        }
        int attempts = payment.getRefundAttempts() == null ? 1 : payment.getRefundAttempts();
        try {
            if (isBlank(payment.getTransactionId())) {
                throw new IllegalStateException("no provider payment id recorded");
            }
            String refundId = processorRegistry.getPaymentTypeProcessor(payment.getProvider())
                    .refund(payment, payment.getRefundReason());
            transactionTemplate.executeWithoutResult(status -> paymentRepository.markRefunded(
                    paymentId, RefundStatus.REFUNDED, RefundStatus.IN_PROGRESS, refundId, LocalDateTime.now()));
            alertService.sendAlert(String.format(
                    "Refund %s issued for booking %s, payment %s (%s): %s",
                    refundId, payment.getBookingId(), payment.getTransactionId(),
                    payment.getProvider(), payment.getRefundReason()));
        } catch (Exception e) {
            // A missing payment id is retried too: the payment webhook may still
            // fill it in (reconciliation can record a paid link before its id is known).
            boolean giveUp = attempts >= maxAttempts;
            String error = PaymentOutcomeService.truncate(
                    e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage(), 500);
            transactionTemplate.executeWithoutResult(status -> paymentRepository.markRefundAttemptFailed(
                    paymentId, giveUp ? RefundStatus.FAILED : RefundStatus.REQUESTED, RefundStatus.IN_PROGRESS,
                    error, LocalDateTime.now()));
            if (giveUp) {
                alertService.sendAlert(String.format(
                        "MANUAL ACTION: automatic refund failed after %d attempt(s) for booking %s, payment %s (%s). "
                                + "Refund it from the provider dashboard. Last error: %s",
                        attempts, payment.getBookingId(), payment.getTransactionId(), payment.getProvider(), error));
            } else {
                log.warn("Refund attempt {} for booking {} failed, will retry: {}",
                        attempts, payment.getBookingId(), error);
            }
        }
    }

    /** Called by the reconciliation job: retries refunds whose backoff has passed. */
    public void retryPendingRefunds() {
        LocalDateTime now = LocalDateTime.now();
        List<Payment> candidates = paymentRepository.findRefundsToProcess(
                RefundStatus.REQUESTED, RefundStatus.IN_PROGRESS, now.minusMinutes(staleClaimMinutes),
                PageRequest.of(0, batchSize));
        for (Payment payment : candidates) {
            if (!backoffPassed(payment, now)) {
                continue;
            }
            try {
                executeRefund(payment.getId());
            } catch (Exception e) {
                log.error("Refund retry crashed for payment {}", payment.getId(), e);
            }
        }
    }

    /** Waits 1, 2, 4, 8 ... minutes (max 60) after each failed attempt. */
    static boolean backoffPassed(Payment payment, LocalDateTime now) {
        if (!RefundStatus.REQUESTED.equals(payment.getRefundStatus()) || payment.getRefundClaimedAt() == null) {
            return true;
        }
        int attempts = payment.getRefundAttempts() == null ? 0 : payment.getRefundAttempts();
        long waitMinutes = Math.min(60L, 1L << Math.min(Math.max(attempts - 1, 0), 6));
        return payment.getRefundClaimedAt().plusMinutes(waitMinutes).isBefore(now);
    }

    private static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }
}
