package com.forvmom.MomentForeverPayment;

import com.forvmom.MomentForeverPayment.controller.RazorpayWebhookController;
import com.forvmom.MomentForeverPayment.domain.entity.OutgoingPaymentOutbox;
import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.PaymentStatus;
import com.forvmom.MomentForeverPayment.domain.entity.RefundStatus;
import com.forvmom.MomentForeverPayment.events.PaymentRefundRequestedEvent;
import com.forvmom.MomentForeverPayment.events.PaymentRequestedEvent;
import com.forvmom.MomentForeverPayment.service.PaymentProcessService;
import com.forvmom.MomentForeverPayment.repository.OutgoingPaymentOutboxDao;
import com.forvmom.MomentForeverPayment.repository.PaymentOutboxDao;
import com.forvmom.MomentForeverPayment.repository.PaymentRepository;
import com.forvmom.MomentForeverPayment.repository.WebhookInboxRepository;
import com.forvmom.MomentForeverPayment.scheduler.OutgoingPaymentPublisher;
import com.forvmom.MomentForeverPayment.service.AlertService;
import com.forvmom.MomentForeverPayment.service.BookingClosureService;
import com.forvmom.MomentForeverPayment.service.PaymentOutcomeDispatcher;
import com.forvmom.MomentForeverPayment.service.PaymentProcessorRegistry;
import com.forvmom.MomentForeverPayment.service.PaymentProvider;
import com.forvmom.MomentForeverPayment.service.PaymentReconciliationService;
import com.forvmom.MomentForeverPayment.service.PaymentStrategy;
import com.forvmom.MomentForeverPayment.service.ProviderPaymentState;
import com.forvmom.MomentForeverPayment.service.RefundService;
import com.forvmom.MomentForeverPayment.service.WebhookProcessingService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.transaction.support.TransactionTemplate;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;
import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.util.HexFormat;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doReturn;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * End-to-end coverage of the payment window, declined attempts, late money,
 * reconciliation and automatic refunds, against the real services and an H2
 * database. Only the provider (Razorpay/Stripe API) and Kafka publishing are
 * mocked.
 *
 * <p>
 * Uses the same mocked beans as {@link PaymentServiceApplicationTests} so the
 * Spring context (and H2 database) is shared; every test cleans all tables.
 */
@SpringBootTest
@ActiveProfiles("test")
class PaymentWindowAndLateMoneyIntegrationTests {

    private static final String PAID = "PAYMENT_PROCESSED";
    private static final String FAILED = "PAYMENT_FAILED";

    @MockBean
    private PaymentProcessorRegistry paymentProcessorRegistry;

    @MockBean
    private OutgoingPaymentPublisher outgoingPaymentPublisher;

    @Autowired private PaymentRepository paymentRepository;
    @Autowired private OutgoingPaymentOutboxDao outgoingDao;
    @Autowired private PaymentOutboxDao paymentOutboxDao;
    @Autowired private WebhookInboxRepository webhookInboxRepository;
    @Autowired private WebhookProcessingService webhookService;
    @Autowired private PaymentOutcomeDispatcher dispatcher;
    @Autowired private PaymentReconciliationService reconciliationService;
    @Autowired private BookingClosureService bookingClosureService;
    @Autowired private RefundService refundService;
    @Autowired private AlertService alertService;
    @Autowired private TransactionTemplate transactionTemplate;
    @Autowired private JdbcTemplate jdbcTemplate;
    @Autowired private RazorpayWebhookController razorpayWebhookController;
    @Autowired private PaymentProcessService paymentProcessService;

    @Value("${payment.gateway.razorpay.webhook-secret}")
    private String razorpayWebhookSecret;

    private PaymentStrategy provider;

    @BeforeEach
    void setUp() {
        cleanDatabase();
        provider = mock(PaymentStrategy.class);
        when(provider.getProvider()).thenReturn(PaymentProvider.RAZORPAY);
        when(paymentProcessorRegistry.getPaymentTypeProcessor(anyString())).thenReturn(provider);
    }

    @AfterEach
    void cleanDatabase() {
        outgoingDao.deleteAllInBatch();
        paymentOutboxDao.deleteAllInBatch();
        webhookInboxRepository.deleteAllInBatch();
        paymentRepository.deleteAllInBatch();
    }

    // ── 1. Customer's bank down / card declined at payment time ──────────────

    @Test
    void declinedCardKeepsLinkOpenAndUpiOnSameLinkConfirmsBooking() {
        pendingRow("B-1", "plink_1", LocalDateTime.now().plusMinutes(25));

        webhookService.processAttemptFailure("RAZORPAY", "evt-fail-1", null, "B-1",
                "Your bank is facing issues (method=card)", "BAD_REQUEST_ERROR");

        Payment afterDecline = onlyRow("B-1");
        assertEquals(PaymentStatus.PENDING, afterDecline.getStatus(), "a decline must not close the link");
        assertEquals(1, afterDecline.getFailedAttempts());
        assertEquals("BAD_REQUEST_ERROR", afterDecline.getLastErrorCode());
        assertTrue(outgoingDao.findAll().isEmpty(), "Booking must not hear about a single declined attempt");

        dispatcher.dispatch(webhookService.processLinkPaid("RAZORPAY", "evt-paid-1", "plink_1", "pay_upi_1", "B-1"));

        Payment paid = onlyRow("B-1");
        assertEquals(PaymentStatus.SUCCESS, paid.getStatus());
        assertEquals("pay_upi_1", paid.getTransactionId());
        assertEquals(1, outgoing("B-1", PAID).size());
        assertEquals(0, outgoing("B-1", FAILED).size());
        verify(outgoingPaymentPublisher).trySinglePublish(any(OutgoingPaymentOutbox.class));
    }

    @Test
    void declineThenUpiThroughTheRealWebhookEndpoint() throws Exception {
        pendingRow("B-HTTP", "plink_http", LocalDateTime.now().plusMinutes(25));
        MockMvc mvc = MockMvcBuilders.standaloneSetup(razorpayWebhookController).build();

        String declined = """
                {"event":"payment.failed","payload":{"payment":{"entity":{
                  "id":"pay_card_x","status":"failed","method":"card",
                  "error_code":"BAD_REQUEST_ERROR","error_description":"Payment declined by bank",
                  "notes":{"bookingId":"B-HTTP"},"description":"Booking B-HTTP"}}}}
                """;
        mvc.perform(signed(declined, "evt-http-1")).andExpect(status().isOk());
        assertEquals(PaymentStatus.PENDING, onlyRow("B-HTTP").getStatus());
        assertEquals(1, onlyRow("B-HTTP").getFailedAttempts());

        String paid = """
                {"event":"payment_link.paid","payload":{
                  "payment_link":{"entity":{"id":"plink_http","status":"paid","reference_id":"B-HTTP"}},
                  "payment":{"entity":{"id":"pay_upi_http","status":"captured","method":"upi"}}}}
                """;
        mvc.perform(signed(paid, "evt-http-2")).andExpect(status().isOk());
        // Redelivery of the same webhook is ignored.
        mvc.perform(signed(paid, "evt-http-2")).andExpect(status().isOk());

        Payment row = onlyRow("B-HTTP");
        assertEquals(PaymentStatus.SUCCESS, row.getStatus());
        assertEquals("pay_upi_http", row.getTransactionId());
        assertEquals(1, outgoing("B-HTTP", PAID).size());
    }

    // ── 2. Bank confirms late / money after the link was closed ──────────────

    @Test
    void moneyOnAnAlreadyClosedLinkIsRecordedAndSentToBookingToDecide() {
        Payment row = pendingRow("B-2", "plink_2", LocalDateTime.now().minusMinutes(40));
        dispatcher.dispatch(webhookService.processLinkClosed("RAZORPAY", "evt-exp-2", "plink_2",
                "Payment window expired", "PAYMENT_LINK_EXPIRED"));
        assertEquals(PaymentStatus.FAILED, paymentRepository.findById(row.getId()).orElseThrow().getStatus());
        assertEquals(1, outgoing("B-2", FAILED).size());

        dispatcher.dispatch(webhookService.processLinkPaid("RAZORPAY", "evt-paid-2", "plink_2", "pay_late_2", "B-2"));

        Payment late = paymentRepository.findById(row.getId()).orElseThrow();
        assertEquals(PaymentStatus.SUCCESS, late.getStatus(), "money is never ignored");
        assertEquals("pay_late_2", late.getTransactionId());
        assertEquals(1, outgoing("B-2", PAID).size(), "Booking decides: confirm or refund");
    }

    @Test
    void capturedThenLinkPaidForTheSameMoneyProducesOneSuccess() {
        pendingRow("B-3", "plink_3", LocalDateTime.now().plusMinutes(20));

        dispatcher.dispatch(webhookService.processCapturedPayment("RAZORPAY", "evt-cap-3", "B-3",
                "pay_3", new BigDecimal("1500.00"), "INR"));
        dispatcher.dispatch(webhookService.processLinkPaid("RAZORPAY", "evt-paid-3", "plink_3", "pay_3", "B-3"));

        assertEquals(1, paymentRepository.findAllByBookingIdOrderByIdDesc("B-3").size());
        assertEquals(PaymentStatus.SUCCESS, onlyRow("B-3").getStatus());
        assertEquals(1, outgoing("B-3", PAID).size());
    }

    @Test
    void secondDifferentPaymentForAPaidBookingIsRefundedAutomatically() {
        Payment paid = pendingRow("B-4", "plink_4", LocalDateTime.now().plusMinutes(20));
        dispatcher.dispatch(webhookService.processLinkPaid("RAZORPAY", "evt-paid-4", "plink_4", "pay_first", "B-4"));
        when(provider.refund(any(Payment.class), anyString())).thenReturn("rfnd_4");

        dispatcher.dispatch(webhookService.processCapturedPayment("RAZORPAY", "evt-cap-4b", "B-4",
                "pay_second", new BigDecimal("1500.00"), "INR"));

        List<Payment> rows = paymentRepository.findAllByBookingIdOrderByIdDesc("B-4");
        assertEquals(2, rows.size());
        Payment extra = rows.stream().filter(p -> "pay_second".equals(p.getTransactionId())).findFirst().orElseThrow();
        assertEquals(RefundStatus.REFUNDED, extra.getRefundStatus());
        assertEquals("rfnd_4", extra.getRefundId());
        assertNull(paymentRepository.findById(paid.getId()).orElseThrow().getRefundStatus(),
                "the payment that confirmed the booking is kept");
        assertEquals(1, outgoing("B-4", PAID).size(), "Booking hears about one payment only");
    }

    // ── Link expiry / booking closure ────────────────────────────────────────

    @Test
    void expiredLinkFailsThePaymentOnce() {
        pendingRow("B-5", "plink_5", LocalDateTime.now().minusMinutes(1));

        dispatcher.dispatch(webhookService.processLinkClosed("RAZORPAY", "evt-exp-5", "plink_5",
                "Payment window expired", "PAYMENT_LINK_EXPIRED"));
        dispatcher.dispatch(webhookService.processLinkClosed("RAZORPAY", "evt-cancel-5", "plink_5",
                "Payment link was cancelled", "PAYMENT_LINK_CANCELLED"));

        assertEquals(PaymentStatus.FAILED, onlyRow("B-5").getStatus());
        List<OutgoingPaymentOutbox> failed = outgoing("B-5", FAILED);
        assertEquals(1, failed.size());
        assertTrue(failed.get(0).getPayload().contains("PAYMENT_LINK_EXPIRED"));
    }

    @Test
    void bookingClosedCancelsTheOpenLinkWithoutTellingBookingAgain() {
        Payment row = pendingRow("B-6", "plink_6", LocalDateTime.now().plusMinutes(20));
        when(provider.fetchState(any())).thenReturn(ProviderPaymentState.open("created"));
        when(provider.cancel(any())).thenReturn(ProviderPaymentState.closed("cancelled"));

        bookingClosureService.closeLinks(bookingClosureService.markCloseRequested("B-6", "Booking BOOKING_CANCELLED"));

        Payment closed = paymentRepository.findById(row.getId()).orElseThrow();
        assertEquals(PaymentStatus.FAILED, closed.getStatus());
        assertNotNull(closed.getCloseRequestedAt());
        verify(provider).cancel(any());
        assertTrue(outgoingDao.findAll().isEmpty(), "Booking already closed the booking");
    }

    @Test
    void bookingClosedButCustomerHadJustPaidRecordsThePayment() {
        pendingRow("B-7", "plink_7", LocalDateTime.now().plusMinutes(20));
        when(provider.fetchState(any())).thenReturn(ProviderPaymentState.open("created"));
        when(provider.cancel(any())).thenReturn(ProviderPaymentState.paid("pay_race_7", "paid"));

        bookingClosureService.closeLinks(bookingClosureService.markCloseRequested("B-7", "Booking BOOKING_FAILED"));

        Payment row = onlyRow("B-7");
        assertEquals(PaymentStatus.SUCCESS, row.getStatus());
        assertEquals("pay_race_7", row.getTransactionId());
        assertEquals(1, outgoing("B-7", PAID).size(), "Booking will request the refund");
    }

    // ── 3 & 4. Provider unreachable / our webhook lost → reconciliation ──────

    @Test
    void reconciliationRecordsAPaymentWhoseWebhookWasLost() {
        pendingRow("B-8", "plink_8", LocalDateTime.now().minusMinutes(10));
        when(provider.fetchState(any())).thenReturn(ProviderPaymentState.paid("pay_lost_8", "paid"));

        reconciliationService.runOnce();

        assertEquals(PaymentStatus.SUCCESS, onlyRow("B-8").getStatus());
        assertEquals("pay_lost_8", onlyRow("B-8").getTransactionId());
        assertEquals(1, outgoing("B-8", PAID).size());
        verify(provider, never()).cancel(any());
    }

    @Test
    void reconciliationClosesAnOverdueOpenLinkAndFailsThePayment() {
        pendingRow("B-9", "plink_9", LocalDateTime.now().minusMinutes(10));
        when(provider.fetchState(any())).thenReturn(ProviderPaymentState.open("created"));
        when(provider.cancel(any())).thenReturn(ProviderPaymentState.closed("cancelled"));

        reconciliationService.runOnce();

        assertEquals(PaymentStatus.FAILED, onlyRow("B-9").getStatus());
        List<OutgoingPaymentOutbox> failed = outgoing("B-9", FAILED);
        assertEquals(1, failed.size());
        assertTrue(failed.get(0).getPayload().contains("PAYMENT_WINDOW_EXPIRED"));
    }

    @Test
    void reconciliationLeavesNotYetDueLinksAlone() {
        pendingRow("B-10", "plink_10", LocalDateTime.now().plusMinutes(15));
        pendingRow("B-10b", "plink_10b", LocalDateTime.now().minusMinutes(2)); // inside the grace period

        reconciliationService.runOnce();

        verify(provider, never()).fetchState(any());
        assertEquals(PaymentStatus.PENDING, onlyRow("B-10").getStatus());
        assertEquals(PaymentStatus.PENDING, onlyRow("B-10b").getStatus());
    }

    @Test
    void providerDownOnlyDelaysTheOutcome() {
        Payment row = pendingRow("B-11", "plink_11", LocalDateTime.now().minusMinutes(10));
        when(provider.fetchState(any())).thenThrow(new IllegalStateException("Razorpay unreachable"));

        reconciliationService.runOnce();

        Payment afterOutage = paymentRepository.findById(row.getId()).orElseThrow();
        assertEquals(PaymentStatus.PENDING, afterOutage.getStatus());
        assertNotNull(afterOutage.getLastReconciledAt());
        assertTrue(outgoingDao.findAll().isEmpty());

        // Provider back; the next run after the recheck interval settles it.
        sql("UPDATE payment SET last_reconciled_at = ? WHERE id = ?", LocalDateTime.now().minusMinutes(30), row.getId());
        doReturn(ProviderPaymentState.paid("pay_after_outage", "paid")).when(provider).fetchState(any());

        reconciliationService.runOnce();

        assertEquals(PaymentStatus.SUCCESS, paymentRepository.findById(row.getId()).orElseThrow().getStatus());
        assertEquals(1, outgoing("B-11", PAID).size());
    }

    @Test
    void legacyPendingRowWithoutExpiryIsSettledAfterTheDefaultWindow() {
        Payment row = pendingRow("B-12", "plink_12", null);
        sql("UPDATE payment SET created_at = ? WHERE id = ?", LocalDateTime.now().minusHours(3), row.getId());
        when(provider.fetchState(any())).thenReturn(ProviderPaymentState.open("created"));
        when(provider.cancel(any())).thenReturn(ProviderPaymentState.closed("cancelled"));

        reconciliationService.runOnce();

        assertEquals(PaymentStatus.FAILED, onlyRow("B-12").getStatus());
        assertEquals(1, outgoing("B-12", FAILED).size(), "Booking releases the abandoned slot");
    }

    @Test
    void olderFailedRowWithAnOpenLinkIsClosedOnlyOnce() {
        Payment row = pendingRow("B-13", "plink_13", null);
        row.setStatus(PaymentStatus.FAILED); // failed by a declined card before this fix
        paymentRepository.save(row);
        when(provider.fetchState(any())).thenReturn(ProviderPaymentState.open("created"));
        when(provider.cancel(any())).thenReturn(ProviderPaymentState.closed("cancelled"));

        reconciliationService.runOnce();
        reconciliationService.runOnce();

        verify(provider, times(1)).cancel(any());
        Payment checked = paymentRepository.findById(row.getId()).orElseThrow();
        assertEquals(PaymentStatus.FAILED, checked.getStatus());
        assertNotNull(checked.getLastReconciledAt());
        assertTrue(outgoingDao.findAll().isEmpty());
    }

    @Test
    void olderFailedRowThatWasActuallyPaidIsRecovered() {
        Payment row = pendingRow("B-14", "plink_14", null);
        row.setStatus(PaymentStatus.FAILED);
        paymentRepository.save(row);
        when(provider.fetchState(any())).thenReturn(ProviderPaymentState.paid("pay_hidden_14", "paid"));

        reconciliationService.runOnce();

        assertEquals(PaymentStatus.SUCCESS, onlyRow("B-14").getStatus());
        assertEquals(1, outgoing("B-14", PAID).size(), "Booking decides: confirm or refund");
    }

    // ── Review findings: older data and edge cases ───────────────────────────

    @Test
    void lateMoneyOnAnOlderFailedRowReplacesTheDeclinedIdAndStopsPolling() {
        Payment old = pendingRow("B-20", "plink_20", null);
        old.setStatus(PaymentStatus.FAILED);
        old.setTransactionId("pay_declined_card"); // older code stored the declined attempt's id
        paymentRepository.save(old);

        dispatcher.dispatch(webhookService.processCapturedPayment("RAZORPAY", "evt-cap-20", "B-20",
                "pay_real_20", new BigDecimal("1500.00"), "INR"));
        dispatcher.dispatch(webhookService.processLinkPaid("RAZORPAY", "evt-paid-20", "plink_20", "pay_real_20", "B-20"));
        reconciliationService.runOnce();

        Payment row = onlyRow("B-20");
        assertEquals(PaymentStatus.SUCCESS, row.getStatus());
        assertEquals("pay_real_20", row.getTransactionId());
        assertEquals(1, outgoing("B-20", PAID).size());
        verify(provider, never()).fetchState(any());
    }

    @Test
    void linkPaidWhoseMoneyIsRecordedOnAnotherRowIsClosedOutNotPolledForever() {
        Payment l1 = pendingRow("B-21", "plink_21a", LocalDateTime.now().minusMinutes(40));
        pendingRow("B-21", "plink_21b", LocalDateTime.now().minusMinutes(40)); // older data: two links

        // payment.captured cannot tell which link was paid; it uses the newest open one.
        dispatcher.dispatch(webhookService.processCapturedPayment("RAZORPAY", "evt-cap-21", "B-21",
                "pay_21", new BigDecimal("1500.00"), "INR"));
        // The paid link was actually the older one.
        dispatcher.dispatch(webhookService.processLinkPaid("RAZORPAY", "evt-paid-21", "plink_21a", "pay_21", "B-21"));

        Payment closedOut = paymentRepository.findById(l1.getId()).orElseThrow();
        assertEquals(PaymentStatus.FAILED, closedOut.getStatus());
        assertEquals("PAID_ON_OTHER_ROW", closedOut.getLastErrorCode());
        assertNotNull(closedOut.getLastReconciledAt());
        assertEquals(1, outgoing("B-21", PAID).size());

        reconciliationService.runOnce();
        verify(provider, never()).fetchState(any());
    }

    @Test
    void paidLinkFoundWithoutPaymentIdIsCompletedByTheWebhookNotRefunded() {
        Payment row = pendingRow("B-22", "plink_22", LocalDateTime.now().minusMinutes(10));
        when(provider.fetchState(any())).thenReturn(ProviderPaymentState.paid(null, "paid"));

        reconciliationService.runOnce();
        dispatcher.dispatch(webhookService.processLinkPaid("RAZORPAY", "evt-paid-22", "plink_22", "pay_22", "B-22"));

        Payment paid = paymentRepository.findById(row.getId()).orElseThrow();
        assertEquals(PaymentStatus.SUCCESS, paid.getStatus());
        assertEquals("pay_22", paid.getTransactionId());
        assertNull(paid.getRefundStatus(), "the same payment, not a second one");
        assertEquals(1, paymentRepository.findAllByBookingIdOrderByIdDesc("B-22").size());
        assertEquals(1, outgoing("B-22", PAID).size());
        verify(provider, never()).refund(any(Payment.class), anyString());
    }

    @Test
    void bookingClosedBeforeItsLinkExistedGetsTheNewLinkClosed() {
        bookingClosureService.markCloseRequested("B-23", "Booking BOOKING_CANCELLED: customer cancelled");

        Payment created = new Payment();
        created.setProvider("RAZORPAY");
        created.setBookingId("B-23");
        created.setProviderSessionId("plink_23");
        created.setPaymentUrl("https://rzp.io/i/plink_23");
        created.setAmount(new BigDecimal("1500.00"));
        created.setCurrency("INR");
        created.setStatus(PaymentStatus.PENDING);
        created.setExpiresAt(LocalDateTime.now().plusMinutes(30));
        when(provider.initiatePayment(any())).thenReturn(created);
        when(paymentProcessorRegistry.getPaymentTypeProcessor(null)).thenReturn(provider);
        PaymentRequestedEvent request = new PaymentRequestedEvent();
        request.setBookingId("B-23");
        request.setEventId("evt-request-23");
        request.setProducer("booking-service");
        request.setGrandTotal(new BigDecimal("1500.00"));
        request.setCurrency("INR");

        paymentProcessService.handleIncomingPaymentRequest(request, null);
        assertNotNull(onlyRow("B-23").getCloseRequestedAt(), "link marked for closing on creation");

        when(provider.fetchState(any())).thenReturn(ProviderPaymentState.open("created"));
        when(provider.cancel(any())).thenReturn(ProviderPaymentState.closed("cancelled"));
        reconciliationService.runOnce();

        assertEquals(PaymentStatus.FAILED, onlyRow("B-23").getStatus());
        assertEquals(0, outgoing("B-23", FAILED).size(), "Booking already closed it");
    }

    // ── Automatic refunds (Option A) ─────────────────────────────────────────

    @Test
    void refundRequestFromBookingRefundsOnceEvenIfDeliveredTwice() {
        Payment row = paidRow("B-15", "plink_15", "pay_15");
        when(provider.refund(any(Payment.class), anyString())).thenReturn("rfnd_15");
        PaymentRefundRequestedEvent request = refundRequest("B-15", "pay_15", "evt-refund-15");

        refundService.onRefundRequested(request);
        refundService.onRefundRequested(request);

        Payment refunded = paymentRepository.findById(row.getId()).orElseThrow();
        assertEquals(RefundStatus.REFUNDED, refunded.getRefundStatus());
        assertEquals("rfnd_15", refunded.getRefundId());
        assertNotNull(refunded.getRefundedAt());
        verify(provider, times(1)).refund(any(Payment.class), anyString());
    }

    @Test
    void failedRefundIsRetriedAndThenEscalated() {
        Payment row = paidRow("B-16", "plink_16", "pay_16");
        when(provider.refund(any(Payment.class), anyString()))
                .thenThrow(new IllegalStateException("Razorpay down"));
        RefundService twoAttempts = new RefundService(paymentRepository, paymentProcessorRegistry,
                webhookInboxRepository, alertService, transactionTemplate, 2, 10, 50);

        twoAttempts.onRefundRequested(refundRequest("B-16", "pay_16", "evt-refund-16"));
        Payment afterFirst = paymentRepository.findById(row.getId()).orElseThrow();
        assertEquals(RefundStatus.REQUESTED, afterFirst.getRefundStatus(), "kept for retry");
        assertEquals(1, afterFirst.getRefundAttempts());
        assertTrue(afterFirst.getRefundLastError().contains("Razorpay down"));

        twoAttempts.executeRefund(row.getId());
        Payment afterSecond = paymentRepository.findById(row.getId()).orElseThrow();
        assertEquals(RefundStatus.FAILED, afterSecond.getRefundStatus(), "escalated to a person");
        assertEquals(2, afterSecond.getRefundAttempts());

        twoAttempts.executeRefund(row.getId());
        verify(provider, times(2)).refund(any(Payment.class), anyString());
    }

    @Test
    void refundInProgressByAnotherWorkerIsNotRepeated() {
        Payment row = paidRow("B-17", "plink_17", "pay_17");
        row.setRefundStatus(RefundStatus.IN_PROGRESS);
        row.setRefundClaimedAt(LocalDateTime.now());
        paymentRepository.save(row);

        refundService.executeRefund(row.getId());
        refundService.retryPendingRefunds();

        verify(provider, never()).refund(any(Payment.class), anyString());
    }

    @Test
    void refundRequestForUnknownPaymentDoesNotRefundAnything() {
        refundService.onRefundRequested(refundRequest("B-NOPE", "pay_nope", "evt-refund-nope"));

        verify(provider, never()).refund(any(Payment.class), anyString());
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private Payment pendingRow(String bookingId, String linkId, LocalDateTime expiresAt) {
        Payment payment = new Payment();
        payment.setProvider("RAZORPAY");
        payment.setBookingId(bookingId);
        payment.setCorrelationId(bookingId);
        payment.setProviderSessionId(linkId);
        payment.setPaymentUrl("https://rzp.io/i/" + linkId);
        payment.setAmount(new BigDecimal("1500.00"));
        payment.setCurrency("INR");
        payment.setStatus(PaymentStatus.PENDING);
        payment.setExpiresAt(expiresAt);
        return paymentRepository.save(payment);
    }

    private Payment paidRow(String bookingId, String linkId, String transactionId) {
        Payment payment = pendingRow(bookingId, linkId, LocalDateTime.now().minusMinutes(1));
        payment.setStatus(PaymentStatus.SUCCESS);
        payment.setTransactionId(transactionId);
        return paymentRepository.save(payment);
    }

    private PaymentRefundRequestedEvent refundRequest(String bookingId, String transactionId, String eventId) {
        PaymentRefundRequestedEvent event = new PaymentRefundRequestedEvent();
        event.setEventId(eventId);
        event.setProducer("booking-service");
        event.setBookingId(bookingId);
        event.setTransactionId(transactionId);
        event.setBookingStatus("FAILED");
        event.setReason("Payment received after the booking was FAILED (payment window expired)");
        return event;
    }

    /** Raw SQL inside a transaction (the pool runs with auto-commit off). */
    private void sql(String statement, Object... args) {
        transactionTemplate.executeWithoutResult(status -> jdbcTemplate.update(statement, args));
    }

    private Payment onlyRow(String bookingId) {
        List<Payment> rows = paymentRepository.findAllByBookingIdOrderByIdDesc(bookingId);
        assertEquals(1, rows.size(), "expected one payment row for " + bookingId);
        return rows.get(0);
    }

    private List<OutgoingPaymentOutbox> outgoing(String bookingId, String eventType) {
        return outgoingDao.findAll().stream()
                .filter(o -> bookingId.equals(o.getBookingId()) && eventType.equals(o.getEventType()))
                .toList();
    }

    private org.springframework.test.web.servlet.RequestBuilder signed(String payload, String eventId) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA256");
        mac.init(new SecretKeySpec(razorpayWebhookSecret.getBytes(StandardCharsets.UTF_8), "HmacSHA256"));
        String signature = HexFormat.of().formatHex(mac.doFinal(payload.getBytes(StandardCharsets.UTF_8)));
        return post("/webhooks/razorpay")
                .contentType(MediaType.APPLICATION_JSON)
                .header("X-Razorpay-Signature", signature)
                .header("X-Razorpay-Event-Id", eventId)
                .content(payload);
    }
}
