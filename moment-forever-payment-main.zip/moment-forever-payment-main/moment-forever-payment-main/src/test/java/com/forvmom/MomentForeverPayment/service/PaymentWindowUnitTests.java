package com.forvmom.MomentForeverPayment.service;

import com.forvmom.MomentForeverPayment.domain.entity.Payment;
import com.forvmom.MomentForeverPayment.domain.entity.RefundStatus;
import com.forvmom.MomentForeverPayment.events.BookingLifecycleEvent;
import com.forvmom.MomentForeverPayment.events.PaymentRefundRequestedEvent;
import com.forvmom.MomentForeverPayment.events.PaymentRequestedEvent;
import org.json.JSONObject;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

class PaymentWindowUnitTests {

    private static final Instant NOW = Instant.parse("2026-11-07T10:00:00Z");

    // ── Payment window clamping ──────────────────────────────────────────────

    @Test
    void bookingDeadlineIsUsedWhenTheProviderAllowsIt() {
        PaymentWindowPolicy policy = new PaymentWindowPolicy(30, 5);
        Instant due = NOW.plus(Duration.ofMinutes(30));

        assertEquals(due, policy.linkExpiry(due, PaymentProvider.RAZORPAY, NOW));
        assertEquals(due.plus(Duration.ofMinutes(1)),
                policy.linkExpiry(due.plus(Duration.ofMinutes(1)), PaymentProvider.STRIPE, NOW));
    }

    @Test
    void deadlineIsClampedToProviderLimits() {
        PaymentWindowPolicy policy = new PaymentWindowPolicy(30, 5);
        Instant almostOver = NOW.plus(Duration.ofMinutes(3));

        assertEquals(NOW.plus(Duration.ofMinutes(16)),
                policy.linkExpiry(almostOver, PaymentProvider.RAZORPAY, NOW), "Razorpay needs >= 15 min");
        assertEquals(NOW.plus(Duration.ofMinutes(31)),
                policy.linkExpiry(almostOver, PaymentProvider.STRIPE, NOW), "Stripe needs >= 30 min");
        assertEquals(NOW.plus(Duration.ofHours(23)),
                policy.linkExpiry(NOW.plus(Duration.ofDays(3)), PaymentProvider.STRIPE, NOW), "Stripe allows <= 24 h");
    }

    @Test
    void missingDeadlineFallsBackToTheDefaultHoldWindow() {
        PaymentWindowPolicy policy = new PaymentWindowPolicy(30, 5);

        assertEquals(NOW.plus(Duration.ofMinutes(30)), policy.linkExpiry(null, PaymentProvider.RAZORPAY, NOW));
    }

    // ── Razorpay link status mapping ─────────────────────────────────────────

    @Test
    void razorpayLinkStatusesMapToOpenPaidClosed() throws Exception {
        assertEquals(ProviderPaymentState.Kind.OPEN,
                RazorpayPaymentProcessor.toState(new JSONObject("{\"status\":\"created\"}")).kind());
        assertEquals(ProviderPaymentState.Kind.OPEN,
                RazorpayPaymentProcessor.toState(new JSONObject("{\"status\":\"partially_paid\"}")).kind());
        assertEquals(ProviderPaymentState.Kind.CLOSED,
                RazorpayPaymentProcessor.toState(new JSONObject("{\"status\":\"expired\"}")).kind());
        assertEquals(ProviderPaymentState.Kind.CLOSED,
                RazorpayPaymentProcessor.toState(new JSONObject("{\"status\":\"cancelled\"}")).kind());

        ProviderPaymentState paid = RazorpayPaymentProcessor.toState(new JSONObject("""
                {"status":"paid","payments":[
                  {"payment_id":"pay_failed_card","status":"failed"},
                  {"payment_id":"pay_upi_ok","status":"captured"}]}
                """));
        assertEquals(ProviderPaymentState.Kind.PAID, paid.kind());
        assertEquals("pay_upi_ok", paid.transactionId(), "the captured payment, not the declined one");

        ProviderPaymentState paidUnknownId = RazorpayPaymentProcessor.toState(new JSONObject("""
                {"status":"paid","payments":[{"payment_id":"pay_failed_card","status":"failed"}]}
                """));
        assertEquals(ProviderPaymentState.Kind.PAID, paidUnknownId.kind());
        assertNull(paidUnknownId.transactionId(), "never guess a declined attempt's id");
    }

    // ── Refund retry backoff ─────────────────────────────────────────────────

    @Test
    void refundRetriesWaitLongerAfterEachFailure() {
        LocalDateTime now = LocalDateTime.of(2026, 11, 7, 10, 0);
        Payment payment = new Payment();
        payment.setRefundStatus(RefundStatus.REQUESTED);

        assertTrue(RefundService.backoffPassed(payment, now), "never attempted yet");

        payment.setRefundAttempts(3);
        payment.setRefundClaimedAt(now.minusMinutes(3));
        assertFalse(RefundService.backoffPassed(payment, now), "3rd failure waits 4 minutes");
        payment.setRefundClaimedAt(now.minusMinutes(5));
        assertTrue(RefundService.backoffPassed(payment, now));

        payment.setRefundAttempts(9);
        payment.setRefundClaimedAt(now.minusMinutes(59));
        assertFalse(RefundService.backoffPassed(payment, now), "capped at 60 minutes");
    }

    // ── Contract with Booking's Kafka messages ───────────────────────────────

    @Test
    void bookingRefundRequestJsonIsReadByPayment() {
        String fromBooking = """
                {"eventId":"e-1","producer":"booking-service","schemaVersion":1,
                 "occurredAt":"2026-11-07T10:00:00Z","correlationId":"B-1","causationId":"pay-evt",
                 "eventType":"PAYMENT_REFUND_REQUESTED","bookingId":"B-1","transactionId":"pay_1",
                 "amount":1500.00,"currency":"INR","bookingStatus":"FAILED",
                 "reason":"Payment received after the booking was FAILED"}
                """;
        PaymentRefundRequestedEvent event = read(fromBooking, PaymentRefundRequestedEvent.class);

        assertEquals("B-1", event.getBookingId());
        assertEquals("pay_1", event.getTransactionId());
        assertEquals(0, new BigDecimal("1500.00").compareTo(event.getAmount()));
        assertEquals("FAILED", event.getBookingStatus());
        assertEquals("e-1", event.getEventId());
    }

    @Test
    void bookingFailedAndCancelledJsonIsReadAsLifecycleEvent() {
        String failed = """
                {"eventId":"f-1","producer":"booking-service","eventType":"BOOKING_FAILED","bookingId":"B-2",
                 "userId":7,"bookingDate":"2026-12-01","failureReason":"Payment window expired",
                 "failedAt":"2026-11-07T10:31:00"}
                """;
        String cancelled = """
                {"eventId":"c-1","eventType":"BOOKING_CANCELLED","bookingId":"B-3","cancelReason":"changed mind",
                 "cancelledAt":"2026-11-07T10:05:00","confirmedAt":null}
                """;

        BookingLifecycleEvent f = read(failed, BookingLifecycleEvent.class);
        BookingLifecycleEvent c = read(cancelled, BookingLifecycleEvent.class);

        assertEquals("B-2", f.getBookingId());
        assertEquals("Payment window expired", f.getFailureReason());
        assertEquals("B-3", c.getBookingId());
        assertEquals("changed mind", c.getCancelReason());
    }

    @Test
    void paymentDueAtFromBookingIsRead() {
        PaymentRequestedEvent withDeadline = read(
                "{\"bookingId\":\"B-4\",\"paymentDueAt\":\"2026-11-07T10:30:00Z\"}", PaymentRequestedEvent.class);
        PaymentRequestedEvent olderBooking = read("{\"bookingId\":\"B-5\"}", PaymentRequestedEvent.class);

        assertEquals(Instant.parse("2026-11-07T10:30:00Z"), withDeadline.getPaymentDueAt());
        assertNull(olderBooking.getPaymentDueAt());
    }

    /** Deserializes exactly like the Kafka listener factories (fixed type, no type headers). */
    private static <T> T read(String json, Class<T> type) {
        try (JsonDeserializer<T> deserializer = new JsonDeserializer<>(type)) {
            deserializer.configure(Map.of(
                    JsonDeserializer.TRUSTED_PACKAGES, "com.forvmom.MomentForeverPayment.events",
                    JsonDeserializer.USE_TYPE_INFO_HEADERS, false), false);
            return deserializer.deserialize("topic", json.getBytes(StandardCharsets.UTF_8));
        }
    }
}
