package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.ExperienceCompletionEvidence;
import com.forvmom.MomentForeverBilling.domain.FinanceReviewCase;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidate;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidateStatus;
import com.forvmom.MomentForeverBilling.events.ExperienceCompletedEvent;
import com.forvmom.MomentForeverBilling.events.ReceiptEligibilityCapturedEvent;
import com.forvmom.MomentForeverBilling.repository.ExperienceCompletionEvidenceRepository;
import com.forvmom.MomentForeverBilling.repository.FinanceReviewCaseRepository;
import com.forvmom.MomentForeverBilling.repository.ReceiptCandidateRepository;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicReference;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ReceiptCandidateServiceTest {

    @Test
    void amountMismatchCreatesCandidateAndFinanceReviewWithoutIssuingReceipt() {
        Fixture fixture = fixture();
        ReceiptEligibilityCapturedEvent event = validCaptureEvent();
        event.setAmountPaid(new BigDecimal("99.99"));
        when(fixture.candidateRepository.findBySourceEventId(event.getEventId())).thenReturn(Optional.empty());
        when(fixture.candidateRepository.findByBookingId(event.getBookingId())).thenReturn(Optional.empty());

        ReceiptCandidateResult result = fixture.service.capture(event);

        assertEquals("AMOUNT_MISMATCH", result.resolutionCode());
        ArgumentCaptor<ReceiptCandidate> candidate = ArgumentCaptor.forClass(ReceiptCandidate.class);
        verify(fixture.candidateRepository).insert(candidate.capture());
        assertEquals(ReceiptCandidateStatus.REVIEW_REQUIRED, candidate.getValue().getStatus());
        verify(fixture.financeReviewCaseRepository).insert(any(FinanceReviewCase.class));
        verify(fixture.receiptIssuanceService, never()).issueIfReady(any(ReceiptCandidate.class));
    }

    @Test
    void incompleteEvidenceWithoutBookingIdIsRetainedForFinanceReview() {
        Fixture fixture = fixture();
        ReceiptEligibilityCapturedEvent event = validCaptureEvent();
        event.setBookingId(null);
        when(fixture.candidateRepository.findBySourceEventId(event.getEventId())).thenReturn(Optional.empty());

        ReceiptCandidateResult result = fixture.service.capture(event);

        assertEquals("PAYMENT_EVIDENCE_INCOMPLETE", result.resolutionCode());
        verify(fixture.candidateRepository).insert(any(ReceiptCandidate.class));
        verify(fixture.financeReviewCaseRepository).insert(any(FinanceReviewCase.class));
        verify(fixture.receiptIssuanceService, never()).issueIfReady(any(ReceiptCandidate.class));
    }

    @Test
    void validCaptureWaitsForCompletionAndDoesNotIssueOrQueueDelivery() {
        Fixture fixture = fixture();
        ReceiptEligibilityCapturedEvent event = validCaptureEvent();
        when(fixture.candidateRepository.findBySourceEventId(event.getEventId())).thenReturn(Optional.empty());
        when(fixture.candidateRepository.findByBookingId(event.getBookingId())).thenReturn(Optional.empty());
        when(fixture.completionRepository.findByBookingId(event.getBookingId())).thenReturn(Optional.empty());

        ReceiptCandidateResult result = fixture.service.capture(event);

        assertEquals("PENDING_COMPLETION", result.resolutionCode());
        ArgumentCaptor<ReceiptCandidate> candidate = ArgumentCaptor.forClass(ReceiptCandidate.class);
        verify(fixture.candidateRepository).insert(candidate.capture());
        assertEquals(ReceiptCandidateStatus.PENDING_COMPLETION, candidate.getValue().getStatus());
        verify(fixture.receiptIssuanceService, never()).issueIfReady(any(ReceiptCandidate.class));
    }

    @Test
    void completionIssuesOnlyForPreviouslyValidCandidate() {
        Fixture fixture = fixture();
        ExperienceCompletedEvent event = completionEvent();
        ReceiptCandidate candidate = new ReceiptCandidate();
        candidate.setBookingId(event.getBookingId());
        candidate.setStatus(ReceiptCandidateStatus.PENDING_COMPLETION);
        when(fixture.completionRepository.findByEventId(event.getEventId())).thenReturn(Optional.empty());
        when(fixture.completionRepository.findByBookingId(event.getBookingId())).thenReturn(Optional.empty());
        when(fixture.candidateRepository.findByBookingId(event.getBookingId())).thenReturn(Optional.of(candidate));
        when(fixture.receiptIssuanceService.issueIfReady(candidate)).thenReturn(ReceiptIssuanceResult.issued());

        ReceiptCandidateResult result = fixture.service.complete(event);

        assertEquals("ISSUED", result.resolutionCode());
        verify(fixture.completionRepository).insert(any(ExperienceCompletionEvidence.class));
        verify(fixture.receiptIssuanceService).issueIfReady(candidate);
    }

    @Test
    void completionWithoutCandidateIsDurablyRetainedWithoutIssuing() {
        Fixture fixture = fixture();
        ExperienceCompletedEvent event = completionEvent();
        when(fixture.completionRepository.findByEventId(event.getEventId())).thenReturn(Optional.empty());
        when(fixture.completionRepository.findByBookingId(event.getBookingId())).thenReturn(Optional.empty());
        when(fixture.candidateRepository.findByBookingId(event.getBookingId())).thenReturn(Optional.empty());

        ReceiptCandidateResult result = fixture.service.complete(event);

        assertEquals("WAITING_FOR_CANDIDATE", result.resolutionCode());
        verify(fixture.completionRepository).insert(any(ExperienceCompletionEvidence.class));
        verify(fixture.receiptIssuanceService, never()).issueIfReady(any(ReceiptCandidate.class));
    }

    @Test
    void captureThenCompletionIssuesExactlyOneReceipt() {
        Fixture fixture = fixture();
        ReceiptEligibilityCapturedEvent capture = validCaptureEvent();
        ExperienceCompletedEvent completion = completionEvent();
        AtomicReference<ReceiptCandidate> savedCandidate = new AtomicReference<>();

        when(fixture.candidateRepository.findBySourceEventId(capture.getEventId())).thenReturn(Optional.empty());
        when(fixture.candidateRepository.findByBookingId(capture.getBookingId()))
                .thenAnswer(invocation -> Optional.ofNullable(savedCandidate.get()));
        when(fixture.completionRepository.findByBookingId(capture.getBookingId())).thenReturn(Optional.empty());
        when(fixture.completionRepository.findByEventId(completion.getEventId())).thenReturn(Optional.empty());
        when(fixture.candidateRepository.insert(any(ReceiptCandidate.class))).thenAnswer(invocation -> {
            ReceiptCandidate candidate = invocation.getArgument(0);
            savedCandidate.set(candidate);
            return candidate;
        });
        when(fixture.receiptIssuanceService.issueIfReady(any(ReceiptCandidate.class)))
                .thenReturn(ReceiptIssuanceResult.issued());

        ReceiptCandidateResult captureResult = fixture.service.capture(capture);
        ReceiptCandidateResult completionResult = fixture.service.complete(completion);

        assertEquals("PENDING_COMPLETION", captureResult.resolutionCode());
        assertEquals("ISSUED", completionResult.resolutionCode());
        verify(fixture.receiptIssuanceService, times(1)).issueIfReady(any(ReceiptCandidate.class));
    }

    @Test
    void completionThenCaptureIssuesExactlyOneReceipt() {
        Fixture fixture = fixture();
        ReceiptEligibilityCapturedEvent capture = validCaptureEvent();
        ExperienceCompletedEvent completion = completionEvent();
        AtomicReference<ExperienceCompletionEvidence> savedCompletion = new AtomicReference<>();

        when(fixture.candidateRepository.findBySourceEventId(capture.getEventId())).thenReturn(Optional.empty());
        when(fixture.candidateRepository.findByBookingId(capture.getBookingId())).thenReturn(Optional.empty());
        when(fixture.completionRepository.findByEventId(completion.getEventId())).thenReturn(Optional.empty());
        when(fixture.completionRepository.findByBookingId(completion.getBookingId()))
                .thenAnswer(invocation -> Optional.ofNullable(savedCompletion.get()));
        when(fixture.completionRepository.insert(any(ExperienceCompletionEvidence.class))).thenAnswer(invocation -> {
            ExperienceCompletionEvidence evidence = invocation.getArgument(0);
            savedCompletion.set(evidence);
            return evidence;
        });
        when(fixture.receiptIssuanceService.issueIfReady(any(ReceiptCandidate.class)))
                .thenReturn(ReceiptIssuanceResult.issued());

        ReceiptCandidateResult completionResult = fixture.service.complete(completion);
        ReceiptCandidateResult captureResult = fixture.service.capture(capture);

        assertEquals("WAITING_FOR_CANDIDATE", completionResult.resolutionCode());
        assertEquals("ISSUED", captureResult.resolutionCode());
        verify(fixture.receiptIssuanceService, times(1)).issueIfReady(any(ReceiptCandidate.class));
    }

    @Test
    void overlappingCaptureAndCompletionEventuallyIssueExactlyOneReceipt() throws Exception {
        Fixture fixture = fixture();
        ReceiptEligibilityCapturedEvent capture = validCaptureEvent();
        ExperienceCompletedEvent completion = completionEvent();
        CountDownLatch candidateInserted = new CountDownLatch(1);
        CountDownLatch completionInserted = new CountDownLatch(1);
        AtomicReference<ReceiptCandidate> savedCandidate = new AtomicReference<>();
        AtomicReference<ExperienceCompletionEvidence> savedCompletion = new AtomicReference<>();
        AtomicBoolean reconciliationPass = new AtomicBoolean(false);
        AtomicInteger issuanceCount = new AtomicInteger();

        when(fixture.candidateRepository.findBySourceEventId(capture.getEventId())).thenReturn(Optional.empty());
        when(fixture.completionRepository.findByEventId(completion.getEventId())).thenReturn(Optional.empty());
        when(fixture.candidateRepository.findByBookingId(capture.getBookingId())).thenAnswer(invocation -> {
            if (reconciliationPass.get()) {
                return Optional.ofNullable(savedCandidate.get());
            }
            if ("capture-thread".equals(Thread.currentThread().getName())) {
                return Optional.empty();
            }
            await(candidateInserted);
            return Optional.empty();
        });
        when(fixture.completionRepository.findByBookingId(completion.getBookingId())).thenAnswer(invocation -> {
            if (reconciliationPass.get()) {
                return Optional.ofNullable(savedCompletion.get());
            }
            if ("completion-thread".equals(Thread.currentThread().getName())) {
                return Optional.empty();
            }
            await(completionInserted);
            return Optional.empty();
        });
        when(fixture.candidateRepository.insert(any(ReceiptCandidate.class))).thenAnswer(invocation -> {
            ReceiptCandidate candidate = invocation.getArgument(0);
            savedCandidate.set(candidate);
            candidateInserted.countDown();
            return candidate;
        });
        when(fixture.completionRepository.insert(any(ExperienceCompletionEvidence.class))).thenAnswer(invocation -> {
            ExperienceCompletionEvidence evidence = invocation.getArgument(0);
            savedCompletion.set(evidence);
            completionInserted.countDown();
            return evidence;
        });
        when(fixture.candidateRepository.findByStatus(ReceiptCandidateStatus.PENDING_COMPLETION))
                .thenAnswer(invocation -> List.of(savedCandidate.get()));
        when(fixture.receiptIssuanceService.issueIfReady(any(ReceiptCandidate.class))).thenAnswer(invocation -> {
            ReceiptCandidate candidate = invocation.getArgument(0);
            if (issuanceCount.incrementAndGet() == 1) {
                candidate.setStatus(ReceiptCandidateStatus.ISSUED);
                candidate.setResolutionCode("ISSUED");
                return ReceiptIssuanceResult.issued();
            }
            return ReceiptIssuanceResult.skipped("RECEIPT_ALREADY_ISSUED");
        });

        ExecutorService executor = Executors.newFixedThreadPool(2);
        try {
            Future<ReceiptCandidateResult> captureResult = executor.submit(() -> {
                Thread.currentThread().setName("capture-thread");
                return fixture.service.capture(capture);
            });
            Future<ReceiptCandidateResult> completionResult = executor.submit(() -> {
                Thread.currentThread().setName("completion-thread");
                return fixture.service.complete(completion);
            });

            assertEquals("PENDING_COMPLETION", captureResult.get(5, TimeUnit.SECONDS).resolutionCode());
            assertEquals("WAITING_FOR_CANDIDATE", completionResult.get(5, TimeUnit.SECONDS).resolutionCode());

            reconciliationPass.set(true);
            fixture.service.reconcileReadyCandidates();

            assertEquals(1, issuanceCount.get());
            assertEquals(ReceiptCandidateStatus.ISSUED, savedCandidate.get().getStatus());
            verify(fixture.receiptIssuanceService, times(1)).issueIfReady(savedCandidate.get());
        } finally {
            executor.shutdownNow();
        }
    }

    private void await(CountDownLatch latch) {
        try {
            assertTrue(latch.await(5, TimeUnit.SECONDS));
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new AssertionError("Interrupted while simulating concurrent processing", exception);
        }
    }

    private Fixture fixture() {
        ReceiptCandidateRepository candidateRepository = mock(ReceiptCandidateRepository.class);
        ExperienceCompletionEvidenceRepository completionRepository =
                mock(ExperienceCompletionEvidenceRepository.class);
        FinanceReviewCaseRepository financeReviewCaseRepository = mock(FinanceReviewCaseRepository.class);
        ReceiptIssuanceService receiptIssuanceService = mock(ReceiptIssuanceService.class);
        BillingProperties properties = new BillingProperties();
        properties.setReceiptFeatureLaunchAt(Instant.parse("2026-01-01T00:00:00Z"));
        return new Fixture(
                candidateRepository,
                completionRepository,
                financeReviewCaseRepository,
                receiptIssuanceService,
                new ReceiptCandidateService(
                        candidateRepository,
                        completionRepository,
                        financeReviewCaseRepository,
                        receiptIssuanceService,
                        properties));
    }

    private ReceiptEligibilityCapturedEvent validCaptureEvent() {
        ReceiptEligibilityCapturedEvent event = new ReceiptEligibilityCapturedEvent();
        event.setEventId("payment-event-1");
        event.setProducer("booking-service");
        event.setBookingId("MFB-100");
        event.setUserId(41L);
        event.setUserEmail("customer@example.com");
        event.setExperienceName("Sunrise walk");
        event.setExpectedAmount(new BigDecimal("100.00"));
        event.setExpectedCurrency("INR");
        event.setPaymentTransactionId("pay_100");
        event.setAmountPaid(new BigDecimal("100.00"));
        event.setCurrencyPaid("INR");
        event.setPaidAt(Instant.parse("2026-10-18T12:00:00Z"));
        event.setBookingDate(Instant.parse("2026-12-01T06:00:00Z"));
        return event;
    }

    private ExperienceCompletedEvent completionEvent() {
        ExperienceCompletedEvent event = new ExperienceCompletedEvent();
        event.setEventId("completion-event-1");
        event.setProducer("booking-service");
        event.setBookingId("MFB-100");
        event.setCompletedAt(Instant.parse("2026-12-01T12:00:00Z"));
        return event;
    }

    private record Fixture(
            ReceiptCandidateRepository candidateRepository,
            ExperienceCompletionEvidenceRepository completionRepository,
            FinanceReviewCaseRepository financeReviewCaseRepository,
            ReceiptIssuanceService receiptIssuanceService,
            ReceiptCandidateService service) {
    }
}
