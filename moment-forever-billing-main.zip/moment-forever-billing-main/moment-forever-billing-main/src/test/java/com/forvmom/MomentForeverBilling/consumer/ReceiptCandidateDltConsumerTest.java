package com.forvmom.MomentForeverBilling.consumer;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.support.Acknowledgment;

import java.nio.charset.StandardCharsets;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;

class ReceiptCandidateDltConsumerTest {

    @Test
    void malformedRawDltPayloadIsAcknowledgedWithoutJsonDeserialization() {
        ReceiptCandidateDltConsumer consumer = new ReceiptCandidateDltConsumer();
        Acknowledgment acknowledgment = mock(Acknowledgment.class);
        ConsumerRecord<String, byte[]> record = new ConsumerRecord<>(
                "topic_receipt_eligibility_captured.DLT",
                0,
                42L,
                "booking-1",
                "{not-json".getBytes(StandardCharsets.UTF_8));

        consumer.onDeadLetter(record, acknowledgment);

        verify(acknowledgment).acknowledge();
    }
}
