package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.DocumentStatus;
import com.forvmom.MomentForeverBilling.domain.FiscalDocument;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidate;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidateStatus;
import com.forvmom.MomentForeverBilling.repository.FiscalDocumentRepository;
import com.forvmom.MomentForeverBilling.repository.ReceiptCandidateRepository;
import com.forvmom.MomentForeverBilling.storage.StorageRegistry;
import com.forvmom.MomentForeverBilling.storage.StoredDocument;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ReceiptIssuanceServiceTest {

    @Test
    void completionIssuanceCreatesOneImmutableReceiptWithoutDeliveryOutbox() {
        FiscalDocumentRepository documentRepository = mock(FiscalDocumentRepository.class);
        ReceiptCandidateRepository candidateRepository = mock(ReceiptCandidateRepository.class);
        ReceiptSequenceService sequenceService = mock(ReceiptSequenceService.class);
        ReceiptPdfRenderer pdfRenderer = mock(ReceiptPdfRenderer.class);
        StorageRegistry storageRegistry = mock(StorageRegistry.class);
        ReceiptIssuanceService service = new ReceiptIssuanceService(
                documentRepository,
                candidateRepository,
                sequenceService,
                pdfRenderer,
                storageRegistry,
                new BillingProperties());
        ReceiptCandidate candidate = validCandidate();
        when(documentRepository.findByBookingId(candidate.getBookingId())).thenReturn(Optional.empty());
        when(sequenceService.nextReceiptNumber(any()))
                .thenReturn(new ReceiptNumber("FY2026-27", "MF-R-FY2026-27-000001"));
        when(pdfRenderer.render(any(FiscalDocument.class))).thenReturn(new byte[]{1, 2, 3});
        when(storageRegistry.store(any(), any()))
                .thenReturn(new StoredDocument("gridfs", "opaque-storage-key", 3, "application/pdf"));

        ReceiptIssuanceResult result = service.issueIfReady(candidate);

        assertEquals("ISSUED", result.resolutionCode());
        assertEquals(ReceiptCandidateStatus.ISSUED, candidate.getStatus());
        ArgumentCaptor<FiscalDocument> document = ArgumentCaptor.forClass(FiscalDocument.class);
        verify(documentRepository).insert(document.capture());
        assertEquals(DocumentStatus.ISSUED, document.getValue().getStatus());
        assertEquals(candidate.getBookingId(), document.getValue().getBookingId());
        assertEquals(candidate.getAmountPaid(), document.getValue().getPaidAmount());
        verify(candidateRepository).save(candidate);
    }

    @Test
    void reviewCandidateCannotIssueReceipt() {
        FiscalDocumentRepository documentRepository = mock(FiscalDocumentRepository.class);
        ReceiptCandidateRepository candidateRepository = mock(ReceiptCandidateRepository.class);
        ReceiptSequenceService sequenceService = mock(ReceiptSequenceService.class);
        ReceiptPdfRenderer pdfRenderer = mock(ReceiptPdfRenderer.class);
        StorageRegistry storageRegistry = mock(StorageRegistry.class);
        ReceiptIssuanceService service = new ReceiptIssuanceService(
                documentRepository,
                candidateRepository,
                sequenceService,
                pdfRenderer,
                storageRegistry,
                new BillingProperties());
        ReceiptCandidate candidate = validCandidate();
        candidate.setStatus(ReceiptCandidateStatus.REVIEW_REQUIRED);

        ReceiptIssuanceResult result = service.issueIfReady(candidate);

        assertEquals("REVIEW_REQUIRED", result.resolutionCode());
        verify(documentRepository, never()).insert(any(FiscalDocument.class));
        verify(storageRegistry, never()).store(any(), any());
    }

    private ReceiptCandidate validCandidate() {
        ReceiptCandidate candidate = new ReceiptCandidate();
        candidate.setBookingId("MFB-100");
        candidate.setOwnerUserId(41L);
        candidate.setTrustedAccountEmail("customer@example.com");
        candidate.setExperienceName("Sunrise walk");
        candidate.setExpectedAmount(new BigDecimal("100.00"));
        candidate.setExpectedCurrency("INR");
        candidate.setPaymentTransactionId("pay_100");
        candidate.setAmountPaid(new BigDecimal("100.00"));
        candidate.setCurrencyPaid("INR");
        candidate.setPaidAt(Instant.parse("2026-10-18T12:00:00Z"));
        candidate.setBookingDate(Instant.parse("2026-12-01T06:00:00Z"));
        candidate.setStatus(ReceiptCandidateStatus.PENDING_COMPLETION);
        return candidate;
    }
}
