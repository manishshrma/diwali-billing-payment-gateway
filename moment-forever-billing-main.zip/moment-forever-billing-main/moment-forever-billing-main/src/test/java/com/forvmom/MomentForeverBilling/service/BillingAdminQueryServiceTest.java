package com.forvmom.MomentForeverBilling.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.forvmom.MomentForeverBilling.domain.BillingOutbox;
import com.forvmom.MomentForeverBilling.domain.DocumentStatus;
import com.forvmom.MomentForeverBilling.domain.FinanceReviewCase;
import com.forvmom.MomentForeverBilling.domain.FiscalDocument;
import com.forvmom.MomentForeverBilling.domain.OutboxStatus;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidate;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidateStatus;
import com.forvmom.MomentForeverBilling.domain.StorageMetadata;
import com.forvmom.MomentForeverBilling.dto.AdminFinanceReviewResponse;
import com.forvmom.MomentForeverBilling.dto.AdminOutboxResponse;
import com.forvmom.MomentForeverBilling.dto.AdminReceiptCandidateResponse;
import com.forvmom.MomentForeverBilling.dto.AdminReceiptResponse;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;
import org.springframework.data.domain.Page;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Query;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class BillingAdminQueryServiceTest {

    private final ObjectMapper objectMapper = new ObjectMapper().registerModule(new JavaTimeModule());

    @Test
    void filtersAndPaginatesIssuedReceiptsWithoutLeakingPrivateFields() throws Exception {
        MongoTemplate mongoTemplate = mock(MongoTemplate.class);
        BillingAdminQueryService service = new BillingAdminQueryService(mongoTemplate);
        FiscalDocument document = receipt();
        when(mongoTemplate.count(any(Query.class), eq(FiscalDocument.class))).thenReturn(51L);
        when(mongoTemplate.find(any(Query.class), eq(FiscalDocument.class))).thenReturn(List.of(document));

        Page<AdminReceiptResponse> result = service.receipts(
                "MFB-100",
                Instant.parse("2026-10-01T00:00:00Z"),
                Instant.parse("2026-10-31T23:59:59Z"),
                1,
                25);

        ArgumentCaptor<Query> query = ArgumentCaptor.forClass(Query.class);
        verify(mongoTemplate).find(query.capture(), eq(FiscalDocument.class));
        assertThat(valuesFor(query.getValue(), "bookingId")).containsExactly("MFB-100");
        assertThat(valuesFor(query.getValue(), "status")).contains(DocumentStatus.ISSUED);
        assertThat(valuesFor(query.getValue(), "issuedAt")).hasSize(1);
        assertThat(query.getValue().getSkip()).isEqualTo(25L);
        assertThat(query.getValue().getLimit()).isEqualTo(25);
        assertThat(result.getTotalElements()).isEqualTo(51L);

        String responseJson = objectMapper.writeValueAsString(result.getContent().get(0));
        assertThat(responseJson)
                .doesNotContain("trustedAccountEmail")
                .doesNotContain("customer@example.com")
                .doesNotContain("paymentTransactionId")
                .doesNotContain("pay_100")
                .doesNotContain("expectedAmount")
                .doesNotContain("raw-storage-key");
    }

    @Test
    void filtersCandidatesReviewsAndOutboxWithRedactedResponses() throws Exception {
        MongoTemplate mongoTemplate = mock(MongoTemplate.class);
        BillingAdminQueryService service = new BillingAdminQueryService(mongoTemplate);
        ReceiptCandidate candidate = candidate();
        FinanceReviewCase review = review();
        BillingOutbox outbox = outbox();
        when(mongoTemplate.count(any(Query.class), eq(ReceiptCandidate.class))).thenReturn(1L);
        when(mongoTemplate.find(any(Query.class), eq(ReceiptCandidate.class))).thenReturn(List.of(candidate));
        when(mongoTemplate.count(any(Query.class), eq(FinanceReviewCase.class))).thenReturn(1L);
        when(mongoTemplate.find(any(Query.class), eq(FinanceReviewCase.class))).thenReturn(List.of(review));
        when(mongoTemplate.count(any(Query.class), eq(BillingOutbox.class))).thenReturn(1L);
        when(mongoTemplate.find(any(Query.class), eq(BillingOutbox.class))).thenReturn(List.of(outbox));

        Page<AdminReceiptCandidateResponse> candidates = service.candidates(
                "MFB-100",
                ReceiptCandidateStatus.REVIEW_REQUIRED,
                Instant.parse("2026-10-01T00:00:00Z"),
                Instant.parse("2026-10-31T23:59:59Z"),
                1,
                10);
        Page<AdminFinanceReviewResponse> reviews = service.financeReviews(
                "MFB-100",
                "OPEN",
                Instant.parse("2026-10-01T00:00:00Z"),
                Instant.parse("2026-10-31T23:59:59Z"),
                0,
                10);
        Page<AdminOutboxResponse> outboxEntries = service.outbox(
                OutboxStatus.FAILED,
                Instant.parse("2026-10-01T00:00:00Z"),
                Instant.parse("2026-10-31T23:59:59Z"),
                0,
                10);

        ArgumentCaptor<Query> candidateQuery = ArgumentCaptor.forClass(Query.class);
        ArgumentCaptor<Query> reviewQuery = ArgumentCaptor.forClass(Query.class);
        ArgumentCaptor<Query> outboxQuery = ArgumentCaptor.forClass(Query.class);
        verify(mongoTemplate).find(candidateQuery.capture(), eq(ReceiptCandidate.class));
        verify(mongoTemplate).find(reviewQuery.capture(), eq(FinanceReviewCase.class));
        verify(mongoTemplate).find(outboxQuery.capture(), eq(BillingOutbox.class));
        assertThat(valuesFor(candidateQuery.getValue(), "bookingId")).containsExactly("MFB-100");
        assertThat(valuesFor(candidateQuery.getValue(), "status"))
                .contains(ReceiptCandidateStatus.REVIEW_REQUIRED);
        assertThat(valuesFor(candidateQuery.getValue(), "capturedAt")).hasSize(1);
        assertThat(candidateQuery.getValue().getSkip()).isEqualTo(10L);
        assertThat(valuesFor(reviewQuery.getValue(), "bookingId")).containsExactly("MFB-100");
        assertThat(valuesFor(reviewQuery.getValue(), "status")).containsExactly("OPEN");
        assertThat(valuesFor(reviewQuery.getValue(), "createdAt")).hasSize(1);
        assertThat(valuesFor(outboxQuery.getValue(), "status")).containsExactly(OutboxStatus.FAILED);
        assertThat(valuesFor(outboxQuery.getValue(), "updatedAt")).hasSize(1);

        String responseJson = objectMapper.writeValueAsString(candidates.getContent().get(0))
                + objectMapper.writeValueAsString(reviews.getContent().get(0))
                + objectMapper.writeValueAsString(outboxEntries.getContent().get(0));
        assertThat(responseJson)
                .doesNotContain("trustedAccountEmail")
                .doesNotContain("customer@example.com")
                .doesNotContain("paymentTransactionId")
                .doesNotContain("pay_100")
                .doesNotContain("paidAmount")
                .doesNotContain("payload")
                .doesNotContain("recipientEmail");
    }

    private FiscalDocument receipt() {
        FiscalDocument document = new FiscalDocument();
        document.setDocumentId("receipt_100");
        document.setBookingId("MFB-100");
        document.setTrustedAccountEmail("customer@example.com");
        document.setDocumentType("PAYMENT_RECEIPT_NON_GST");
        document.setReceiptNumber("MF-R-2026-000001");
        document.setFinancialYear("2026-27");
        document.setStatus(DocumentStatus.ISSUED);
        document.setIssuedAt(Instant.parse("2026-10-20T00:00:00Z"));
        document.setExpectedAmount(new BigDecimal("100.00"));
        document.setPaidAmount(new BigDecimal("100.00"));
        document.setPaymentTransactionId("pay_100");
        document.setStorage(new StorageMetadata(
                "gridfs",
                "raw-storage-key",
                "checksum",
                10L,
                "application/pdf"));
        return document;
    }

    private ReceiptCandidate candidate() {
        ReceiptCandidate candidate = new ReceiptCandidate();
        candidate.setBookingId("MFB-100");
        candidate.setTrustedAccountEmail("customer@example.com");
        candidate.setPaymentTransactionId("pay_100");
        candidate.setExpectedAmount(new BigDecimal("100.00"));
        candidate.setAmountPaid(new BigDecimal("99.00"));
        candidate.setStatus(ReceiptCandidateStatus.REVIEW_REQUIRED);
        candidate.setResolutionCode("AMOUNT_MISMATCH");
        candidate.setCapturedAt(Instant.parse("2026-10-20T00:00:00Z"));
        return candidate;
    }

    private FinanceReviewCase review() {
        FinanceReviewCase review = new FinanceReviewCase();
        review.setBookingId("MFB-100");
        review.setReasonCode("AMOUNT_MISMATCH");
        review.setStatus("OPEN");
        review.setPaymentTransactionId("pay_100");
        review.setExpectedAmount(new BigDecimal("100.00"));
        review.setPaidAmount(new BigDecimal("99.00"));
        review.setCreatedAt(Instant.parse("2026-10-20T00:00:00Z"));
        return review;
    }

    private BillingOutbox outbox() {
        BillingOutbox outbox = new BillingOutbox();
        outbox.setAggregateId("receipt_100");
        outbox.setEventType("RECEIPT_DELIVERY_REQUESTED");
        outbox.setPayload("{\"recipientEmail\":\"customer@example.com\"}");
        outbox.setStatus(OutboxStatus.FAILED);
        outbox.setRetryCount(2);
        outbox.setCreatedAt(Instant.parse("2026-10-20T00:00:00Z"));
        outbox.setUpdatedAt(Instant.parse("2026-10-20T00:05:00Z"));
        return outbox;
    }

    private List<Object> valuesFor(Query query, String field) {
        return ((List<?>) query.getQueryObject().get("$and")).stream()
                .filter(org.bson.Document.class::isInstance)
                .map(org.bson.Document.class::cast)
                .filter(clause -> clause.containsKey(field))
                .map(clause -> clause.get(field))
                .toList();
    }
}
