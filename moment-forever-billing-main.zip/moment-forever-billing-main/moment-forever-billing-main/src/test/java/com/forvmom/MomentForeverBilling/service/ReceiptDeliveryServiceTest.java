package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.domain.BillingOutbox;
import com.forvmom.MomentForeverBilling.domain.DeliveryAudit;
import com.forvmom.MomentForeverBilling.domain.DocumentStatus;
import com.forvmom.MomentForeverBilling.domain.FiscalDocument;
import com.forvmom.MomentForeverBilling.exception.ReceiptRateLimitExceededException;
import com.forvmom.MomentForeverBilling.repository.DeliveryAuditRepository;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class ReceiptDeliveryServiceTest {

    @Test
    void resendRateLimitRejectsBeforeCreatingAuditOrDeliveryEvent() {
        ReceiptQueryService queryService = mock(ReceiptQueryService.class);
        ReceiptResendRateLimiter rateLimiter = mock(ReceiptResendRateLimiter.class);
        DeliveryAuditRepository auditRepository = mock(DeliveryAuditRepository.class);
        BillingOutboxService outboxService = mock(BillingOutboxService.class);
        ReceiptDeliveryService service = new ReceiptDeliveryService(
                queryService, rateLimiter, auditRepository, outboxService);
        FiscalDocument document = issuedDocument();
        when(queryService.ownedIssuedDocument("receipt_1", 41L)).thenReturn(document);
        when(rateLimiter.tryAcquire("receipt_1", 41L)).thenReturn(false);

        assertThrows(ReceiptRateLimitExceededException.class,
                () -> service.requestResend("receipt_1", 41L, null));

        verify(auditRepository, never()).insert(any(DeliveryAudit.class));
        verify(outboxService, never()).enqueueReceiptDelivery(any());
    }

    @Test
    void alternateEmailQueuesAuditedResendImmediately() {
        ReceiptQueryService queryService = mock(ReceiptQueryService.class);
        ReceiptResendRateLimiter rateLimiter = mock(ReceiptResendRateLimiter.class);
        DeliveryAuditRepository auditRepository = mock(DeliveryAuditRepository.class);
        BillingOutboxService outboxService = mock(BillingOutboxService.class);
        ReceiptDeliveryService service = new ReceiptDeliveryService(
                queryService, rateLimiter, auditRepository, outboxService);
        FiscalDocument document = issuedDocument();
        when(queryService.ownedIssuedDocument("receipt_1", 41L)).thenReturn(document);
        when(rateLimiter.tryAcquire("receipt_1", 41L)).thenReturn(true);
        when(outboxService.enqueueReceiptDelivery(any())).thenReturn(new BillingOutbox());

        service.requestResend("receipt_1", 41L, "alternate@example.com");

        verify(auditRepository).insert(any(DeliveryAudit.class));
        verify(outboxService).enqueueReceiptDelivery(any());
    }

    private FiscalDocument issuedDocument() {
        FiscalDocument document = new FiscalDocument();
        document.setDocumentId("receipt_1");
        document.setBookingId("booking_1");
        document.setOwnerUserId(41L);
        document.setTrustedAccountEmail("trusted@example.com");
        document.setReceiptNumber("MF-R-FY2026-27-000001");
        document.setStatus(DocumentStatus.ISSUED);
        document.setIssuedAt(Instant.now());
        return document;
    }
}
