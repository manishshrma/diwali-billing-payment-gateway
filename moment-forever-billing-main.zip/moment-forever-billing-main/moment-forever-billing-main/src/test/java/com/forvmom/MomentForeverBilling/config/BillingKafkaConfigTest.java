package com.forvmom.MomentForeverBilling.config;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.ByteArrayDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.junit.jupiter.api.Test;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.test.util.ReflectionTestUtils;

import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;

class BillingKafkaConfigTest {

    @Test
    void dltConsumerUsesRawBytesInsteadOfJsonTypeDeserialization() {
        BillingKafkaConfig config = new BillingKafkaConfig();
        ReflectionTestUtils.setField(config, "bootstrapServers", "localhost:9092");

        DefaultKafkaConsumerFactory<String, byte[]> consumerFactory =
                (DefaultKafkaConsumerFactory<String, byte[]>) config.billingDltConsumerFactory();
        Map<String, Object> properties = consumerFactory.getConfigurationProperties();

        assertEquals(StringDeserializer.class, properties.get(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG));
        assertEquals(ByteArrayDeserializer.class, properties.get(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG));
        assertFalse(properties.containsKey("spring.deserializer.value.delegate.class"));
    }
}
