package com.forvmom.MomentForeverBilling.domain;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.Instant;

@Data
@Document("fiscal_documents")
@CompoundIndex(name = "uq_fiscal_document_booking", def = "{'bookingId': 1}", unique = true)
public class FiscalDocument {

    @Id
    private String id;

    @Indexed(unique = true)
    private String documentId;

    @Indexed
    private String bookingId;

    @Indexed
    private Long ownerUserId;

    private String trustedAccountEmail;
    private String documentType;
    private String receiptNumber;
    private String financialYear;
    private DocumentStatus status;
    private Instant issuedAt;
    private String issuerName;
    private String issuerCountry;
    private String currency;
    private BigDecimal expectedAmount;
    private BigDecimal paidAmount;
    private String paymentTransactionId;
    private Instant paymentPaidAt;
    private String experienceName;
    private Instant bookingDate;
    private StorageMetadata storage;
}
