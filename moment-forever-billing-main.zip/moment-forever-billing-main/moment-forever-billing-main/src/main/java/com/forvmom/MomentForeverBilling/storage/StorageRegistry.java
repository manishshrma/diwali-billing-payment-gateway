package com.forvmom.MomentForeverBilling.storage;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.StorageMetadata;
import org.springframework.stereotype.Component;

import java.io.InputStream;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Component
public class StorageRegistry {

    private final BillingProperties properties;
    private final Map<String, PrivateDocumentStorage> storageByProvider;

    public StorageRegistry(BillingProperties properties, List<PrivateDocumentStorage> storages) {
        this.properties = properties;
        this.storageByProvider = storages.stream()
                .collect(Collectors.toUnmodifiableMap(
                        storage -> storage.provider().toLowerCase(),
                        Function.identity()));
    }

    public StoredDocument store(byte[] content, String contentType) {
        return selectedStorage().store(content, contentType);
    }

    public InputStream open(StorageMetadata metadata) {
        return storageFor(metadata.getProvider()).open(metadata);
    }

    public void delete(StorageMetadata metadata) {
        storageFor(metadata.getProvider()).delete(metadata);
    }

    private PrivateDocumentStorage selectedStorage() {
        return storageFor(properties.getStorage().getProvider());
    }

    private PrivateDocumentStorage storageFor(String provider) {
        PrivateDocumentStorage storage = storageByProvider.get(provider == null ? "" : provider.toLowerCase());
        if (storage == null) {
            throw new IllegalStateException("No private document storage is configured for the requested provider");
        }
        return storage;
    }
}
