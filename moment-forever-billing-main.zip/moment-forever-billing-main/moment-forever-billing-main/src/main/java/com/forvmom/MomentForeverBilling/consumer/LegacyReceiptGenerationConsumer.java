package com.forvmom.MomentForeverBilling.consumer;

import com.forvmom.MomentForeverBilling.events.ReceiptGenerationRequestedEvent;
import com.forvmom.MomentForeverBilling.service.ReceiptCandidateResult;
import com.forvmom.MomentForeverBilling.service.ReceiptCandidateService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.kafka.support.Acknowledgment;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Component;

@Component
public class LegacyReceiptGenerationConsumer {

    private static final Logger log = LoggerFactory.getLogger(LegacyReceiptGenerationConsumer.class);

    private final ReceiptCandidateService receiptCandidateService;

    public LegacyReceiptGenerationConsumer(ReceiptCandidateService receiptCandidateService) {
        this.receiptCandidateService = receiptCandidateService;
    }

    @KafkaListener(
            topics = "${kafka.topics.receipt-generation-requested}",
            groupId = "billing-legacy-receipt-candidate-group",
            containerFactory = "billingKafkaListenerContainerFactory")
    public void onLegacyReceiptGenerationRequested(
            @Payload ReceiptGenerationRequestedEvent event,
            Acknowledgment acknowledgment) {
        ReceiptCandidateResult result = receiptCandidateService.captureLegacy(event);
        acknowledgment.acknowledge();
        log.warn("Legacy receipt-generation event captured without issuance: bookingId={}, resolution={}",
                event.getBookingId(), result.resolutionCode());
    }
}
