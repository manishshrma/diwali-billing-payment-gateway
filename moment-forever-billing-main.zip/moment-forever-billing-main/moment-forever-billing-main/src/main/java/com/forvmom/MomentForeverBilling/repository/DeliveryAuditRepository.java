package com.forvmom.MomentForeverBilling.repository;

import com.forvmom.MomentForeverBilling.domain.DeliveryAudit;
import org.springframework.data.mongodb.repository.MongoRepository;

public interface DeliveryAuditRepository extends MongoRepository<DeliveryAudit, String> {
}
