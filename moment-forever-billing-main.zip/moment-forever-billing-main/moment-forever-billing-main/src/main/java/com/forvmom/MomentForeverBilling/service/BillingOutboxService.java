package com.forvmom.MomentForeverBilling.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.forvmom.MomentForeverBilling.domain.BillingOutbox;
import com.forvmom.MomentForeverBilling.domain.OutboxStatus;
import com.forvmom.MomentForeverBilling.events.ReceiptDeliveryRequestedEvent;
import com.forvmom.MomentForeverBilling.repository.BillingOutboxRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

@Service
public class BillingOutboxService {

    public static final String RECEIPT_DELIVERY_REQUESTED = "RECEIPT_DELIVERY_REQUESTED";

    private final BillingOutboxRepository outboxRepository;
    private final ObjectMapper objectMapper;

    public BillingOutboxService(BillingOutboxRepository outboxRepository, ObjectMapper objectMapper) {
        this.outboxRepository = outboxRepository;
        this.objectMapper = objectMapper;
    }

    @Transactional
    public BillingOutbox enqueueReceiptDelivery(ReceiptDeliveryRequestedEvent event) {
        BillingOutbox outbox = new BillingOutbox();
        outbox.setAggregateId(event.getDocumentId());
        outbox.setEventType(RECEIPT_DELIVERY_REQUESTED);
        outbox.setPayload(serialize(event));
        outbox.setStatus(OutboxStatus.PENDING);
        outbox.setRetryCount(0);
        outbox.setCreatedAt(Instant.now());
        outbox.setUpdatedAt(outbox.getCreatedAt());
        return outboxRepository.insert(outbox);
    }

    @Transactional
    public void markSent(BillingOutbox outbox) {
        outbox.setStatus(OutboxStatus.SENT);
        outbox.setUpdatedAt(Instant.now());
        outboxRepository.save(outbox);
    }

    @Transactional
    public void markFailed(BillingOutbox outbox) {
        outbox.setStatus(OutboxStatus.FAILED);
        outbox.setUpdatedAt(Instant.now());
        outboxRepository.save(outbox);
    }

    @Transactional
    public void incrementRetry(BillingOutbox outbox) {
        outbox.setRetryCount(outbox.getRetryCount() + 1);
        outbox.setUpdatedAt(Instant.now());
        outboxRepository.save(outbox);
    }

    @Transactional
    public void markDead(BillingOutbox outbox) {
        outbox.setStatus(OutboxStatus.DEAD);
        outbox.setUpdatedAt(Instant.now());
        outboxRepository.save(outbox);
    }

    public ReceiptDeliveryRequestedEvent readDeliveryEvent(BillingOutbox outbox) {
        try {
            return objectMapper.readValue(outbox.getPayload(), ReceiptDeliveryRequestedEvent.class);
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("Could not deserialize a billing outbox event", exception);
        }
    }

    private String serialize(ReceiptDeliveryRequestedEvent event) {
        try {
            return objectMapper.writeValueAsString(event);
        } catch (JsonProcessingException exception) {
            throw new IllegalStateException("Could not serialize a billing outbox event", exception);
        }
    }
}
