package com.forvmom.MomentForeverBilling.controller;

import com.forvmom.MomentForeverBilling.domain.OutboxStatus;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidateStatus;
import com.forvmom.MomentForeverBilling.dto.AdminFinanceReviewResponse;
import com.forvmom.MomentForeverBilling.dto.AdminOutboxResponse;
import com.forvmom.MomentForeverBilling.dto.AdminReceiptCandidateResponse;
import com.forvmom.MomentForeverBilling.dto.AdminReceiptResponse;
import com.forvmom.MomentForeverBilling.exception.BillingAccessDeniedException;
import com.forvmom.MomentForeverBilling.service.BillingAdminQueryService;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.data.domain.Page;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.util.StringUtils;

import java.time.Instant;

@RestController
@RequestMapping(BillingAdminController.BASE_PATH)
@ConditionalOnProperty(prefix = "billing.admin", name = "endpoints-enabled", havingValue = "true")
public class BillingAdminController {

    public static final String BASE_PATH = "/admin/receipt-tracking";

    private final BillingAdminQueryService billingAdminQueryService;

    public BillingAdminController(BillingAdminQueryService billingAdminQueryService) {
        this.billingAdminQueryService = billingAdminQueryService;
    }

    @GetMapping("/receipts")
    public Page<AdminReceiptResponse> receipts(
            @RequestHeader(value = "X-User-Roles", required = false) String roles,
            @RequestParam(required = false) String bookingId,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "25") int size) {
        requireAdminRole(roles);
        return billingAdminQueryService.receipts(bookingId, from, to, page, size);
    }

    @GetMapping("/candidates")
    public Page<AdminReceiptCandidateResponse> candidates(
            @RequestHeader(value = "X-User-Roles", required = false) String roles,
            @RequestParam(required = false) String bookingId,
            @RequestParam(required = false) ReceiptCandidateStatus status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "25") int size) {
        requireAdminRole(roles);
        return billingAdminQueryService.candidates(bookingId, status, from, to, page, size);
    }

    @GetMapping("/finance-reviews")
    public Page<AdminFinanceReviewResponse> financeReviews(
            @RequestHeader(value = "X-User-Roles", required = false) String roles,
            @RequestParam(required = false) String bookingId,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "25") int size) {
        requireAdminRole(roles);
        return billingAdminQueryService.financeReviews(bookingId, status, from, to, page, size);
    }

    @GetMapping("/outbox")
    public Page<AdminOutboxResponse> outbox(
            @RequestHeader(value = "X-User-Roles", required = false) String roles,
            @RequestParam(required = false) OutboxStatus status,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "25") int size) {
        requireAdminRole(roles);
        return billingAdminQueryService.outbox(status, from, to, page, size);
    }

    private void requireAdminRole(String roles) {
        if (!StringUtils.hasText(roles)) {
            throw new BillingAccessDeniedException("An administrative role is required");
        }
        for (String role : roles.split(",")) {
            String normalized = role.trim();
            if ("ADMIN".equalsIgnoreCase(normalized) || "SUPER_ADMIN".equalsIgnoreCase(normalized)) {
                return;
            }
        }
        throw new BillingAccessDeniedException("An administrative role is required");
    }
}
