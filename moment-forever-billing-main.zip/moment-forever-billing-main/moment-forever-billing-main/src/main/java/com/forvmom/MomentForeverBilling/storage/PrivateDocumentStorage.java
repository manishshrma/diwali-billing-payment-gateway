package com.forvmom.MomentForeverBilling.storage;

import com.forvmom.MomentForeverBilling.domain.StorageMetadata;

import java.io.InputStream;

public interface PrivateDocumentStorage {

    String provider();

    StoredDocument store(byte[] content, String contentType);

    InputStream open(StorageMetadata metadata);

    void delete(StorageMetadata metadata);
}
