package com.forvmom.MomentForeverBilling;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
@EnableConfigurationProperties(BillingProperties.class)
public class MomentForeverBillingApplication {

    public static void main(String[] args) {
        SpringApplication.run(MomentForeverBillingApplication.class, args);
    }
}
