package com.forvmom.MomentForeverBilling.repository;

import com.forvmom.MomentForeverBilling.domain.ReceiptCandidate;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidateStatus;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface ReceiptCandidateRepository extends MongoRepository<ReceiptCandidate, String> {

    Optional<ReceiptCandidate> findBySourceEventId(String sourceEventId);

    Optional<ReceiptCandidate> findByBookingId(String bookingId);

    List<ReceiptCandidate> findByStatus(ReceiptCandidateStatus status);

    List<ReceiptCandidate> findByOwnerUserIdAndBookingIdIn(Long ownerUserId, Collection<String> bookingIds);
}
