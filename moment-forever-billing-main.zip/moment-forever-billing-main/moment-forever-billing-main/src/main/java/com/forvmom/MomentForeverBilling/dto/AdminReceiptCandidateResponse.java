package com.forvmom.MomentForeverBilling.dto;

import java.time.Instant;

public record AdminReceiptCandidateResponse(
        String bookingId,
        String status,
        String resolutionCode,
        Instant capturedAt,
        Instant issuedAt) {
}
