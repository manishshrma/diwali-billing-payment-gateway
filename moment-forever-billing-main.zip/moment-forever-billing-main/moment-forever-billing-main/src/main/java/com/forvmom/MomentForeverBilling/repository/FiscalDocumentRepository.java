package com.forvmom.MomentForeverBilling.repository;

import com.forvmom.MomentForeverBilling.domain.DocumentStatus;
import com.forvmom.MomentForeverBilling.domain.FiscalDocument;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

public interface FiscalDocumentRepository extends MongoRepository<FiscalDocument, String> {

    Optional<FiscalDocument> findByDocumentId(String documentId);

    Optional<FiscalDocument> findByBookingId(String bookingId);

    List<FiscalDocument> findByOwnerUserIdAndBookingIdInAndStatus(
            Long ownerUserId,
            Collection<String> bookingIds,
            DocumentStatus status);
}
