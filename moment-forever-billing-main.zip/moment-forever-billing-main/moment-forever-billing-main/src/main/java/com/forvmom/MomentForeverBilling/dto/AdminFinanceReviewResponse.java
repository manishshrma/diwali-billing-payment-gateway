package com.forvmom.MomentForeverBilling.dto;

import java.time.Instant;

public record AdminFinanceReviewResponse(
        String bookingId,
        String reasonCode,
        String status,
        Instant createdAt) {
}
