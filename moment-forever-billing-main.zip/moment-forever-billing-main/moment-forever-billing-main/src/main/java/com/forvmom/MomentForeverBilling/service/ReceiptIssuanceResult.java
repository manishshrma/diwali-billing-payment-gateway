package com.forvmom.MomentForeverBilling.service;

public record ReceiptIssuanceResult(String resolutionCode) {

    public static ReceiptIssuanceResult issued() {
        return new ReceiptIssuanceResult("ISSUED");
    }

    public static ReceiptIssuanceResult skipped(String resolutionCode) {
        return new ReceiptIssuanceResult(resolutionCode);
    }
}
