package com.forvmom.MomentForeverBilling.domain;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.math.BigDecimal;
import java.time.Instant;

@Data
@Document("receipt_candidates")
@CompoundIndexes({
        @CompoundIndex(name = "uq_receipt_candidate_booking", def = "{'bookingId': 1}", unique = true, sparse = true),
        @CompoundIndex(name = "uq_receipt_candidate_source_event", def = "{'sourceEventId': 1}", unique = true)
})
public class ReceiptCandidate {

    @Id
    private String id;

    private String sourceEventId;
    private String sourceProducer;
    private String bookingId;
    private Long ownerUserId;
    private String trustedAccountEmail;
    private String userFullName;
    private String experienceName;
    private Instant bookingDate;
    private BigDecimal expectedAmount;
    private String expectedCurrency;
    private String paymentTransactionId;
    private BigDecimal amountPaid;
    private String currencyPaid;
    private Instant paidAt;
    @Indexed
    private ReceiptCandidateStatus status;
    private String resolutionCode;
    private Instant capturedAt;
    private Instant issuedAt;
}
