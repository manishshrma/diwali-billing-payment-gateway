package com.forvmom.MomentForeverBilling.config;

import com.forvmom.MomentForeverBilling.controller.BillingAdminController;
import org.springdoc.core.customizers.OpenApiCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration(proxyBeanMethods = false)
public class BillingAdminOpenApiConfig {

    @Bean
    public OpenApiCustomizer billingAdminOpenApiCustomizer(BillingProperties properties) {
        return openApi -> {
            if (properties.getAdmin().isSwaggerVisible() || openApi.getPaths() == null) {
                return;
            }
            openApi.getPaths().keySet().removeIf(path ->
                    path.startsWith(BillingAdminController.BASE_PATH));
        };
    }
}
