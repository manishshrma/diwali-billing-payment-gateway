package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.domain.DocumentStatus;
import com.forvmom.MomentForeverBilling.domain.FiscalDocument;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidate;
import com.forvmom.MomentForeverBilling.domain.ReceiptCandidateStatus;
import com.forvmom.MomentForeverBilling.dto.ReceiptAvailabilityResponse;
import com.forvmom.MomentForeverBilling.exception.BillingAccessDeniedException;
import com.forvmom.MomentForeverBilling.exception.BillingNotFoundException;
import com.forvmom.MomentForeverBilling.repository.FiscalDocumentRepository;
import com.forvmom.MomentForeverBilling.repository.ReceiptCandidateRepository;
import com.forvmom.MomentForeverBilling.storage.StorageRegistry;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Collection;
import java.util.HexFormat;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
public class ReceiptQueryService {

    private static final int MAX_BULK_BOOKINGS = 100;

    private final FiscalDocumentRepository documentRepository;
    private final ReceiptCandidateRepository candidateRepository;
    private final StorageRegistry storageRegistry;

    public ReceiptQueryService(
            FiscalDocumentRepository documentRepository,
            ReceiptCandidateRepository candidateRepository,
            StorageRegistry storageRegistry) {
        this.documentRepository = documentRepository;
        this.candidateRepository = candidateRepository;
        this.storageRegistry = storageRegistry;
    }

    public List<ReceiptAvailabilityResponse> availability(Long userId, Collection<String> bookingIds) {
        if (bookingIds == null || bookingIds.isEmpty() || bookingIds.size() > MAX_BULK_BOOKINGS) {
            throw new IllegalArgumentException("bookingIds must contain between 1 and 100 values");
        }
        List<String> uniqueBookingIds = bookingIds.stream()
                .filter(id -> id != null && !id.isBlank())
                .distinct()
                .toList();
        if (uniqueBookingIds.isEmpty()) {
            throw new IllegalArgumentException("bookingIds must contain at least one non-blank value");
        }
        Map<String, FiscalDocument> documents = documentRepository
                .findByOwnerUserIdAndBookingIdInAndStatus(userId, uniqueBookingIds, DocumentStatus.ISSUED)
                .stream()
                .collect(Collectors.toMap(FiscalDocument::getBookingId, Function.identity()));
        Map<String, ReceiptCandidate> candidates = candidateRepository
                .findByOwnerUserIdAndBookingIdIn(userId, uniqueBookingIds)
                .stream()
                .collect(Collectors.toMap(ReceiptCandidate::getBookingId, Function.identity()));

        return uniqueBookingIds.stream()
                .map(bookingId -> toAvailability(
                        bookingId,
                        documents.get(bookingId),
                        candidates.get(bookingId)))
                .toList();
    }

    public ReceiptFile downloadForUser(String documentId, Long userId) {
        FiscalDocument document = ownedIssuedDocument(documentId, userId);
        return readVerified(document);
    }

    public ReceiptFile downloadForInternalService(String documentId) {
        FiscalDocument document = documentRepository.findByDocumentId(documentId)
                .filter(value -> value.getStatus() == DocumentStatus.ISSUED)
                .orElseThrow(() -> new BillingNotFoundException("Receipt document not found"));
        return readVerified(document);
    }

    public FiscalDocument ownedIssuedDocument(String documentId, Long userId) {
        FiscalDocument document = documentRepository.findByDocumentId(documentId)
                .orElseThrow(() -> new BillingNotFoundException("Receipt document not found"));
        if (document.getOwnerUserId() == null || !document.getOwnerUserId().equals(userId)) {
            throw new BillingAccessDeniedException("Receipt access is not authorized");
        }
        if (document.getStatus() != DocumentStatus.ISSUED) {
            throw new BillingNotFoundException("Receipt document not found");
        }
        return document;
    }

    private ReceiptAvailabilityResponse toAvailability(
            String bookingId,
            FiscalDocument document,
            ReceiptCandidate candidate) {
        if (document != null) {
            return new ReceiptAvailabilityResponse(
                    bookingId,
                    true,
                    document.getDocumentId(),
                    document.getReceiptNumber(),
                    document.getIssuedAt(),
                    "AVAILABLE");
        }
        return new ReceiptAvailabilityResponse(
                bookingId,
                false,
                null,
                null,
                null,
                lifecycleState(candidate));
    }

    private String lifecycleState(ReceiptCandidate candidate) {
        if (candidate == null) {
            return "NOT_AVAILABLE";
        }
        return switch (candidate.getStatus()) {
            case PENDING_COMPLETION -> "PENDING_COMPLETION";
            case PREPARING, ISSUED -> "PREPARING";
            case REVIEW_REQUIRED -> "MANUAL_REVIEW";
            case NOT_ELIGIBLE -> "NOT_AVAILABLE";
        };
    }

    private ReceiptFile readVerified(FiscalDocument document) {
        if (document.getStorage() == null) {
            throw new IllegalStateException("Receipt document storage metadata is unavailable");
        }
        try (InputStream stream = storageRegistry.open(document.getStorage())) {
            byte[] content = stream.readAllBytes();
            if (!checksum(content).equals(document.getStorage().getChecksumSha256())) {
                throw new IllegalStateException("Receipt document checksum verification failed");
            }
            return new ReceiptFile("receipt-" + document.getReceiptNumber() + ".pdf", content);
        } catch (IOException exception) {
            throw new IllegalStateException("Receipt document could not be read", exception);
        }
    }

    private String checksum(byte[] content) {
        try {
            return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(content));
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is unavailable", exception);
        }
    }
}
