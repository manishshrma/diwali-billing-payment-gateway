package com.forvmom.MomentForeverBilling.events;

import lombok.Data;

import java.math.BigDecimal;
import java.time.Instant;

@Data
public class ReceiptEligibilityCapturedEvent {

    private String eventId;
    private String producer;
    private String correlationId;
    private String causationId;
    private Integer schemaVersion;
    private Instant occurredAt;
    private String eventType;
    private String bookingId;
    private Long userId;
    private String userEmail;
    private String userFullName;
    private String experienceName;
    private Instant bookingDate;
    private BigDecimal expectedAmount;
    private String expectedCurrency;
    private String paymentTransactionId;
    private BigDecimal amountPaid;
    private String currencyPaid;
    private Instant paidAt;
}
