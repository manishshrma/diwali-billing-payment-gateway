package com.forvmom.MomentForeverBilling.exception;

public class ReceiptRateLimitExceededException extends RuntimeException {
    public ReceiptRateLimitExceededException() {
        super("Receipt resend limit exceeded; try again later");
    }
}
