package com.forvmom.MomentForeverBilling.controller;

import com.forvmom.MomentForeverBilling.service.ReceiptFile;
import com.forvmom.MomentForeverBilling.service.ReceiptQueryService;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

@RestController
@RequestMapping("/internal/receipts")
public class InternalReceiptController {

    private final ReceiptQueryService receiptQueryService;
    private final byte[] expectedToken;

    public InternalReceiptController(
            ReceiptQueryService receiptQueryService,
            @Value("${billing-internal.token}") String internalToken) {
        this.receiptQueryService = receiptQueryService;
        if (!StringUtils.hasText(internalToken)) {
            throw new IllegalStateException("BILLING_INTERNAL_TOKEN must be configured");
        }
        this.expectedToken = internalToken.getBytes(StandardCharsets.UTF_8);
    }

    @GetMapping("/{documentId}/pdf")
    public ResponseEntity<byte[]> retrieve(
            @PathVariable String documentId,
            @RequestHeader(value = "X-Billing-Internal-Token", required = false) String suppliedToken) {
        if (suppliedToken == null
                || !MessageDigest.isEqual(expectedToken, suppliedToken.getBytes(StandardCharsets.UTF_8))) {
            return ResponseEntity.status(401).build();
        }
        ReceiptFile receipt = receiptQueryService.downloadForInternalService(documentId);
        return ResponseEntity.ok()
                .contentType(MediaType.APPLICATION_PDF)
                .header(HttpHeaders.CONTENT_DISPOSITION, ContentDisposition.attachment()
                        .filename(receipt.filename(), StandardCharsets.UTF_8)
                        .build()
                        .toString())
                .body(receipt.content());
    }
}
