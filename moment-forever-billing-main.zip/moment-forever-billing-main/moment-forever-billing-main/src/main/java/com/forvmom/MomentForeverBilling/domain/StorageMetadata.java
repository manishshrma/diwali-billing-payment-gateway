package com.forvmom.MomentForeverBilling.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class StorageMetadata {
    private String provider;
    private String storageKey;
    private String checksumSha256;
    private long sizeBytes;
    private String contentType;
}
