package com.forvmom.MomentForeverBilling.domain;

public enum DocumentStatus {
    ISSUED
}
