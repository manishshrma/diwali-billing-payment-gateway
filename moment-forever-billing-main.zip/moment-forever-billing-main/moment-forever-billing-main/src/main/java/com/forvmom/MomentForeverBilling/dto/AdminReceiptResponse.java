package com.forvmom.MomentForeverBilling.dto;

import java.time.Instant;

public record AdminReceiptResponse(
        String documentId,
        String bookingId,
        String receiptNumber,
        String financialYear,
        String documentType,
        String status,
        Instant issuedAt) {
}
