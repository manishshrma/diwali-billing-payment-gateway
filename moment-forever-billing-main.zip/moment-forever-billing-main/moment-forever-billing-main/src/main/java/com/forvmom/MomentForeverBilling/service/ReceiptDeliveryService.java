package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.domain.BillingOutbox;
import com.forvmom.MomentForeverBilling.domain.DeliveryAudit;
import com.forvmom.MomentForeverBilling.domain.FiscalDocument;
import com.forvmom.MomentForeverBilling.events.ReceiptDeliveryRequestedEvent;
import com.forvmom.MomentForeverBilling.exception.ReceiptRateLimitExceededException;
import com.forvmom.MomentForeverBilling.repository.DeliveryAuditRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.time.Instant;
import java.util.HexFormat;
import java.util.UUID;
import java.util.regex.Pattern;

@Service
public class ReceiptDeliveryService {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");

    private final ReceiptQueryService receiptQueryService;
    private final ReceiptResendRateLimiter rateLimiter;
    private final DeliveryAuditRepository deliveryAuditRepository;
    private final BillingOutboxService outboxService;

    public ReceiptDeliveryService(
            ReceiptQueryService receiptQueryService,
            ReceiptResendRateLimiter rateLimiter,
            DeliveryAuditRepository deliveryAuditRepository,
            BillingOutboxService outboxService) {
        this.receiptQueryService = receiptQueryService;
        this.rateLimiter = rateLimiter;
        this.deliveryAuditRepository = deliveryAuditRepository;
        this.outboxService = outboxService;
    }

    @Transactional
    public BillingOutbox requestResend(String documentId, Long userId, String alternateEmail) {
        FiscalDocument document = receiptQueryService.ownedIssuedDocument(documentId, userId);
        if (!rateLimiter.tryAcquire(documentId, userId)) {
            throw new ReceiptRateLimitExceededException();
        }

        boolean alternate = StringUtils.hasText(alternateEmail);
        String recipient = alternate ? alternateEmail.trim() : document.getTrustedAccountEmail();
        if (!isValidEmail(recipient)) {
            throw new IllegalArgumentException("A valid receipt recipient is required");
        }

        DeliveryAudit audit = new DeliveryAudit();
        audit.setDocumentId(documentId);
        audit.setRequestorUserId(userId);
        audit.setRecipientHash(hashRecipient(recipient));
        audit.setRecipientSource(alternate ? "ALTERNATE_EMAIL" : "TRUSTED_ACCOUNT_EMAIL");
        audit.setAction("RESEND_REQUESTED");
        audit.setCreatedAt(Instant.now());
        deliveryAuditRepository.insert(audit);

        ReceiptDeliveryRequestedEvent event = new ReceiptDeliveryRequestedEvent();
        event.setEventId(UUID.randomUUID().toString());
        event.setProducer("billing-service");
        event.setCorrelationId(document.getBookingId());
        event.setOccurredAt(Instant.now());
        event.setEventType(BillingOutboxService.RECEIPT_DELIVERY_REQUESTED);
        event.setDocumentId(document.getDocumentId());
        event.setBookingId(document.getBookingId());
        event.setUserId(document.getOwnerUserId());
        event.setRecipientEmail(recipient);
        event.setReceiptNumber(document.getReceiptNumber());
        event.setResend(true);
        return outboxService.enqueueReceiptDelivery(event);
    }

    private boolean isValidEmail(String email) {
        return StringUtils.hasText(email) && email.length() <= 254 && EMAIL_PATTERN.matcher(email).matches();
    }

    private String hashRecipient(String recipient) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(recipient.trim().toLowerCase().getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (NoSuchAlgorithmException exception) {
            throw new IllegalStateException("SHA-256 is unavailable", exception);
        }
    }
}
