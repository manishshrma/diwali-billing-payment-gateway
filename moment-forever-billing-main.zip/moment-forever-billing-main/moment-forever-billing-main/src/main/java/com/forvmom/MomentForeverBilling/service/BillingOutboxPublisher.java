package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.config.BillingProperties;
import com.forvmom.MomentForeverBilling.domain.BillingOutbox;
import com.forvmom.MomentForeverBilling.domain.OutboxStatus;
import com.forvmom.MomentForeverBilling.events.ReceiptDeliveryRequestedEvent;
import com.forvmom.MomentForeverBilling.repository.BillingOutboxRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class BillingOutboxPublisher {

    private static final Logger log = LoggerFactory.getLogger(BillingOutboxPublisher.class);

    private final BillingOutboxRepository outboxRepository;
    private final BillingOutboxService outboxService;
    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final BillingProperties properties;

    @Value("${kafka.topics.receipt-delivery-requested}")
    private String receiptDeliveryTopic;

    @Value("${kafka.topics.receipt-delivery-dlt}")
    private String receiptDeliveryDltTopic;

    public BillingOutboxPublisher(
            BillingOutboxRepository outboxRepository,
            BillingOutboxService outboxService,
            KafkaTemplate<String, Object> billingKafkaTemplate,
            BillingProperties properties) {
        this.outboxRepository = outboxRepository;
        this.outboxService = outboxService;
        this.kafkaTemplate = billingKafkaTemplate;
        this.properties = properties;
    }

    public void tryPublish(BillingOutbox outbox) {
        if (outbox == null || outbox.getStatus() == OutboxStatus.SENT || outbox.getStatus() == OutboxStatus.DEAD) {
            return;
        }
        publish(outbox, false);
    }

    @Scheduled(fixedDelayString = "${billing.outbox-poll-ms:30000}")
    public void publishPendingEvents() {
        List<BillingOutbox> pending = outboxRepository.findByStatusInOrderByUpdatedAtAsc(
                List.of(OutboxStatus.PENDING, OutboxStatus.FAILED));
        for (BillingOutbox outbox : pending) {
            if (outbox.getRetryCount() >= properties.getOutboxMaxRetries()) {
                publishDeadLetter(outbox);
                continue;
            }
            publish(outbox, true);
        }
    }

    private void publish(BillingOutbox outbox, boolean retry) {
        try {
            if (retry) {
                outboxService.incrementRetry(outbox);
            }
            ReceiptDeliveryRequestedEvent event = outboxService.readDeliveryEvent(outbox);
            if (!event.isResend()) {
                rejectAutomaticDelivery(outbox, event);
                return;
            }
            kafkaTemplate.send(receiptDeliveryTopic, event.getBookingId(), event).get(5, TimeUnit.SECONDS);
            outboxService.markSent(outbox);
            log.info("Receipt delivery event published: outboxId={}, documentId={}, bookingId={}",
                    outbox.getId(), event.getDocumentId(), event.getBookingId());
        } catch (Exception exception) {
            outboxService.markFailed(outbox);
            log.warn("Receipt delivery event publication failed: outboxId={}, aggregateId={}, exceptionType={}",
                    outbox.getId(), outbox.getAggregateId(), exception.getClass().getSimpleName());
        }
    }

    private void rejectAutomaticDelivery(BillingOutbox outbox, ReceiptDeliveryRequestedEvent event) {
        try {
            kafkaTemplate.send(receiptDeliveryDltTopic, event.getBookingId(), event).get(5, TimeUnit.SECONDS);
            outboxService.markDead(outbox);
            log.error("Receipt delivery event rejected because it is not an explicit resend: outboxId={}, documentId={}, bookingId={}",
                    outbox.getId(), event.getDocumentId(), event.getBookingId());
        } catch (Exception exception) {
            outboxService.markFailed(outbox);
            log.error("Receipt delivery rejection could not be published to the DLT: outboxId={}, aggregateId={}, exceptionType={}",
                    outbox.getId(), outbox.getAggregateId(), exception.getClass().getSimpleName());
        }
    }

    private void publishDeadLetter(BillingOutbox outbox) {
        try {
            ReceiptDeliveryRequestedEvent event = outboxService.readDeliveryEvent(outbox);
            kafkaTemplate.send(receiptDeliveryDltTopic, event.getBookingId(), event).get(5, TimeUnit.SECONDS);
            outboxService.markDead(outbox);
            log.error("Receipt delivery event moved to DLT: outboxId={}, documentId={}, bookingId={}",
                    outbox.getId(), event.getDocumentId(), event.getBookingId());
        } catch (Exception exception) {
            log.error("Receipt delivery DLT publication failed: outboxId={}, aggregateId={}, exceptionType={}",
                    outbox.getId(), outbox.getAggregateId(), exception.getClass().getSimpleName());
        }
    }
}
