package com.forvmom.MomentForeverBilling.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;

public record ResendReceiptRequest(
        @Email(message = "alternateEmail must be a valid email address")
        @Size(max = 254, message = "alternateEmail must not exceed 254 characters")
        String alternateEmail) {
}
