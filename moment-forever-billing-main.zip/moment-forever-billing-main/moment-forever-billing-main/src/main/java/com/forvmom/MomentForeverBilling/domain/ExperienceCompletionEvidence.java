package com.forvmom.MomentForeverBilling.domain;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.Instant;

@Data
@Document("experience_completion_evidence")
@CompoundIndexes({
        @CompoundIndex(name = "uq_experience_completion_event", def = "{'eventId': 1}", unique = true),
        @CompoundIndex(name = "uq_experience_completion_booking", def = "{'bookingId': 1}", unique = true)
})
public class ExperienceCompletionEvidence {

    @Id
    private String id;

    private String eventId;
    private String producer;
    private String bookingId;
    private Instant completedAt;
    private Instant receivedAt;
}
