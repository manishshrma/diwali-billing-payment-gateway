package com.forvmom.MomentForeverBilling.service;

import com.forvmom.MomentForeverBilling.domain.FiscalDocument;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.math.RoundingMode;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;

@Component
public class ReceiptPdfRenderer {

    private static final DateTimeFormatter TIMESTAMP_FORMAT =
            DateTimeFormatter.ofPattern("dd MMM uuuu HH:mm 'UTC'").withZone(ZoneOffset.UTC);

    public byte[] render(FiscalDocument document) {
        try (PDDocument pdf = new PDDocument();
             ByteArrayOutputStream output = new ByteArrayOutputStream()) {
            PDPage page = new PDPage(PDRectangle.A4);
            pdf.addPage(page);
            try (PDPageContentStream content = new PDPageContentStream(pdf, page)) {
                content.beginText();
                content.setLeading(18f);
                content.newLineAtOffset(54, 790);
                content.setFont(PDType1Font.HELVETICA_BOLD, 16);
                line(content, document.getIssuerName());
                content.setFont(PDType1Font.HELVETICA_BOLD, 12);
                line(content, "PAYMENT RECEIPT - NOT A GST TAX INVOICE");
                content.setFont(PDType1Font.HELVETICA, 10);
                line(content, "");
                line(content, "Receipt number: " + document.getReceiptNumber());
                line(content, "Issued: " + TIMESTAMP_FORMAT.format(document.getIssuedAt()));
                line(content, "Booking reference: " + document.getBookingId());
                line(content, "Experience: " + document.getExperienceName());
                line(content, "Payment transaction: " + document.getPaymentTransactionId());
                line(content, "Amount received: " + document.getCurrency() + " "
                        + document.getPaidAmount().setScale(2, RoundingMode.HALF_UP).toPlainString());
                line(content, "Payment received: " + TIMESTAMP_FORMAT.format(document.getPaymentPaidAt()));
                line(content, "");
                line(content, "This immutable receipt records payment received by Moment Forever in India.");
                line(content, "It is not a GST tax invoice. GST must not be claimed from this document.");
                content.endText();
            }
            pdf.save(output);
            return output.toByteArray();
        } catch (IOException exception) {
            throw new IllegalStateException("Could not render fiscal document PDF", exception);
        }
    }

    private void line(PDPageContentStream content, String text) throws IOException {
        content.showText(asPdfText(text));
        content.newLine();
    }

    private String asPdfText(String value) {
        if (value == null) {
            return "";
        }
        return value.replaceAll("[^\\x20-\\x7E]", "?");
    }
}
