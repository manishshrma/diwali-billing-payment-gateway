package com.forvmom.MomentForeverBilling.config;

import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.serialization.ByteArrayDeserializer;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.config.TopicBuilder;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.support.serializer.ErrorHandlingDeserializer;
import org.springframework.kafka.support.serializer.JsonDeserializer;
import org.springframework.kafka.support.serializer.JsonSerializer;
import org.springframework.util.backoff.FixedBackOff;

import java.util.HashMap;
import java.util.Map;

@Configuration
public class BillingKafkaConfig {

    @Value("${spring.kafka.bootstrap-servers}")
    private String bootstrapServers;

    @Value("${kafka.topics.receipt-generation-requested}")
    private String receiptGenerationRequestedTopic;

    @Value("${kafka.topics.receipt-eligibility-captured}")
    private String receiptEligibilityCapturedTopic;

    @Value("${kafka.topics.experience-completed}")
    private String experienceCompletedTopic;

    @Value("${kafka.topics.receipt-delivery-requested}")
    private String receiptDeliveryRequestedTopic;

    @Value("${kafka.topics.receipt-generation-requested-dlt}")
    private String receiptGenerationRequestedDltTopic;

    @Value("${kafka.topics.receipt-eligibility-captured-dlt}")
    private String receiptEligibilityCapturedDltTopic;

    @Value("${kafka.topics.experience-completed-dlt}")
    private String experienceCompletedDltTopic;

    @Value("${kafka.topics.receipt-delivery-dlt}")
    private String receiptDeliveryDltTopic;

    @Bean
    public ProducerFactory<String, Object> billingProducerFactory() {
        Map<String, Object> config = new HashMap<>();
        config.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        config.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class);
        config.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, JsonSerializer.class);
        config.put(ProducerConfig.ACKS_CONFIG, "all");
        config.put(ProducerConfig.RETRIES_CONFIG, 3);
        config.put(JsonSerializer.TYPE_MAPPINGS,
                "com.forvmom.billing.events.ReceiptDeliveryRequestedEvent:"
                        + "com.forvmom.MomentForeverBilling.events.ReceiptDeliveryRequestedEvent");
        return new DefaultKafkaProducerFactory<>(config);
    }

    @Bean
    public KafkaTemplate<String, Object> billingKafkaTemplate() {
        return new KafkaTemplate<>(billingProducerFactory());
    }

    @Bean
    public ConsumerFactory<String, Object> billingConsumerFactory() {
        Map<String, Object> config = new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ErrorHandlingDeserializer.class);
        config.put(ErrorHandlingDeserializer.KEY_DESERIALIZER_CLASS, StringDeserializer.class);
        config.put(ErrorHandlingDeserializer.VALUE_DESERIALIZER_CLASS, JsonDeserializer.class);
        config.put(JsonDeserializer.TRUSTED_PACKAGES, "com.forvmom");
        config.put(JsonDeserializer.TYPE_MAPPINGS,
                "com.forvmom.booking.events.ReceiptGenerationRequestedEvent:"
                        + "com.forvmom.MomentForeverBilling.events.ReceiptGenerationRequestedEvent,"
                        + "com.forvmom.booking.events.ReceiptEligibilityCapturedEvent:"
                        + "com.forvmom.MomentForeverBilling.events.ReceiptEligibilityCapturedEvent,"
                        + "com.forvmom.booking.events.ExperienceCompletedEvent:"
                        + "com.forvmom.MomentForeverBilling.events.ExperienceCompletedEvent");
        config.put(JsonDeserializer.USE_TYPE_INFO_HEADERS, true);
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, Object> billingKafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, Object> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(billingConsumerFactory());
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        DeadLetterPublishingRecoverer recoverer = new DeadLetterPublishingRecoverer(billingKafkaTemplate());
        factory.setCommonErrorHandler(new DefaultErrorHandler(recoverer, new FixedBackOff(1000L, 3)));
        return factory;
    }

    @Bean
    public ConsumerFactory<String, byte[]> billingDltConsumerFactory() {
        Map<String, Object> config = new HashMap<>();
        config.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, bootstrapServers);
        config.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class);
        config.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, ByteArrayDeserializer.class);
        config.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        config.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        return new DefaultKafkaConsumerFactory<>(config);
    }

    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, byte[]> billingDltKafkaListenerContainerFactory() {
        ConcurrentKafkaListenerContainerFactory<String, byte[]> factory =
                new ConcurrentKafkaListenerContainerFactory<>();
        factory.setConsumerFactory(billingDltConsumerFactory());
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        factory.setCommonErrorHandler(new DefaultErrorHandler(new FixedBackOff(0L, 0L)));
        return factory;
    }

    @Bean
    public NewTopic receiptGenerationRequestedTopic() {
        return TopicBuilder.name(receiptGenerationRequestedTopic).partitions(1).replicas(1).build();
    }

    @Bean
    public NewTopic receiptEligibilityCapturedTopic() {
        return TopicBuilder.name(receiptEligibilityCapturedTopic).partitions(1).replicas(1).build();
    }

    @Bean
    public NewTopic experienceCompletedTopic() {
        return TopicBuilder.name(experienceCompletedTopic).partitions(1).replicas(1).build();
    }

    @Bean
    public NewTopic receiptDeliveryRequestedTopic() {
        return TopicBuilder.name(receiptDeliveryRequestedTopic).partitions(1).replicas(1).build();
    }

    @Bean
    public NewTopic receiptDeliveryDltTopic() {
        return TopicBuilder.name(receiptDeliveryDltTopic).partitions(1).replicas(1).build();
    }

    @Bean
    public NewTopic receiptGenerationRequestedDltTopic() {
        return TopicBuilder.name(receiptGenerationRequestedDltTopic).partitions(1).replicas(1).build();
    }

    @Bean
    public NewTopic receiptEligibilityCapturedDltTopic() {
        return TopicBuilder.name(receiptEligibilityCapturedDltTopic).partitions(1).replicas(1).build();
    }

    @Bean
    public NewTopic experienceCompletedDltTopic() {
        return TopicBuilder.name(experienceCompletedDltTopic).partitions(1).replicas(1).build();
    }
}
