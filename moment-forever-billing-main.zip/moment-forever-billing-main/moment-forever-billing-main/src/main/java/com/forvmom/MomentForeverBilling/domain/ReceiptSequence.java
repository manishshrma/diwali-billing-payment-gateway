package com.forvmom.MomentForeverBilling.domain;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.annotation.Version;
import org.springframework.data.mongodb.core.mapping.Document;

@Data
@Document("receipt_sequences")
public class ReceiptSequence {

    @Id
    private String financialYear;

    @Version
    private Long version;

    private String prefix;

    private long nextValue;
}
