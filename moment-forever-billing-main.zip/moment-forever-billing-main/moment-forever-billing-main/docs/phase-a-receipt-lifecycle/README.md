# Phase A Receipt Lifecycle

## Start here

This folder explains the receipt process in simple terms.

**Phase A** means:

1. a customer pays for a booking;
2. Booking saves the payment details needed for a future receipt;
3. an authorized operations user confirms that the experience really happened;
4. Billing creates one permanent non-GST payment receipt;
5. the customer can download it or explicitly ask for it by email.

The older project documents sometimes call this work **Phase 1**. In this
folder, Phase A and Phase 1 mean the same implemented feature.

### What Phase A does not do

- It does **not** create a receipt when the payment succeeds.
- It does **not** create a receipt before the experience is complete.
- It does **not** send an email just because a receipt was created.
- It does **not** let a customer mark an experience as complete.
- It does **not** let a download request create a new receipt.
- It does **not** change an issued receipt for a cancellation or refund.

This keeps payment confirmation fast and safe. A PDF, storage, email, or
Kafka problem cannot undo a confirmed booking.

## Simple words used in this guide

| Word | Plain-English meaning |
|---|---|
| **Candidate** | Billing's saved copy of the payment and booking details that may later become a receipt. |
| **Outbox** | A database record that stores an event before the application sends it to Kafka. It prevents lost messages when a service restarts or Kafka is unavailable. |
| **Kafka event** | A message sent from one service to another. Booking and Billing do not call each other's databases. |
| **DLT** | Dead-letter topic. It holds a Kafka message that kept failing after retries so an operator can investigate it. |
| **Idempotent** | Safe to do more than once. A duplicate message must not create a second receipt. |
| **Compare-and-set update** | A database update that changes a row only when it is currently in the expected state. |
| **Finance review** | A durable record for a person to investigate when payment evidence is missing or does not match. |

## 1. Why this process exists

A payment proves that the customer paid. It does not prove that the experience
was delivered. Phase A keeps those two facts separate.

Booking confirms the payment and saves a reliable receipt candidate. Later,
only a trusted operations action can mark the booking as complete. Billing
creates the receipt only after it has both:

- good payment evidence; and
- completion evidence for the same booking.

Billing uses its own saved copy of the information. It never reads Booking or
Payment databases while creating a receipt.

## 2. The quick story

```mermaid
flowchart LR
    A[Payment succeeds] --> B[Booking confirms booking]
    B --> C[Booking saves receipt evidence event]
    C --> D[Billing saves receipt candidate]
    D --> E[Operations marks experience complete]
    E --> F[Billing creates one receipt]
    F --> G[Customer downloads PDF]
    F --> H[Customer asks to resend email]
```

The PDF is created only at **Billing creates one receipt**. The email is sent
only after **Customer asks to resend email**.

## 3. What happens at each step

| Step | What starts it | What is saved | What can go wrong safely |
|---:|---|---|---|
| 1. Confirm payment | Booking receives a trusted `PaymentProcessedEvent`. | Booking becomes `CONFIRMED`. Booking also saves two separate outbox records: `BOOKING_CONFIRMED` and `RECEIPT_ELIGIBILITY_CAPTURED`. | If Kafka is down later, the Booking outbox keeps the records for retry. The booking stays confirmed. |
| 2. Save payment evidence | Billing receives `ReceiptEligibilityCapturedEvent`. | Billing saves a `ReceiptCandidate`. Bad evidence also creates a `FinanceReviewCase`. | Bad amount/currency data becomes manual review. It does not cause endless Kafka retries. |
| 3. Mark experience complete | An `ADMIN` or `SUPER_ADMIN` calls the Booking completion endpoint. | Booking becomes `COMPLETED`, stores `completedAt`, and saves an `EXPERIENCE_COMPLETED` outbox record. | A customer cannot call this endpoint. Repeating a successful request does not create another event. |
| 4. Create receipt | Billing receives `ExperienceCompletedEvent`, or receives valid payment evidence after stored completion evidence. | Billing saves one `FiscalDocument`, private PDF storage metadata, and a receipt number. | Duplicate events still lead to one document because Billing uses unique database indexes. |
| 5. Show availability | Customer calls Billing's availability endpoint. | Nothing changes. | Billing returns a safe state such as waiting, manual review, or available. |
| 6. Download | Customer asks for an issued document. | Nothing changes. | Billing checks ownership, issued status, and file checksum before returning the PDF. |
| 7. Resend email | Customer explicitly requests a resend. | Billing saves an audit record and a delivery outbox record. | Delivery retry/DLT behavior handles temporary failures. Bad recipients/configuration are skipped clearly, not retried forever. |

## Read the rest in this order

| Document | Best for |
|---|---|
| [lifecycle-and-trust.md](lifecycle-and-trust.md) | Understanding states, who may complete a booking, payment evidence, and receipt creation. |
| [delivery-and-reliability.md](delivery-and-reliability.md) | Understanding downloads, resends, Kafka/outbox retries, DLTs, and failure cases. |
| [sequence-and-implementation.md](sequence-and-implementation.md) | Finding the code, reading diagrams, checking rules that must never change, and understanding implementation impact. |

## Important code names

New developers can use these names to find the main code paths:

| Purpose | Main code |
|---|---|
| Payment confirmation | `PaymentProcessedProcessor` in Booking |
| Trusted completion | `BookingAdminController` and `BookingServiceImpl` in Booking |
| Payment evidence capture | `ReceiptEligibilityCapturedConsumer` and `ReceiptCandidateService` in Billing |
| Completion handling | `ExperienceCompletedConsumer` in Billing |
| Receipt creation | `ReceiptIssuanceService` in Billing |
| Availability and download | `ReceiptController` and `ReceiptQueryService` in Billing |
| Explicit resend | `ReceiptDeliveryService` and `BillingOutboxPublisher` in Billing |
| Email attachment delivery | `ReceiptDeliveryConsumer` in Booking |
