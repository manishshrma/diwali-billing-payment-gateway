# Phase A: Download, Resend, and Reliable Delivery

This document explains what happens after Billing has already issued a
receipt. It also explains how retries and dead-letter topics work.

## 8. Downloading a receipt

Downloading is a read-only action. It does not create a receipt, send an
email, or create a Kafka event.

### Customer endpoint

```text
GET /billing/api/receipts/{documentId}/download
```

The request goes through:

```text
ReceiptController
  -> ReceiptQueryService.downloadForUser
  -> private storage
  -> PDF response
```

### What Billing checks

Billing receives the trusted `X-User-Id` header from the gateway. It then:

1. finds the document by `documentId`;
2. checks that the document belongs to that user;
3. checks that the document is `ISSUED`;
4. reads the PDF from private storage;
5. checks the file's SHA-256 checksum against saved metadata;
6. returns the PDF only when all checks pass.

Billing returns the same unavailable/not-found result when:

- the document does not exist;
- the caller does not own it;
- it is not issued yet.

This does not reveal whether another customer has a receipt.

### Availability endpoint

Before showing a download button, a customer application can call:

```text
GET /billing/api/receipts/availability?bookingIds=...
```

Billing returns a safe state without returning payment details:

| Availability state | Meaning for the customer |
|---|---|
| `AVAILABLE` | The receipt exists and can be downloaded. |
| `PENDING_COMPLETION` | Payment evidence is saved, but the experience is not complete yet. |
| `PREPARING` | Billing is creating the receipt. |
| `MANUAL_REVIEW` | A finance team member needs to check the evidence. |
| `NOT_AVAILABLE` | Billing has no usable receipt for this booking. |

### Important rule

The current code does **not** generate a receipt during download.
`ReceiptQueryService.downloadForUser` only finds an already-issued document.
It never calls `ReceiptIssuanceService`.

## 9. Asking Billing to send the receipt by email

Email is an explicit resend request. It is not part of payment confirmation,
completion, receipt creation, availability, or download.

### Customer endpoint

```text
POST /billing/api/receipts/{documentId}/resend
```

The customer may omit `alternateEmail`. In that case Billing uses the trusted
account email. If an alternate email is supplied, Billing validates it before
using it.

### What the resend service does

`ReceiptDeliveryService.requestResend`:

1. checks that the caller owns an issued document;
2. applies the resend limit for this document and this requesting user;
3. chooses the account email or valid alternate email;
4. saves a `DeliveryAudit` record with a hash of the recipient, not the raw
   recipient;
5. saves `ReceiptDeliveryRequestedEvent` in Billing's outbox;
6. returns `202 Accepted` with `QUEUED`.

The default limit is three resend requests per document and requesting user
per hour. This is controlled by `ReceiptResendRateLimiter`.

### How the email gets sent

```text
Billing outbox
  -> Kafka ReceiptDeliveryRequestedEvent
  -> Booking ReceiptDeliveryConsumer
  -> Billing internal PDF endpoint
  -> Booking EmailNotificationService
```

Booking owns the email send. It gets the PDF from Billing's internal endpoint:

```text
GET /billing/internal/receipts/{documentId}/pdf
```

`InternalReceiptController` checks `X-Billing-Internal-Token` using a
constant-time comparison. It returns only an issued, checksum-verified
document.

### Email outcomes

| Result | What Booking does | Why |
|---|---|---|
| Email sent | Acknowledges the Kafka message. | Delivery finished. |
| Email feature disabled | Logs an explicit skip and acknowledges. | Retrying cannot enable a disabled feature. |
| Recipient invalid | Logs an explicit skip and acknowledges. | Retrying invalid email data is not useful. |
| Email configuration missing | Logs an explicit skip and acknowledges. | A human must fix configuration. |
| Billing network/5xx failure | Throws a transient error. | Kafka retries the message. |
| SMTP/provider failure | Throws a transient error. | Kafka retries the message. |

No log should contain the recipient address, email body, PDF content, or a
secret token.

## 10. How outbox, retry, and DLT handling works

### Booking payment and completion messages

Booking uses two kinds of outbox record:

| Record | Why it exists |
|---|---|
| **Inbound outbox** | Remembers a Kafka message that Booking received, so it can recover if business processing fails after Kafka acknowledgment. |
| **Outgoing outbox** | Remembers a message that Booking must publish after its database transaction commits. |

For a successful payment:

1. Booking saves the `CONFIRMED` booking change.
2. Booking saves `BOOKING_CONFIRMED`.
3. Booking saves `RECEIPT_ELIGIBILITY_CAPTURED`.
4. Booking marks the payment message processed.
5. Booking commits all four changes together.
6. `OutgoingOutboxPublisher` tries each outgoing message after the commit.

For a trusted completion, Booking saves:

1. the `COMPLETED` booking change;
2. the completion time;
3. `EXPERIENCE_COMPLETED` in the outgoing outbox.

It commits those changes together and publishes after the commit.

### Recovering a missed payment output

`InboundOutboxRetryService` knows that a `PAYMENT_PROCESSED` message should
have created two outgoing records:

- `BOOKING_CONFIRMED`;
- `RECEIPT_ELIGIBILITY_CAPTURED`.

If retry finds a booking already confirmed but one output is missing,
`PaymentProcessedProcessor.reconcile` creates only the missing record. It does
not run confirmation again or combine both events into a list.

### Booking retry limit

Booking retries pending/failed outbox work up to five times.

| Exhausted record | Handler | Result |
|---|---|---|
| Incoming payment record | `OutboxDeadLetterHandler` | Marks it dead and sends an operations alert that refund/manual action may be needed. |
| Outgoing Booking confirmation/cancellation record | `OutgoingOutboxDeadLetterHandler` | Marks it dead, alerts operations, and runs the existing event-specific compensation where one exists. |
| Outgoing eligibility or completion record | `OutgoingOutboxDeadLetterHandler` | Marks it dead and alerts operations. There is no automatic receipt-specific compensation. Operators must investigate/replay using the existing outbox process. |

These Booking database-outbox dead records are different from Kafka dead-letter
topics.

### Billing Kafka retry and DLT

Billing consumes these topics:

| Topic | Consumer | Normal work |
|---|---|---|
| `topic_receipt_eligibility_captured` | `ReceiptEligibilityCapturedConsumer` | Save candidate or finance review. |
| `topic_experience_completed` | `ExperienceCompletedConsumer` | Save completion evidence and possibly issue. |
| `topic_receipt_generation_requested` | `LegacyReceiptGenerationConsumer` | Compatibility capture only. It must not auto-issue. |

Billing uses a Kafka `DefaultErrorHandler` with a one-second pause and three
retries. If an unexpected technical error still fails, Kafka puts the message
on that topic's DLT.

`ReceiptCandidateDltConsumer` reads the three receipt lifecycle DLTs with a
raw-byte consumer, not the normal JSON event consumer. It logs the topic,
partition, and offset, then acknowledges the DLT record. Even broken JSON or
an unknown event type can therefore be observed without creating another DLT
message. It does not quietly re-run an unsafe receipt operation.

Bad payment evidence is not a technical failure. Billing creates a finance
review record and acknowledges it normally.

### Billing resend outbox

The Billing delivery outbox is used only after an explicit resend request:

1. `BillingOutboxService` writes a `PENDING` delivery record.
2. `BillingOutboxPublisher` rejects an older delivery record with
   `resend=false`, sends it to `topic_receipt_delivery_requested.DLT`, and
   marks the outbox record `DEAD`. It never sends that record to Booking's
   email consumer.
3. `BillingOutboxPublisher` tries a true resend event immediately.
4. If that fails, the row becomes `FAILED`.
5. A scheduled publisher checks pending/failed records every
   `billing.outbox-poll-ms` (30 seconds by default).
6. Billing retries up to `billing.outbox-max-retries` (5 by default).
7. After the limit, Billing sends the delivery event to
   `topic_receipt_delivery_requested.DLT` and marks the outbox record `DEAD`.

Booking also checks `resend=true` before it reads a PDF or sends email. This
second check safely rejects an old event that reached Kafka before Billing's
publisher rule was deployed.

### Booking email retry and DLT

For temporary PDF retrieval or SMTP failures, `ReceiptDeliveryConsumer` lets
the error reach Booking's Kafka error handler. Booking retries with a
one-second pause and three retries. If all retries fail, Kafka sends the
message to the receipt-delivery DLT.

`BookingNotificationDltConsumer` observes that DLT, logs/alerts the topic,
partition, and offset, and acknowledges it. This protects the rest of the
notification system without rolling back booking completion or receipt
creation.

## 11. Common failure cases

| Problem | What happens | What should a developer or operator know |
|---|---|---|
| Payment succeeds, but the experience never completes | Candidate stays `PENDING_COMPLETION`. | No receipt and no email are created. |
| Completion is requested before payment confirmation | Booking rejects it because the booking is not `CONFIRMED`. | No completion event is written. |
| Completion is requested twice | First request wins; second is safe. | There is only one completion event. |
| Payment amount/currency is wrong or missing | Candidate is `REVIEW_REQUIRED`; finance review opens. | Do not retry the message to “fix” business data. |
| Completion arrives before payment evidence | Billing stores completion evidence. | Later good evidence can issue the receipt. |
| Receipt creation fails | Kafka retries the Billing consumer. | If retries finish, investigate the Billing DLT. |
| Two receipt workers race | Unique booking ID on `FiscalDocument` picks one winner. | Losing worker removes its extra file and uses the existing receipt. |
| Customer downloads repeatedly | Each request checks owner/status/checksum. | No new receipt or email is created. |
| Customer resends repeatedly | Rate limit is checked each time. | Existing receipt is reused; a new fiscal document is never created. |
| Same Kafka event arrives twice | Unique indexes find existing candidate/completion data. | The flow remains safe to repeat. |
| Old delivery event has `resend=false` | Billing moves the outbox record to delivery DLT; Booking rejects a direct old Kafka message. | It is visible as `DEAD`/DLT and is never reported as sent. |
| Billing/SMTP is temporarily down | Booking email consumer retries, then DLTs if exhausted. | The booking and receipt stay valid. |
| Email address/configuration is bad | Booking skips it clearly without retry. | Fix configuration or make a new valid resend request. |
| Service restarts | Committed outbox/candidate/completion records remain. | Scheduled retry and Kafka redelivery continue from saved data. |
