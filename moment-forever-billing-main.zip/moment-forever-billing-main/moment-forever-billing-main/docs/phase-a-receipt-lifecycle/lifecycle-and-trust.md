# Phase A: States, Trust, Evidence, and Receipt Creation

This document explains the part of the process that decides **whether** Billing
may create a receipt.

## 4. State model

There is no single `ReceiptState` field. The state is stored across Booking
and Billing records.

```mermaid
stateDiagram-v2
    [*] --> PENDING
    PENDING --> CONFIRMED: payment success
    CONFIRMED --> CandidateSaved: payment evidence saved
    CONFIRMED --> COMPLETED: trusted operations action
    CandidateSaved --> WaitingForCompletion
    COMPLETED --> Eligible: valid candidate exists
    WaitingForCompletion --> Eligible: completion evidence arrives
    Eligible --> ISSUED: receipt created
    CandidateSaved --> MANUAL_REVIEW: payment data is bad
    CandidateSaved --> NOT_ELIGIBLE: payment before feature launch
```

### Where each state is stored

| Business idea | Where the code stores it | What it means |
|---|---|---|
| Payment is confirmed | `BookingStatus.CONFIRMED` and `Booking.confirmedAt` | Payment was accepted and Booking has confirmed the booking. |
| Payment evidence is saved | `ReceiptCandidate` | Billing has its own saved copy of the payment and booking details. |
| Waiting for completion | `ReceiptCandidateStatus.PENDING_COMPLETION` | The evidence is good, but Billing has not seen trusted completion yet. |
| Booking is complete | `BookingStatus.COMPLETED` and `Booking.completedAt` | A trusted Booking operation says the experience happened. |
| Completion reached Billing | `ExperienceCompletionEvidence` | Billing has saved the completion event, even if the candidate has not arrived yet. |
| Ready to issue | No separate stored value | Billing has both a `PENDING_COMPLETION` candidate and completion evidence for the same booking. |
| Receipt is issued | `FiscalDocument.status == ISSUED` and candidate status `ISSUED` | The one permanent receipt exists. |
| Manual review needed | Candidate status `REVIEW_REQUIRED` plus `FinanceReviewCase` | Evidence is missing or does not match. |
| Not eligible | Candidate status `NOT_ELIGIBLE` | Payment happened before the configured feature launch date. |

## 5. Who can mark a booking complete

### The rule

Only an operations user can mark a booking complete. A customer cannot do it.

| Item | Value |
|---|---|
| Endpoint | `PUT /booking/admin/bookings/{bookingId}/complete` |
| Controller | `BookingAdminController` |
| Allowed roles | `ADMIN`, `SUPER_ADMIN` |
| Trusted header | `X-User-Roles` |
| Customer route | None |

The API gateway must remove any role header sent by a browser and add the
trusted role header after validating the user's JWT. Booking still checks the
role itself. A hidden button or hidden Swagger endpoint is not enough
security.

### What happens in the Booking database

`BookingServiceImpl.completeBooking` asks
`BookingStatusTransitionService` to make this one-way change:

```text
CONFIRMED -> COMPLETED
```

The database update succeeds only if the booking is currently `CONFIRMED`.
This is called a compare-and-set update.

If the update succeeds, the same database transaction also:

1. sets `completedAt`;
2. builds an `ExperienceCompletedEvent`;
3. saves an `EXPERIENCE_COMPLETED` Booking outbox record.

The event is sent to Kafka only after that transaction commits. This matters:
if Kafka is unavailable, the completion is still safely stored and the outbox
retry job can send the event later.

### Repeated or invalid completion requests

| Request | Result |
|---|---|
| Complete a `CONFIRMED` booking | Changes to `COMPLETED` and creates one event. |
| Complete the same booking again | Returns the idempotent result and creates no second event. |
| Complete `PENDING`, `CANCELLED`, or another invalid state | Returns a conflict. |
| Customer calls the endpoint | Returns access denied. |

## 6. How payment evidence is captured

### Payment-time work in Booking

When Booking handles a successful `PaymentProcessedEvent`, it performs one
database transaction:

1. change the booking from `PENDING` to `CONFIRMED`;
2. save a `BOOKING_CONFIRMED` outbox record;
3. save a separate `RECEIPT_ELIGIBILITY_CAPTURED` outbox record;
4. mark the inbound payment event processed.

The two outbox records are separate because they have separate jobs:

- `BOOKING_CONFIRMED` continues to feed existing booking confirmation
  notifications;
- `RECEIPT_ELIGIBILITY_CAPTURED` gives Billing the data it needs later.

`OutboundProcessingResult` carries the two saved outbox records from the
transaction to the publisher. It does **not** put a list inside one Kafka
message. Each record becomes one normal Kafka event.

### What the evidence event contains

`OutboundEventGenerator.buildReceiptEligibilityCapturedEvent` creates
`ReceiptEligibilityCapturedEvent` from the successful payment event.

| Type of information | Values in the event |
|---|---|
| Event identity | Event ID, producer, schema version, event time, correlation ID, causation ID, event type |
| Booking and customer snapshot | Booking ID, customer ID, customer email/name, experience name, booking date |
| Expected payment | Expected amount and currency |
| Actual payment | Payment transaction ID, paid amount, paid currency, paid time |

Billing saves this information in `ReceiptCandidate`. It does not ask Booking
or Payment to look it up again later.

### What Billing checks

`ReceiptCandidateService.capture` checks that:

1. the event has an ID;
2. the booking ID, customer ID, payment transaction ID, expected amount,
   expected currency, paid amount, paid currency, and paid time are present;
3. expected and paid amounts are equal;
4. expected and paid currencies match Billing's configured currency;
5. payment happened on or after `billing.receipt-feature-launch-at`.

### What Billing saves for each result

| Evidence result | Candidate status | Extra record | Can Billing issue a receipt? |
|---|---|---|---|
| Good evidence | `PENDING_COMPLETION` | None | Yes, but only after completion. |
| Payment is before feature launch | `NOT_ELIGIBLE` | None | No. |
| Required evidence is missing | `REVIEW_REQUIRED` | `FinanceReviewCase` with `PAYMENT_EVIDENCE_INCOMPLETE` | No. |
| Paid and expected amounts differ | `REVIEW_REQUIRED` | `FinanceReviewCase` with `AMOUNT_MISMATCH` | No. |
| Paid and expected currencies differ | `REVIEW_REQUIRED` | `FinanceReviewCase` with `CURRENCY_MISMATCH` | No. |

Bad payment data is a business problem, not a transport problem. Billing saves
it for finance review and acknowledges the Kafka event. Retrying the same bad
event would not make its amount or currency correct.

### Duplicate and out-of-order events

Billing uses durable unique indexes:

- `ReceiptCandidate.sourceEventId` is unique;
- the candidate booking ID is unique when it exists;
- `ExperienceCompletionEvidence.eventId` is unique;
- the completion booking ID is unique.

This gives these safe outcomes:

| Situation | What Billing does |
|---|---|
| Kafka sends the same payment evidence twice | Uses the existing candidate; does not create another one. |
| Kafka sends the same completion event twice | Uses the existing completion evidence; does not create another one. |
| Completion arrives before payment evidence | Saves completion evidence and waits for a candidate. |
| Payment evidence arrives after completion | Finds stored completion evidence and may issue if the candidate is valid. |

When a duplicate event arrives, Billing does not stop at "already seen." It
looks again for the matching saved candidate and completion evidence. This can
finish a receipt that was waiting during an earlier race.

Billing also runs `reconcileReadyCandidates` every
`billing.receipt-candidate-reconciliation-poll-ms` (30 seconds by default).
It checks all `PENDING_COMPLETION` candidates that have completion evidence
and tries normal issuance. This is a safety net for the case where the payment
and completion Kafka listeners both saved their own record before either could
see the other one. The normal one-receipt database rule still applies.

## 7. How Billing creates the receipt

### The only allowed time to issue

`ReceiptCandidateService` calls `ReceiptIssuanceService.issueIfReady` only
when Billing has:

- a candidate in `PENDING_COMPLETION`; and
- completion evidence for the same booking.

`ReceiptIssuanceService` immediately skips candidates in any other state.
That prevents a receipt for:

- a payment-only booking;
- a candidate waiting for completion;
- a manual-review case;
- a pre-launch payment;
- a candidate already issued.

### What the issuance service does

For an allowed candidate, `ReceiptIssuanceService`:

1. checks whether a fiscal document already exists for the booking;
2. reserves the next receipt number for the configured financial year;
3. renders a non-GST payment-receipt PDF;
4. saves the PDF in private storage;
5. saves the document's checksum, size, content type, and private storage
   metadata;
6. creates a `FiscalDocument` of type `PAYMENT_RECEIPT_NON_GST`;
7. marks the candidate `ISSUED`.

The document is immutable. The public API uses the document ID. It never
returns the private GridFS or S3 storage key.

### How Billing avoids two receipts

| Risk | Protection |
|---|---|
| Same candidate event is delivered again | Candidate source-event unique index. |
| Same completion event is delivered again | Completion event unique index. |
| Two workers try to issue at the same time | `FiscalDocument` has a unique booking ID. |
| A second worker stored a PDF before it loses the document insert race | Billing deletes that extra private file, reads the winning document, and marks the candidate issued from it. |
| A completed receipt is requested again | Existing-document lookup returns the existing receipt. |

### No automatic email

`ReceiptIssuanceService` does not depend on `BillingOutboxService`. In plain
English, that means creating the receipt does not queue an email. Email is an
explicit later customer action, explained in
[delivery-and-reliability.md](delivery-and-reliability.md).
