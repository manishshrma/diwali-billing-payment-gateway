# Phase A: Diagrams, Code Map, and Change Guide

This document helps a new developer connect the business flow to the code.
The class names are exact. The explanation around them is intentionally
plain.

## 12. Sequence diagrams

### Flow A: Payment confirmation and payment evidence

```mermaid
sequenceDiagram
    participant Payment as Payment service
    participant Kafka
    participant Consumer as PaymentProcessedConsumer
    participant Process as PaymentProcessedProcessor
    participant BookingDB as Booking database
    participant Outbox as Booking outgoing outbox
    participant Billing as ReceiptEligibilityCapturedConsumer
    participant BillingDB as Billing MongoDB

    Payment->>Kafka: PaymentProcessedEvent
    Kafka->>Consumer: payment message
    Consumer->>Process: process payment
    Process->>BookingDB: change PENDING to CONFIRMED
    Process->>Outbox: save BOOKING_CONFIRMED
    Process->>Outbox: save RECEIPT_ELIGIBILITY_CAPTURED
    Note over BookingDB,Outbox: One database transaction
    Outbox->>Kafka: ReceiptEligibilityCapturedEvent
    Kafka->>Billing: evidence event
    Billing->>BillingDB: save candidate or finance review
```

### Flow B: Trusted completion

```mermaid
sequenceDiagram
    participant Ops as ADMIN or SUPER_ADMIN
    participant Gateway
    participant Controller as BookingAdminController
    participant Service as BookingServiceImpl
    participant BookingDB as Booking database/outbox
    participant Kafka

    Ops->>Gateway: complete booking request
    Gateway->>Controller: trusted X-User-Roles
    Controller->>Controller: check operations role
    Controller->>Service: completeBooking
    Service->>BookingDB: change CONFIRMED to COMPLETED
    Service->>BookingDB: save EXPERIENCE_COMPLETED outbox row
    Note over Service,BookingDB: One database transaction
    BookingDB->>Kafka: ExperienceCompletedEvent
```

### Flow C: Receipt creation

```mermaid
sequenceDiagram
    participant Kafka
    participant Consumer as ExperienceCompletedConsumer
    participant Candidate as ReceiptCandidateService
    participant BillingDB as Billing MongoDB
    participant Issue as ReceiptIssuanceService
    participant Storage as Private document storage

    Kafka->>Consumer: ExperienceCompletedEvent
    Consumer->>Candidate: save completion evidence
    Candidate->>BillingDB: find candidate by booking ID
    alt valid candidate is waiting for completion
        Candidate->>Issue: issueIfReady
        Issue->>BillingDB: reserve receipt number
        Issue->>Storage: save private PDF
        Issue->>BillingDB: save FiscalDocument and mark candidate ISSUED
    else candidate has not arrived yet
        Candidate->>BillingDB: keep completion evidence
    else candidate is invalid or not eligible
        Candidate->>BillingDB: do not issue
    end
```

### Flow D: Manual download

```mermaid
sequenceDiagram
    participant User
    participant Gateway
    participant API as ReceiptController
    participant Query as ReceiptQueryService
    participant BillingDB as Billing MongoDB
    participant Storage as Private document storage

    User->>Gateway: download document
    Gateway->>API: trusted X-User-Id
    API->>Query: downloadForUser
    Query->>BillingDB: check owner and ISSUED status
    Query->>Storage: read PDF
    Query->>Query: verify checksum
    Query-->>User: PDF
    Note over API,User: No email, Kafka event, or receipt creation
```

### Flow E: Explicit email resend

```mermaid
sequenceDiagram
    participant User
    participant API as ReceiptController
    participant Delivery as ReceiptDeliveryService
    participant BillingDB as Billing MongoDB
    participant Publisher as BillingOutboxPublisher
    participant Kafka
    participant Booking as ReceiptDeliveryConsumer
    participant BillingPDF as InternalReceiptController
    participant Email as EmailNotificationService

    User->>API: resend request
    API->>Delivery: requestResend
    Delivery->>BillingDB: check owner, rate limit, and email
    Delivery->>BillingDB: save audit and delivery outbox row
    Publisher->>Kafka: ReceiptDeliveryRequestedEvent
    Kafka->>Booking: delivery request
    Booking->>BillingPDF: get immutable PDF with internal token
    BillingPDF-->>Booking: PDF
    Booking->>Email: send attachment
```

### Flow F: Retry and DLT

```mermaid
sequenceDiagram
    participant Tx as Service transaction
    participant Outbox as Durable outbox
    participant Publisher
    participant Kafka
    participant Consumer
    participant DLT as Dead-letter topic
    participant Ops as Alert or DLT consumer

    Tx->>Outbox: save business change and event together
    Publisher->>Kafka: publish after commit
    alt publish fails
        Publisher->>Outbox: mark failed
        loop scheduled outbox retry
            Publisher->>Kafka: retry publish
        end
        Publisher->>Outbox: mark dead after limit
        Publisher->>Ops: operations alert
    end
    Kafka->>Consumer: deliver event
    alt temporary consumer failure
        loop Kafka retries
            Kafka->>Consumer: retry
        end
        Kafka->>DLT: move exhausted event
        DLT->>Ops: log or alert metadata
    end
```

## 13. Code map: who owns what

| Job | Main code | What the code is responsible for |
|---|---|---|
| Accept successful payment | `PaymentProcessedConsumer` | Starts Booking's safe inbound processing path. |
| Confirm booking and make evidence event | `PaymentProcessedProcessor` | Changes Booking to confirmed and creates two independent outbox records. |
| Keep payment processing atomic | `InboundEventProcessingTransactionService` | Saves the Booking change, outgoing events, and inbound completion together. |
| Repair missing payment outputs | `InboundOutboxRetryService` | Checks that payment created both expected outbox records. |
| Publish Booking events | `OutgoingOutboxPublisher`, `BookingEventProducer` | Sends each saved Booking outbox record after commit and on scheduled retry. |
| Check completion permission | `BookingAdminController` | Allows only `ADMIN` or `SUPER_ADMIN`. |
| Change Booking to complete | `BookingServiceImpl`, `BookingStatusTransitionService` | Makes the trusted completion change and creates its outbox record. |
| Save payment evidence | `ReceiptEligibilityCapturedConsumer`, `ReceiptCandidateService` | Creates candidate or finance review. |
| Save completion evidence | `ExperienceCompletedConsumer`, `ReceiptCandidateService` | Saves completion first, then issues only when allowed. |
| Keep old topic compatible | `LegacyReceiptGenerationConsumer` | Captures legacy events but never auto-issues a receipt. |
| Create receipt | `ReceiptIssuanceService` | Makes one immutable non-GST PDF receipt from Billing's saved candidate. |
| Show availability and download | `ReceiptController`, `ReceiptQueryService` | Protects owner-only read access and checks file integrity. |
| Queue email resend | `ReceiptDeliveryService`, `BillingOutboxService`, `BillingOutboxPublisher` | Checks resend request and safely sends it to Booking later. |
| Send attachment email | `ReceiptDeliveryConsumer`, `BillingDocumentClient`, `EmailNotificationService` | Gets the private PDF through internal auth and sends or explicitly skips email. |
| Watch Billing DLTs | `ReceiptCandidateDltConsumer` | Logs safe Kafka location information for failed receipt events. |
| Watch Booking delivery DLT | `BookingNotificationDltConsumer` | Alerts operations about failed receipt delivery messages. |

There is no separate notification service. Booking is still the service that
sends email.

## 14. Rules that must never change

1. Payment success alone must never create a receipt.
2. Only trusted Booking completion can unlock a receipt.
3. Billing must save enough payment evidence to issue without reading Booking
   or Payment databases.
4. Download must be manual.
5. Download must not send email.
6. Email must be an explicit resend request.
7. Duplicate events must not create duplicate receipts.
8. Kafka/outbox retries and DLT handling must continue to work.
9. An email problem must not undo booking completion or receipt creation.
10. The process must continue safely after an application restart.
11. A review-required or not-eligible candidate must never issue.
12. Public APIs must never expose a private storage key, PDF bytes in a list
    response, token, or unnecessary payment details.
13. Issuing a receipt must not automatically add an email delivery outbox row.
14. The original receipt stays unchanged when a booking is manually cancelled
    or refunded. Phase A does not create automatic credit notes.

## 15. What changed from the older flow

The current repository already runs the Phase A approach. The table below
helps developers avoid accidentally bringing old behavior back.

| Older idea | Phase A behavior now |
|---|---|
| Payment success could be treated as a receipt-generation command. | Payment success captures evidence only. |
| `ReceiptGenerationRequestedEvent` may still arrive from older systems. | `LegacyReceiptGenerationConsumer` stores capture data only. It never issues automatically. |
| Booking ended at `CONFIRMED`. | Booking can now move from `CONFIRMED` to trusted `COMPLETED`. |
| Receipt processing could depend on the order that Kafka topics arrive. | Billing saves both payment and completion evidence. Either event may arrive first. |
| Receipt issuance and email could be thought of as one action. | Issuance is separate. Resend is the only delivery trigger. |
| Download might be mistaken for a generation trigger. | Download only reads an existing issued document. |

The old automatic-generation implementation is not present in this checkout.
Do not assume an older historical call path beyond the compatibility topic
that remains in the code.

## 16. What was kept, changed, or added

| Type | Area | Main changes |
|---|---|---|
| KEEP | Booking inbound/outgoing outbox pattern | Continue saving database changes before publishing Kafka messages. |
| CHANGE | Payment processing | `PaymentProcessedProcessor` now creates both confirmation and evidence outbox records. |
| CHANGE | Booking state | Add `COMPLETED`, `completedAt`, and trusted completion endpoint. |
| ADD | New events | `ReceiptEligibilityCapturedEvent` and `ExperienceCompletedEvent`. |
| ADD | Billing evidence data | `ReceiptCandidate`, `ExperienceCompletionEvidence`, and review handling. |
| ADD | Receipt creation service | `ReceiptIssuanceService` creates one receipt only after completion. |
| CHANGE | Receipt availability | Billing can report waiting, preparing, manual review, or available. |
| KEEP | Download API | It stays owner-only and read-only. |
| KEEP | Resend delivery pattern | It stays explicit, audited, rate-limited, and outbox-backed. |
| CHANGE | Legacy receipt-generation topic | It becomes capture-only compatibility behavior. |
| ADD | Admin tracking | Read-only Billing tracking endpoints with redacted data and independent endpoint/Swagger configuration. |

### Stored data changes

| Record | Why it exists |
|---|---|
| Booking `completedAt` and `COMPLETED` | Shows trusted experience completion. |
| Booking outgoing outbox | Holds confirmation, payment-evidence, and completion events until Kafka accepts them. |
| `ReceiptCandidate` | Holds the independent payment/booking snapshot. |
| `ExperienceCompletionEvidence` | Holds completion even when it arrives before the candidate. |
| `FinanceReviewCase` | Gives finance a durable problem record for bad payment evidence. |
| `FiscalDocument` | Holds the one immutable receipt for a booking. |
| Billing delivery outbox/audit/rate-limit data | Supports explicit email resend without affecting issuance. |

### Important API and topic names

| Kind | Name | Purpose |
|---|---|---|
| Booking API | `PUT /booking/admin/bookings/{bookingId}/complete` | Trusted completion. |
| Billing API | `GET /billing/api/receipts/availability` | Safe lifecycle status. |
| Billing API | `GET /billing/api/receipts/{documentId}/download` | Owner-only manual download. |
| Billing API | `POST /billing/api/receipts/{documentId}/resend` | Explicit email resend. |
| Kafka event | `ReceiptEligibilityCapturedEvent` | Payment-time evidence. |
| Kafka topic | `topic_receipt_eligibility_captured` | Carries payment evidence to Billing. |
| Kafka event | `ExperienceCompletedEvent` | Trusted completion evidence. |
| Kafka topic | `topic_experience_completed` | Carries completion to Billing. |
| Compatibility topic | `topic_receipt_generation_requested` | Older input; capture only, never automatic issuance. |
| Kafka event | `ReceiptDeliveryRequestedEvent` | Explicit resend request. |
| Kafka topic | `topic_receipt_delivery_requested` | Delivers resend work to Booking. |

### Testing focus

The staged tests cover:

- two independent payment outputs;
- payment-output retry reconciliation;
- completion authorization and atomic event creation;
- candidate validation and finance-review cases;
- completion-before-candidate ordering;
- completion-gated issuance with no automatic email;
- duplicate receipt protection;
- Billing admin authorization, filtering, pagination, disabled endpoints, and
  redaction.

### Migration and operational notes

1. Keep the old `topic_receipt_generation_requested` topic mapping while older
   producers might still send it.
2. Do not change its consumer back to automatic issuance.
3. Make sure Mongo indexes are active before production traffic. They prevent
   duplicate candidates, completion records, and documents.
4. Deploy Booking and Billing event mappings together before producing the new
   event types.
5. Keep receipt sequence and private-storage checksum metadata during restore
   or storage migration.

### Assumptions

- This repository treats `PaymentProcessedEvent` as trusted payment success.
  The Payment service itself is outside this codebase.
- The gateway is responsible for stripping browser-supplied identity/role
  headers and adding headers from a validated JWT.
- DLT replay is an operations procedure. The code records or alerts failed
  messages; it does not automatically replay them without human review.
