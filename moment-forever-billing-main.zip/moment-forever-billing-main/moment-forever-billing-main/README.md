# Moment Forever Billing

Billing owns private, immutable non-GST payment receipts. It uses the shared
MongoDB server but stores its own documents in the `moment_forever_billing`
database. It does not read Booking or Payment databases.

## Run locally

Billing uses MongoDB transactions for receipt evidence and outbox state. MongoDB
transactions require a replica set, including for a single local MongoDB
container.

1. Start the local single-node replica set:

   ```powershell
   docker compose up -d
   docker compose logs mongo-init
   ```

   `mongo-init` exits successfully after initializing replica set `rs0`.

2. Set a local-only internal token. It must match the token used by Booking when
   exercising receipt resend delivery:

   ```powershell
   $env:BILLING_INTERNAL_TOKEN = "local-development-only-token"
   ```

3. Run Billing:

   ```powershell
   mvn spring-boot:run
   ```

The default URI is
`mongodb://localhost:27017/moment_forever_billing?replicaSet=rs0&directConnection=true`.
Set `MONGODB_URI` to use another MongoDB deployment. Production and shared
environments must use a replica set or mongos; a standalone MongoDB server
cannot run the required transactions.

## Container image

Build the service image from this directory:

```powershell
docker build -t groote123/moment-forever-billing:latest .
```

The Kubernetes/Argo CD manifests live in the Infrastructure repository under
`clusters/dev/billing`.
